# Platform builds: Web/PWA, Android, Desktop

AI World Builder keeps one React/Three.js codebase and wraps it for each platform. Core procedural planning/generation, editing, IndexedDB persistence, imports and exports remain local and require no paid service.

## 1. Web and installable PWA

```bash
npm install
npm run dev            # development: frontend 5173 + API 8787
npm run pwa:build      # production files in dist/
```

The production build includes a manifest, icon, standalone display metadata, an install prompt and a service worker. After one successful production load, same-origin static resources are cached for offline startup. API routes are deliberately not cached; remote AI/research correctly report unavailable while offline.

Install from Chrome/Edge using **Install** in the app/header or browser menu. On iOS Safari use Share → Add to Home Screen (the `beforeinstallprompt` event is not supported by iOS).

## 2. Android (Capacitor)

The native project is committed in `android/`.

```bash
npm run android:sync   # rebuild web assets and copy them into Android
npm run android:open   # open Android Studio
# or, with JDK 17+ and Android SDK installed:
cd android
./gradlew assembleDebug
```

Debug APK output: `android/app/build/outputs/apk/debug/app-debug.apk`.

### Android requirements and API behavior

- JDK 17+, Android Studio/SDK and platform build tools are required.
- This sandbox has only Java 11, so the generated Android project was synced successfully but APK compilation cannot complete here. The Gradle error was verified and documented rather than hidden.
- Local procedural features work in the bundled WebView without a backend.
- Hosted LLM, Tripo and web research need a reachable HTTPS backend. Build with a public backend URL (never an API key):

```bash
VITE_API_BASE_URL=https://your-backend.example npm run android:sync
```

Provider keys remain only on that backend. Never place them in `VITE_*` variables or the Android project.

## 3. Desktop (Electron)

```bash
npm run desktop:bundle   # builds web + bundled Express API
npm run desktop:pack     # unpacked app for current OS
npm run desktop:dist     # installer/package for current OS
```

Targets: Windows NSIS, macOS DMG, Linux AppImage + DEB. Build each signed release on its target OS/CI. The production Electron wrapper:

- launches the bundled Express API on localhost;
- serves the built web app from an ephemeral localhost port;
- proxies `/api` to the private local API;
- keeps `contextIsolation`, renderer sandboxing and no Node integration;
- opens external links in the system browser.

A Linux x64 unpacked package was successfully built in this workspace at `release/linux-unpacked` (generated build output, not source-controlled/persisted). Real GUI launch could not be tested because the sandbox has no graphical display.

## Mobile interaction notes

The UI switches at 960px to a viewport-first layout with bottom navigation for World, Hierarchy, Assets, Properties and Console. It includes safe-area insets for notches/navigation bars, 40px toolbar targets, 52px bottom navigation targets, touch manipulation hints, OrbitControls pinch/pan behavior, and responsive dialogs.

Physical Android/iOS testing is still required for device-specific GPU limits, touch transforms, large imports and downloads. These are not claimed verified merely because responsive CSS exists.

## Security and dependency notes

- `npm audit --omit=dev` reported **0 production vulnerabilities** when platform dependencies were added.
- Packaging dependencies are development-only and may report transitive tooling advisories; keep Electron/Capacitor/builder versions updated and review before release.
- Capacitor Android is pinned to major 7 for Node 20 compatibility in this project.
- No signing keys, API keys or credentials belong in this repository.
