package ai.arena.worldbuilder;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
