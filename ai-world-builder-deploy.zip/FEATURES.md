# FEATURES — implemented vs. pending

Status legend: ✅ implemented & covered by tests or runtime verification · 🟡 implemented,
needs browser verification · ⏳ pending / planned

## 1. AI world generation
| Feature | Status | Notes |
|---|---|---|
| Natural-language world description → editable WorldPlan | ✅ | Local rule-based planner (offline) + optional remote LLM |
| Plan preview before execution | 🟡 | Editor commands show Apply/Discard diffs; initial text-to-world planning still executes immediately |
| Inference of missing details (assumptions surfaced in console) | ✅ | `PlannerOutput.assumptions` |
| Biomes (plains, forest, desert, snow, swamp, volcanic, beach, ocean, island, canyon, mountains…) | ✅ | Keyword inference + biome presets |
| Art styles (realistic, stylized, cartoon, low-poly, voxel) | ✅ | Palette + shading + terracing differences |
| World size / density / quality controls | ✅ | World panel sliders |
| Terrain features (mountains, valleys, cliffs, canyons, craters, lakes, rivers, plateaus…) | ✅ | Explicit feature shaping on heightfield |
| Structures (villages, cities, castles, farms, ruins, temples, camps, harbors, graveyards) | ✅ | Region expansion with roads + props |
| Regenerate selected area without destroying the rest | 🟡 | `regenerateRegion()` + command support; dedicated box-select UI pending |
| Cancellable generation jobs with progress | ✅ | Jobs panel with Cancel |
| Remote LLM planning (OpenAI-compatible / Anthropic) | ✅ | Server-side keys; validated output; graceful fallback to local planner |

## 2. 3D asset generation
| Feature | Status | Notes |
|---|---|---|
| Provider interface (pluggable, replaceable) | ✅ | `Asset3DProvider` in `src/ai/provider.ts` |
| Tripo text-to-3D / image-to-3D submission | 🟡 | Backend URL/token endpoints + polling compile; requires key/credits; direct image upload and automatic GLB import pending; v2→v3 migration needed |
| Procedural modeling fallback (~50 prefab builders) | ✅ | Trees, rocks, houses, towers, props… honest procedural meshes |
| Honest “not configured” messaging (no fake generation) | ✅ | 503 `provider-not-configured` + UI badges |
| PBR materials / texture maps / LOD / rigging pipelines | ⏳ | Materials (color/rough/metal/emissive) per object; LOD & rigging planned |
| Local generation tools (e.g. running local mesh AIs) | ⏳ | Provider interface ready; no local mesh model bundled |

## 3. Terrain & world intelligence
| Feature | Status | Notes |
|---|---|---|
| 5 terrain generators (fbm, islands, canyons, mountains, flat) | ✅ | Deterministic, tested |
| Domain warp, ridge mixing, terracing (voxel style) | ✅ | Terrain params in WorldPlan |
| Heightfield sampling, normals, serialization | ✅ | For placement + export |
| Water level, animated water surface | 🟡 | Static plane in export (documented) |
| Slope/water-aware, spacing-constrained placement | ✅ | Scatter tests cover underwater exclusion |
| Biome-coherent transitions (weights, height bias) | ✅ | |
| Rivers as terrain trenches + path ribbons | ✅ | |
| Caves, tunnels, interiors | ⏳ | |

## 4. Asset pack intelligence
| Feature | Status | Notes |
|---|---|---|
| ZIP pack upload with safe extraction | ✅ | Traversal guard, size budgets, nested-ZIP refusal |
| Scan, classify, index (format, kind, dimensions where possible) | ✅ | `classify.ts` + import report |
| Unsupported files & extraction errors reported clearly | ✅ | Import dialog issue list + console |
| License/attribution preservation | ✅ | Extracted and stored per asset |
| Auto-arrange imported models in the scene (scale, rotation, terrain align, spacing) | ⏳ | Placement pipeline exists for prefabs; wired to imported meshes next |
| Preview thumbnails of imported assets | ⏳ | List preview exists; in-scene thumbnails pending |

## 5. Internet research & knowledge
| Feature | Status | Notes |
|---|---|---|
| Web search via providers (Wikipedia + DuckDuckGo) | ✅ | Runtime-verified with live results |
| Source URLs + retrieval timestamps + verified flag | ✅ | |
| Relevance scoring | ✅ | Term-overlap scoring before returning |
| Caching with refresh | ✅ | 30-min server cache |
| Persistent project reference library + RAG context | ⏳ | Research panel is session-only; persistence and retrieval injection are not implemented |
| Respect robots/ToS/rate limits, no login bypass | ✅ | Public endpoints only, timeouts, UA identification |

## 6. Editor & workflow
| Feature | Status | Notes |
|---|---|---|
| Real-time 3D viewport (orbit, zoom, pan) | 🟡 | three.js + OrbitControls; needs browser smoke test |
| View modes (rendered / solid / wireframe) | 🟡 | |
| Selection + move/rotate/scale gizmo + snapping-ready transforms | 🟡 | TransformControls; grid snapping pending |
| Scene hierarchy panel | ✅ | Multi-select, filter, region list |
| Properties panel (transform, material overrides, per-object) | ✅ | |
| Asset browser (procedural prefab library, click-to-place) | ✅ | |
| World panel (style, environment, density, seed, size, quality, features) | ✅ | |
| Undo/redo (snapshots) | ✅ | Tested |
| Autosave + checkpoints + restore | ✅ | Tested |
| Natural-language editor commands | ✅ | add/remove/style/weather/density/rename/regenerate |
| Preview changes before applying | ✅ | |
| Duplicate/delete/multi-select | ✅ | |
| Responsive desktop + mobile layouts | 🟡 | Grid + bottom nav; needs device verification |

## 7. Import / export
| Feature | Status | Notes |
|---|---|---|
| GLB/glTF scene export (geometry, materials, hierarchy, metadata) | 🟡 | GLTFExporter; large scenes untested |
| WorldPlan JSON export/import (validated) | ✅ | |
| Project package ZIP (plan + scene + heightmap + assets + checkpoints + reports) | ✅ | Tested (structure verified) |
| Godot 4 conversion helper (`godot_import.gd`) + docs | ✅ | In package `tools/` |
| Unity converter (`unity_heightmap_import.cs`) + docs | ✅ | |
| Per-target export validation reports (no silent loss) | ✅ | Tested |
| Import of user GLB/OBJ models into the viewport | ⏳ | Classified + stored; scene placement wiring pending |
| FBX/DAE import | ⏳ | Reported as unsupported (convert to GLB) |

## 8. Reliability & security
| Feature | Status | Notes |
|---|---|---|
| API keys server-side only | ✅ | |
| Upload validation (type, size, traversal) | ✅ | Tested (client + server paths) |
| JSON body limits, error redaction | ✅ | |
| Loading / empty / error / success states | ✅ | Console + dialogs + badges |
| Test suite (79 tests) | ✅ | Terrain, placement, saving/reopening, import, export, parsing, planning |
| Build + typecheck clean | ✅ | |

## Highest-priority pending work
1. Browser smoke test pass (WebGL, touch, GLB export of a full world).
2. Terrain brush tools (height paint/flatten/smooth) + heightmap delta persistence.
3. Imported GLB/OBJ → placeable prefabs in the asset browser.
4. Region box-select + “regenerate this area” gizmo.
5. Persistent research/reference library with RAG injection into planner prompts.
6. Snap-to-grid / snapping options for the transform gizmo.
