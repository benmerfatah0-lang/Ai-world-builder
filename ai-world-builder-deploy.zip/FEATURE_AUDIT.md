# Full feature audit — AI World Builder

**Audit date:** 2026-10-21  
**Method:** source-path inspection, TypeScript check, Vitest suite, production build, and live HTTP/API checks. A visible control alone is not counted as complete.

Status: **VERIFIED** = exercised by automated test or live endpoint; **IMPLEMENTED / BROWSER CHECK** = compiled implementation but WebGL/browser interaction still needs manual verification; **PARTIAL** = useful implementation exists but requirement is not complete; **MISSING** = no working path.

## Verification baseline

| Evidence | Result |
|---|---|
| `npm run typecheck` | PASS |
| `npm test` | PASS — 79/79 tests, 7 files |
| `npm run build` | PASS — 91 modules, JS 986.47 kB / 276.68 kB gzip |
| Live frontend and Vite transforms | HTTP 200 |
| `/api/health`, provider status, `/api/files/classify` | Live verified |
| Browser automation / physical Android | Not available; WebGL rendering, touch gestures and browser download flows are not claimed verified |

## A. Original application requirements

| Capability | Status | Actual implementation and evidence | Gaps / limitations |
|---|---|---|---|
| Natural-language world generation | **VERIFIED** | `localPlanner.ts`; optional `remotePlanner.ts`; planner tests cover inference and deterministic output | Prompt planning immediately executes; there is no full JSON plan-review editor before generation |
| Editable, versioned WorldPlan | **PARTIAL** | Types in `core/types.ts`, JSON schema, validator, plan ops, JSON import/export, settings/object editors | No raw/tree WorldPlan editor; initial AI plan lacks explicit Apply/Discard stage |
| Reference images as planning input | **PARTIAL** | Provider input supports image descriptors; image-to-3D accepts URL/token | UI does not analyze reference-image colors/labels or attach them to world planning |
| World size, density, quality, art style | **IMPLEMENTED / BROWSER CHECK** | WorldPlan settings, local inference, RightPanel controls, palettes/material factory | Browser interaction not automated |
| Terrain/biomes/paths/vegetation/buildings/props/lighting/atmosphere/POIs | **VERIFIED core** | Terrain/scatter/structures generators plus viewport lighting/sky/water; generator tests | “POI” is represented as regions/objects, not a dedicated POI schema; caves/tunnels/interiors absent |
| Area regeneration without destroying rest | **PARTIAL** | `regenerateRegion`, `regenerateSelected`, `regenerateArea` | No region brush/box/circle selection UI; selected authored objects can be removed by regenerate-selection behavior |
| Real-time viewport: orbit/zoom/pan/view modes | **IMPLEMENTED / BROWSER CHECK** | `engine/Viewport.ts`, OrbitControls, render loop, three view modes | Needs real browser and Android smoke test |
| Select/move/rotate/scale/duplicate/delete | **IMPLEMENTED / BROWSER CHECK** | Raycast selection, TransformControls, store actions, shortcuts | Grid/surface snapping options are absent |
| Hierarchy, asset browser, properties, materials | **IMPLEMENTED / BROWSER CHECK** | `LeftPanel`, `RightPanel`, procedural prefab library | Imported model bytes are not yet loaded as placeable GLB/OBJ scene assets |
| Terrain editing tools | **MISSING** | Terrain settings and full regeneration exist | No paint/raise/lower/flatten/smooth brush |
| Undo/redo | **VERIFIED core** | `PlanHistory` and plan-op tests | Derived-state-only changes are not all represented as plan history |
| Autosave, reopen, checkpoints | **VERIFIED core** | IndexedDB abstraction + ProjectStore; memory-backed save/reopen/checkpoint tests | Browser IndexedDB lifecycle is not browser-automated |
| Progress + cancellable jobs | **VERIFIED core** | Generator progress/cancel token and Jobs UI; cancellation test | Some short actions only show busy state rather than cancellable jobs |
| Natural-language editor commands | **VERIFIED** | Parser tests; command preview Apply/Discard | Rule-based command vocabulary is intentionally finite |
| Per-object/per-region regeneration | **PARTIAL** | Selection and coordinate-based regeneration paths | Dedicated region selection UX missing |
| Loading/empty/error/success states | **IMPLEMENTED** | Logs, jobs, dialogs, status badges, provider errors | Not every state has browser interaction tests |
| Responsive/mobile UI | **IMPLEMENTED / BROWSER CHECK** | CSS breakpoint and `MobileNav` | Physical-device test pending |

## B. AI 3D asset generation

| Capability | Status | Actual implementation and evidence | Gaps / limitations |
|---|---|---|---|
| Replaceable 3D provider interface | **VERIFIED by compile** | `Asset3DProvider`; procedural + Tripo implementations | No third-party/local-model adapter bundled |
| Text-to-3D | **PARTIAL external** | Backend Tripo task creation/polling; honest 503 when unconfigured | Requires `TRIPO_API_KEY`, internet and provider credits; no configured-key E2E test; returned GLB not auto-imported |
| Image-to-3D | **PARTIAL external — repaired in audit** | Added `/api/ai/image-to-3d` and Tripo `image_to_model`; accepts HTTPS URL or Tripo file token; validation live-tested | Raw browser Blob upload/upload-token acquisition UI absent; requires Tripo; output not auto-imported. Tripo v2 retirement risk noted below |
| Procedural fallback | **VERIFIED core** | ~50 programmatic prefab builders; no false AI claim | Selection from arbitrary descriptive prompts is basic |
| PBR/material generation | **PARTIAL** | MeshStandard materials with roughness/metalness/emissive; Tripo requests PBR at high quality | No texture baking/editing pipeline |
| Mesh optimization and LOD | **PARTIAL** | Instancing, merged prefab geometry, provider face limits | No LOD generation/decimation UI or runtime LOD objects |
| Rigging/animation | **MISSING** | — | Not implemented |

## C. Asset-pack intelligence

| Capability | Status | Actual implementation and evidence | Gaps / limitations |
|---|---|---|---|
| ZIP and loose-file import | **VERIFIED parser** | JSZip pipeline + classification tests | Browser file picker not automated |
| Safe extraction | **VERIFIED** | 64 MB/file classifier limit, 256 MB unpacked budget, 4000 files, traversal checks, nested ZIP refusal | ZIP bombs are bounded only after decompression by JSZip; no streaming extraction |
| Scan/classify/index | **VERIFIED** | Kind/format/size/tags and asset records | Model geometry dimensions are not parsed despite earlier docs implying dimensions “where possible” |
| Preserve originals and metadata | **IMPLEMENTED — repaired in audit** | ZIP and loose imports now store every readable original in project-scoped IndexedDB and merge license/attribution into plan assets | Export UI does not yet retrieve those IndexedDB blobs into project package `assets/` automatically |
| Preview assets | **PARTIAL** | File list/status preview | No rendered model/texture thumbnails |
| Auto-arrange/scale/rotate/terrain align/collision spacing | **MISSING for imported models** | Procedural scatter has these placement concepts | Imported GLB/OBJ bytes are not instantiated in the viewport |
| Never overwrite originals | **IMPLEMENTED** | New project-scoped immutable copies; importer does not mutate input | No deduplication/version UI |

## D. Terrain and structure intelligence

| Capability | Status | Evidence | Gaps |
|---|---|---|---|
| Mountains, hills, valleys, cliffs, canyons, craters, lakes, rivers, beaches, plateaus | **VERIFIED** | Heightfield feature code and terrain tests | River hydrology is stylized, not simulation-grade |
| Islands/ocean/plains/forest/desert/snow/swamp/volcanic | **VERIFIED** | Generator and biome presets/tests | Biome blending is heuristic |
| Villages/cities/castles/farms/ruins/temples/camps/harbors/quarries/orchards/graveyards | **PARTIAL** | Region kinds + structure expansion; key village/castle/farm paths tested | Several kinds reuse generic layouts; no detailed interiors |
| Volumetric caves/tunnels/interiors | **MISSING** | — | Heightfield cannot represent overhangs/caves |

## E. Internet research and project knowledge

| Capability | Status | Evidence | Gaps |
|---|---|---|---|
| Search/read public references | **VERIFIED search** | Wikipedia + DuckDuckGo live search, URLs/snippets/timestamps | No general full-page reader/extractor |
| Verified vs guessed | **PARTIAL** | `verified` field and planner assumptions | Search result “verified” means source-backed result, not independent fact verification |
| Cache + refresh | **PARTIAL** | 30-minute in-memory server cache | No explicit refresh/bypass-cache control; cache is lost on server restart |
| Persistent project knowledge | **MISSING** | Schema provenance and current-session research results | Research results are not persisted to IndexedDB per project |
| Optional RAG | **MISSING** | — | Research is not injected into planner context; no claim that the base model learns |

## F. Import/export and engine workflows

| Capability | Status | Evidence | Gaps |
|---|---|---|---|
| GLB/glTF with hierarchy/materials | **IMPLEMENTED / BROWSER CHECK** | `GLTFExporter`, metadata extras, compiled | Runtime full-world export not browser-tested; UI exports binary GLB only |
| Export validation and unsupported reporting | **VERIFIED** | Export validator tests and package reports | Runtime GLTFExporter failures depend on scene/browser |
| Full project package | **VERIFIED structure** | ZIP structure test: plan, heightmap, reports, checkpoints, tools | Stored asset bytes are not yet gathered by the store action and passed to package exporter |
| Godot workflow | **VERIFIED artifact** | Generated `.gd` helper + instructions | Converter not run inside Godot |
| Unity workflow | **VERIFIED artifact** | Generated `.cs` helper + instructions | Converter not run inside Unity |

## G. Architecture, security, continuation, tests

| Capability | Status | Evidence | Gaps |
|---|---|---|---|
| Modular architecture/reusable systems | **VERIFIED by review/build** | Core/generators/engine/AI/persistence/assets/export/server boundaries | `state/store.ts` is large (~1100 lines) and should be split by domain eventually |
| API keys backend-only | **VERIFIED** | `server/src/env.ts`; relative `/api`; redacted status | Browser must never receive provider keys |
| Provider connection testing | **IMPLEMENTED** | Settings action tests local/remote/Tripo/research readiness | Research readiness check is optimistic and does not issue a network request |
| Tests for terrain, placement, save/reopen, import, export | **VERIFIED** | 79 tests | No DOM/WebGL E2E suite; no external-provider contract mocks |
| Project-continuation docs | **UPDATED** | README, PROJECT_CONTEXT, ARCHITECTURE, this audit | Keep audit status aligned with code changes |

## Duplicated, misleading, or broken items found

1. **Broken:** frontend image-to-3D called a backend route that did not exist. Repaired with URL/token API and honest raw-upload limitation.
2. **Broken/incomplete:** imported originals were held only in transient memory. Repaired by project-scoped IndexedDB storage for ZIP and loose imports.
3. **Incomplete:** loose imports did not merge asset records into the WorldPlan. Repaired.
4. **Misleading docs:** prior README/FEATURES said Tripo image-to-3D was implemented and implied automatic asset-library import. Corrected: generation submission exists, automatic result download/import does not.
5. **Misleading docs:** prior text implied all AI WorldPlans were previewed before execution. Only editor commands have Apply/Discard preview; initial world prompts execute immediately.
6. **Misleading docs:** “persistent research library/RAG” was described too optimistically. It is session-only search plus server memory cache.
7. **Duplicated concepts, not duplicate code:** procedural “asset generation” and prefab placement share the same prefab builders by design; generated region objects and authored plan objects are separate by design.

## External dependencies and commercial limitations

- Core procedural creation, editing, IndexedDB persistence and export require no paid API.
- OpenAI-compatible and Anthropic planning require user-supplied server keys and may incur provider charges.
- Tripo text/image-to-3D requires `TRIPO_API_KEY`, network access and available provider credits. No configured-key end-to-end run was possible in this audit.
- [Tripo’s public general documentation](https://platform.tripo3d.ai/docs/general) says its v2 API is scheduled for retirement on **2026-11-01**; this code currently uses v2 for compatibility and should migrate to v3 next. The image request shape was checked against [Tripo’s generation documentation](https://platform.tripo3d.ai/docs/generation).
- DuckDuckGo/Wikipedia research uses public endpoints and can fail or throttle independently.
- Supported asset indexing includes GLB/glTF/OBJ and common textures/audio/text. FBX/DAE/BLEND and nested ZIPs are retained/reported but not loaded into the viewport.

## H. Cross-platform delivery (added 2026-10-21)

| Capability | Status | Evidence | Limits |
|---|---|---|---|
| Installable PWA | **IMPLEMENTED / BROWSER CHECK** | Manifest, icon, install event UI, production-only service worker, successful production build | Install/offline cycle needs a real production browser test; iOS uses Share → Add to Home Screen |
| Responsive phone/tablet layout | **IMPLEMENTED / DEVICE CHECK** | Existing mobile panels plus safe-area insets and larger touch targets | Physical Android/iOS GPU, gestures and downloads not yet tested |
| Android application project | **IMPLEMENTED / BUILD ENV NEEDED** | Capacitor project added and `cap sync android` passed | APK build attempted and correctly failed because sandbox has Java 11; JDK 17+ and Android SDK required |
| Desktop application | **IMPLEMENTED / GUI CHECK** | Electron wrapper bundles local Express API, static app/proxy; web/API bundle passed; Linux x64 unpacked package built | No graphical display for launch test; signed Windows/macOS/Linux installers must be produced on release systems |
| Native backend connectivity | **IMPLEMENTED** | Electron embeds backend; Android accepts public `VITE_API_BASE_URL` while keeping secrets server-side | Android hosted AI/research needs a deployed HTTPS backend; local core works without it |

See `PLATFORMS.md` for exact commands and security guidance.

## Prioritized next implementation steps

1. Add AI-plan review/edit/Apply stage before generation.
2. Migrate Tripo adapter to v3; add bounded image upload → provider token; poll and import resulting GLB.
3. Load imported GLB/OBJ into the viewport, generate previews, and add deterministic terrain-aligned auto-arrangement.
4. Include persisted asset blobs in project-package export and restore them on package import.
5. Persist project research, add refresh control and explicit source selection for RAG prompts.
6. Add terrain brushes, region selection gizmo, snapping, and non-destructive region regeneration semantics.
7. Add Playwright browser tests (WebGL smoke, persistence, GLB download) and physical Android checks.
