import { describe, it, expect } from 'vitest';
import { classifyFile, extractAttribution, toAssetRecord } from '../src/assets/classify';
import { createEmptyPlan } from '../src/core/types';
import { validateExport } from '../src/export/validate';

describe('Asset classification', () => {
  it('detects supported model formats', () => {
    const c = classifyFile('models/tree.glb', 1024);
    expect(c.kind).toBe('model');
    expect(c.supported).toBe(true);
    expect(c.format).toBe('glTF Binary');
  });

  it('flags unsupported model formats with an explanation', () => {
    const c = classifyFile('models/house.fbx', 2048);
    expect(c.kind).toBe('model');
    expect(c.supported).toBe(false);
    expect(c.reason).toBeTruthy();
  });

  it('detects textures and images', () => {
    expect(classifyFile('textures/grass.png', 10).kind).toBe('texture');
    expect(classifyFile('preview/cover.jpg', 10).kind).toBe('image');
    expect(classifyFile('textures/normal.tga', 10).supported).toBe(false);
  });

  it('detects license files', () => {
    const c = classifyFile('LICENSE.txt', 500);
    expect(c.format).toBe('text');
    expect(c.supported).toBe(true);
  });

  it('rejects oversized files', () => {
    const c = classifyFile('big/huge.glb', 100 * 1024 * 1024);
    expect(c.supported).toBe(false);
    expect(c.reason).toContain('MB');
  });

  it('flags nested ZIPs as unsupported', () => {
    const c = classifyFile('nested/pack.zip', 100);
    expect(c.supported).toBe(false);
  });

  it('derives tags from paths', () => {
    const c = classifyFile('nature/trees/oak_tree_lowpoly.glb', 100);
    expect(c.tags).toContain('tree');
    expect(c.tags).toContain('nature');
    expect(c.tags).toContain('lowpoly');
  });

  it('builds asset records with provenance', () => {
    const rec = toAssetRecord(classifyFile('wood/crate_01.glb', 100), 'user');
    expect(rec.source).toBe('user');
    expect(rec.kind).toBe('model');
  });

  it('extracts attribution and license', () => {
    const result = extractAttribution([
      { path: 'LICENSE.txt', text: 'CC0 1.0 Universal' },
      { path: 'README.md', text: 'Author: Jane Doe\nThese models are free.' },
    ]);
    expect(result.license).toContain('CC0');
    expect(result.attribution).toContain('Jane Doe');
  });
});

describe('Export validation reports', () => {
  it('reports GLB capabilities', () => {
    const plan = createEmptyPlan();
    const report = validateExport(plan, 'glb');
    expect(report.ok).toBe(true);
    const meshes = report.capabilities.find((c) => c.feature.includes('Meshes'));
    expect(meshes?.supported).toBe(true);
    const anim = report.capabilities.find((c) => /animation/i.test(c.feature));
    expect(anim?.supported).toBe(false);
  });

  it('reports Godot and Unity targets', () => {
    const plan = createEmptyPlan();
    const godot = validateExport(plan, 'godot');
    const unity = validateExport(plan, 'unity');
    expect(godot.capabilities.length).toBeGreaterThan(3);
    expect(unity.capabilities.length).toBeGreaterThan(3);
    expect(unity.capabilities.some((c) => !c.supported)).toBe(true);
  });

  it('warns on empty worlds', () => {
    const report = validateExport(createEmptyPlan(), 'glb');
    expect(report.warnings.some((w) => w.includes('no objects'))).toBe(true);
  });

  it('includes package capabilities', () => {
    const report = validateExport(createEmptyPlan(), 'project-package');
    expect(report.capabilities.find((c) => c.feature.includes('WorldPlan'))?.supported).toBe(true);
    expect(report.capabilities.find((c) => c.feature.includes('Conversion scripts'))?.supported).toBe(true);
  });
});
