import { describe, it, expect } from 'vitest';
import JSZip from 'jszip';
import { exportProjectPackage } from '../src/export/packageExporter';
import { createEmptyPlan } from '../src/core/types';
import { generateHeightfield } from '../src/generators/terrain';

describe('Project package export', () => {
  it('packages plan, heightmap, reports and tools into a ZIP', async () => {
    const plan = createEmptyPlan({ name: 'Package Test', seed: 21 });
    const hf = generateHeightfield(plan, 33);

    const result = await exportProjectPackage(plan, {
      heightfield: hf,
      checkpoints: [{ id: 'c1', ts: new Date().toISOString(), label: 'first', plan }],
      assets: [{ record: { id: 'a1', name: 'crate', kind: 'model', filename: 'crate.glb', license: 'CC0' }, data: new Uint8Array([1, 2, 3]).buffer }],
    });

    expect(result.blob.size).toBeGreaterThan(200);
    expect(result.filename).toContain('package.zip');
    expect(result.planValidation.valid).toBe(true);
    expect(result.reports.length).toBeGreaterThan(0);

    // Re-open the zip and verify its structure.
    const zip = await JSZip.loadAsync(await result.blob.arrayBuffer());
    const names = Object.keys(zip.files);
    expect(names).toContain('worldplan.json');
    expect(names).toContain('heightmap.json');
    expect(names).toContain('README.md');
    expect(names).toContain('tools/GODOT_IMPORT.md');
    expect(names).toContain('tools/UNITY_IMPORT.md');
    expect(names).toContain('tools/godot_import.gd');
    expect(names).toContain('tools/unity_heightmap_import.cs');
    expect(names.some((n) => n.startsWith('reports/'))).toBe(true);
    expect(names.some((n) => n.startsWith('checkpoints/'))).toBe(true);
    expect(names.some((n) => n.startsWith('assets/'))).toBe(true);

    const planJson = JSON.parse(await zip.file('worldplan.json')!.async('string'));
    expect(planJson.name).toBe('Package Test');
    expect(planJson.schemaVersion).toBe('1.0.0');

    const heightmap = JSON.parse(await zip.file('heightmap.json')!.async('string'));
    expect(heightmap.resolution).toBe(33);
    expect(heightmap.data.length).toBe(33 * 33);
  });

  it('works without optional parts', async () => {
    const plan = createEmptyPlan({ name: 'Minimal' });
    const result = await exportProjectPackage(plan);
    const zip = await JSZip.loadAsync(await result.blob.arrayBuffer());
    expect(Object.keys(zip.files)).toContain('worldplan.json');
    expect(Object.keys(zip.files)).not.toContain('heightmap.json');
  });
});
