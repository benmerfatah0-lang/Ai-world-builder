import { describe, it, expect } from 'vitest';
import { createEmptyPlan, SCHEMA_VERSION } from '../src/core/types';
import { validateWorldPlan } from '../src/core/schema/validate';
import { applyOp, diffPlans } from '../src/core/world/planOps';
import { PlanHistory } from '../src/core/world/history';

describe('WorldPlan schema', () => {
  it('creates a valid empty plan', () => {
    const plan = createEmptyPlan();
    const result = validateWorldPlan(plan);
    if (!result.valid) console.error(result.issues);
    expect(result.valid).toBe(true);
    expect(plan.schemaVersion).toBe(SCHEMA_VERSION);
  });

  it('rejects non-objects', () => {
    expect(validateWorldPlan(null).valid).toBe(false);
    expect(validateWorldPlan('x').valid).toBe(false);
  });

  it('rejects missing required fields', () => {
    const plan = createEmptyPlan();
    const bad = { ...plan, seed: 'nope' };
    const result = validateWorldPlan(bad);
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.path === 'seed')).toBe(true);
  });

  it('rejects duplicate object ids', () => {
    const plan = createEmptyPlan();
    plan.objects = [
      { id: 'dup', kind: 'tree', position: [0, 0, 0] },
      { id: 'dup', kind: 'rock', position: [1, 0, 1] },
    ];
    const result = validateWorldPlan(plan);
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.message.includes('duplicate'))).toBe(true);
  });

  it('rejects bad enum values', () => {
    const plan = createEmptyPlan();
    (plan.settings as { style: string }).style = 'cubist';
    const result = validateWorldPlan(plan);
    expect(result.valid).toBe(false);
  });

  it('accepts plans with clusters and regions', () => {
    const plan = createEmptyPlan();
    plan.objects = [{
      id: 'cluster-1', kind: 'tree', prefab: 'tree.oak_a', position: [0, 0, 0],
      instances: [{ position: [1, 2, 3] }, { position: [4, 5, 6], scale: 2 }],
    }];
    plan.regions = [{ id: 'r1', kind: 'village', center: [10, 20], radius: 30 }];
    expect(validateWorldPlan(plan).valid).toBe(true);
  });
});

describe('Plan operations', () => {
  it('adds, updates, and removes objects', () => {
    let plan = createEmptyPlan();
    const obj = { id: 'o1', kind: 'tree' as const, position: [1, 2, 3] as [number, number, number] };
    plan = applyOp(plan, { type: 'addObject', object: obj }).plan;
    expect(plan.objects).toHaveLength(1);

    plan = applyOp(plan, { type: 'updateObject', id: 'o1', patch: { name: 'Oak' } }).plan;
    expect(plan.objects[0].name).toBe('Oak');

    plan = applyOp(plan, { type: 'transformObject', id: 'o1', position: [5, 5, 5] }).plan;
    expect(plan.objects[0].position).toEqual([5, 5, 5]);

    plan = applyOp(plan, { type: 'removeObject', id: 'o1' }).plan;
    expect(plan.objects).toHaveLength(0);
  });

  it('duplicates objects with fresh ids', () => {
    let plan = createEmptyPlan();
    plan = applyOp(plan, { type: 'addObject', object: { id: 'a', kind: 'rock', position: [0, 0, 0] } }).plan;
    plan = applyOp(plan, { type: 'duplicateObject', id: 'a' }).plan;
    expect(plan.objects).toHaveLength(2);
    expect(plan.objects[1].id).not.toBe('a');
    expect(plan.objects[1].meta?.duplicatedFrom).toBe('a');
  });

  it('computes diffs for preview', () => {
    const before = createEmptyPlan();
    const after = applyOp(before, { type: 'addObject', object: { id: 'x', kind: 'tree', position: [0, 0, 0] } }).plan;
    const diff = diffPlans(before, after);
    expect(diff.added).toHaveLength(1);
    expect(diff.summary.join(' ')).toContain('+1 objects');
  });

  it('supports undo/redo with bounded history', () => {
    const history = new PlanHistory(createEmptyPlan({ name: 'A' }), 5);
    history.commit(createEmptyPlan({ name: 'B' }));
    history.commit(createEmptyPlan({ name: 'C' }));
    expect(history.current.name).toBe('C');
    expect(history.undo()?.name).toBe('B');
    expect(history.undo()?.name).toBe('A');
    expect(history.undo()).toBeNull();
    expect(history.redo()?.name).toBe('B');
    expect(history.redo()?.name).toBe('C');
  });

  it('clears redo stack on new commit', () => {
    const history = new PlanHistory(createEmptyPlan({ name: 'A' }));
    history.commit(createEmptyPlan({ name: 'B' }));
    history.undo();
    history.commit(createEmptyPlan({ name: 'D' }));
    expect(history.canRedo).toBe(false);
  });
});
