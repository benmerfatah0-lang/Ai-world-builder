import { describe, it, expect } from 'vitest';
import { LocalCommandParser } from '../src/ai/commandParser';
import { LocalPlannerProvider } from '../src/ai/localPlanner';
import { validateWorldPlan } from '../src/core/schema/validate';

const parser = new LocalCommandParser();

describe('Command parser', () => {
  it('parses weather commands', () => {
    const c = parser.parse('make it sunset');
    expect(c.intent).toBe('set-weather');
    expect(c.params.sky).toBe('sunset');
  });

  it('parses style commands', () => {
    const c = parser.parse('switch to voxel style');
    expect(c.intent).toBe('set-style');
    expect(c.params.style).toBe('voxel');
  });

  it('parses density commands', () => {
    const c = parser.parse('increase vegetation density');
    expect(c.intent).toBe('set-density');
    expect(c.params.delta).toBeGreaterThan(0);
  });

  it('parses add-object commands with count and location', () => {
    const c = parser.parse('add three pines near the lake');
    expect(c.intent).toBe('add-object');
    expect(c.params.kind).toBe('tree');
    expect(c.params.count).toBe(3);
    expect(String(c.params.near)).toContain('lake');
  });

  it('parses rename commands', () => {
    const c = parser.parse('rename the world to "Emerald Reach"');
    expect(c.intent).toBe('rename');
    expect(c.params.name).toBe('Emerald Reach');
  });

  it('parses remove commands', () => {
    const c = parser.parse('remove all trees');
    expect(c.intent).toBe('remove-object');
    expect(c.params.scope).toBe('all');
  });

  it('parses regenerate commands', () => {
    const c = parser.parse('regenerate this area');
    expect(c.intent).toBe('regenerate-region');
  });

  it('parses world generation commands', () => {
    const c = parser.parse('generate a desert with ancient ruins');
    expect(c.intent).toBe('generate-world');
  });

  it('returns unknown for gibberish', () => {
    const c = parser.parse('purple monkey dishwasher');
    expect(c.intent).toBe('unknown');
    expect(c.confidence).toBeLessThan(0.5);
  });
});

describe('Local planner', () => {
  const planner = new LocalPlannerProvider();

  it('is always configured and tests OK', async () => {
    expect(await planner.isConfigured()).toBe(true);
    const test = await planner.testConnection();
    expect(test.ok).toBe(true);
  });

  it('produces a valid WorldPlan from a rich prompt', async () => {
    const out = await planner.planWorld({
      prompt: 'a snowy mountain village at sunset with a frozen lake and pine forest, low-poly style',
    });
    const validation = validateWorldPlan(out.plan);
    if (!validation.valid) console.error(validation.issues);
    expect(validation.valid).toBe(true);
    expect(out.usedRemoteModel).toBe(false);
    expect(out.explanation.length).toBeGreaterThan(20);
  });

  it('infers biomes from keywords', async () => {
    const out = await planner.planWorld({ prompt: 'a vast desert with cacti and a small oasis' });
    const types = (out.plan.biomes ?? []).map((b) => b.type);
    expect(types).toContain('desert');
  });

  it('infers regions from keywords', async () => {
    const out = await planner.planWorld({ prompt: 'a medieval castle overlooking a village by the river' });
    const kinds = (out.plan.regions ?? []).map((r) => r.kind);
    expect(kinds).toContain('castle');
    expect(kinds).toContain('village');
  });

  it('infers style and environment', async () => {
    const out = await planner.planWorld({ prompt: 'a voxel world at night with a storm' });
    expect(out.plan.settings.style).toBe('voxel');
    expect(out.plan.settings.environment?.skyPreset).toBe('night');
    expect(out.plan.settings.environment?.weather).toBe('storm');
  });

  it('is deterministic for the same prompt', async () => {
    const a = await planner.planWorld({ prompt: 'rolling green hills with a farm' });
    const b = await planner.planWorld({ prompt: 'rolling green hills with a farm' });
    expect(a.plan.seed).toBe(b.plan.seed);
    expect(a.plan.name).toBe(b.plan.name);
  });

  it('records assumptions for underspecified prompts', async () => {
    const out = await planner.planWorld({ prompt: 'hello world' });
    expect(out.assumptions.length).toBeGreaterThan(0);
  });

  it('honors named worlds', async () => {
    const out = await planner.planWorld({ prompt: 'a quiet valley called "Willowmere"' });
    expect(out.plan.name).toBe('Willowmere');
  });

  it('generates island terrain for island prompts', async () => {
    const out = await planner.planWorld({ prompt: 'a tropical island with palms and a beach' });
    expect(out.plan.terrain.generator).toBe('islands');
  });
});
