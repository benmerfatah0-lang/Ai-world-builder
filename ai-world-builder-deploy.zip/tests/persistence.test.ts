import { describe, it, expect } from 'vitest';
import { MemoryKeyValueStore } from '../src/persistence/memoryStore';
import { ProjectStore } from '../src/persistence/projectStore';
import { createEmptyPlan } from '../src/core/types';

function makeStore(): ProjectStore {
  return new ProjectStore(new MemoryKeyValueStore() as never);
}

describe('Project persistence (save / reopen)', () => {
  it('saves and reopens a project', async () => {
    const store = makeStore();
    const plan = createEmptyPlan({ name: 'Test Vale', seed: 42 });
    plan.objects = [{ id: 'o1', kind: 'tree', position: [1, 2, 3] }];

    const saved = await store.saveProject(plan);
    expect(saved.projectId).toBe(plan.id);

    const loaded = await store.loadProject(plan.id);
    expect(loaded).not.toBeNull();
    expect(loaded!.plan.name).toBe('Test Vale');
    expect(loaded!.plan.objects[0].position).toEqual([1, 2, 3]);
  });

  it('lists projects sorted by update time', async () => {
    const store = makeStore();
    await store.saveProject(createEmptyPlan({ name: 'First' }));
    await new Promise((r) => setTimeout(r, 5));
    await store.saveProject(createEmptyPlan({ name: 'Second' }));
    const list = await store.listProjects();
    expect(list.length).toBe(2);
    expect(list[0].name).toBe('Second');
  });

  it('preserves createdAt across saves', async () => {
    const store = makeStore();
    const plan = createEmptyPlan({ name: 'Stable' });
    await store.saveProject(plan);
    const first = await store.loadProject(plan.id);
    await new Promise((r) => setTimeout(r, 5));
    plan.name = 'Stable renamed';
    await store.saveProject(plan);
    const second = await store.loadProject(plan.id);
    expect(second!.record.createdAt).toBe(first!.record.createdAt);
    expect(second!.record.updatedAt).not.toBe(first!.record.updatedAt);
  });

  it('creates and restores checkpoints', async () => {
    const store = makeStore();
    const plan = createEmptyPlan({ name: 'Checkpointed' });
    await store.saveProject(plan);
    const ck = await store.createCheckpoint({ ...plan, name: 'Before change' }, 'manual');
    expect(ck.label).toBe('manual');

    const restored = await store.restoreCheckpoint(ck.id, plan.id);
    expect(restored!.name).toBe('Before change');

    const list = await store.listCheckpoints(plan.id);
    expect(list).toHaveLength(1);
  });

  it('stores and retrieves project data blobs', async () => {
    const store = makeStore();
    const plan = createEmptyPlan();
    await store.saveProject(plan);
    await store.putData(plan.id, 'asset', 'tree.glb', { fake: 'binary' }, { format: 'glb' });
    const data = await store.getData(plan.id, 'asset', 'tree.glb');
    expect(data).toEqual({ fake: 'binary' });
    const all = await store.listData(plan.id);
    expect(all.length).toBe(1);
  });

  it('deletes projects with related data', async () => {
    const store = makeStore();
    const plan = createEmptyPlan();
    await store.saveProject(plan);
    await store.createCheckpoint(plan, 'x');
    await store.putData(plan.id, 'asset', 'a', { v: 1 });
    await store.deleteProject(plan.id);
    expect(await store.loadProject(plan.id)).toBeNull();
    expect(await store.listCheckpoints(plan.id)).toHaveLength(0);
    expect(await store.listData(plan.id)).toHaveLength(0);
  });

  it('returns null for unknown projects', async () => {
    const store = makeStore();
    expect(await store.loadProject('missing')).toBeNull();
  });
});
