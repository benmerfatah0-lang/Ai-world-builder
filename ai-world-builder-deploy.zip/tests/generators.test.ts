import { describe, it, expect } from 'vitest';
import { createEmptyPlan } from '../src/core/types';
import { generateHeightfield, sampleHeight, sampleNormal, heightfieldToJSON, heightfieldFromJSON } from '../src/generators/terrain';
import { scatterWorld, placePropsAround } from '../src/generators/scatter';
import { expandRegion } from '../src/generators/structures';
import { generateWorld, createCancelToken } from '../src/generators/index';

describe('Terrain generation', () => {
  it('produces a deterministic heightfield', () => {
    const plan = createEmptyPlan({ seed: 4242 });
    const h1 = generateHeightfield(plan, 65);
    const h2 = generateHeightfield(plan, 65);
    expect(h1.heights.length).toBe(65 * 65);
    for (let i = 0; i < h1.heights.length; i += 17) {
      expect(h1.heights[i]).toBeCloseTo(h2.heights[i], 8);
    }
  });

  it('different seeds produce different terrain', () => {
    const a = generateHeightfield(createEmptyPlan({ seed: 1 }), 65);
    const b = generateHeightfield(createEmptyPlan({ seed: 2 }), 65);
    let differs = 0;
    for (let i = 0; i < a.heights.length; i += 13) {
      if (Math.abs(a.heights[i] - b.heights[i]) > 0.01) differs++;
    }
    expect(differs).toBeGreaterThan(10);
  });

  it('applies terrain features (mountains raise height)', () => {
    const plan = createEmptyPlan({ seed: 7 });
    const plain = generateHeightfield(plan, 65);
    plan.terrain.features = [{ id: 'm', type: 'mountain', position: [0, 0], radius: 40, height: 60, falloff: 0.5 }];
    const mountain = generateHeightfield(plan, 65);
    const centerH1 = sampleHeight(plain, 0, 0);
    const centerH2 = sampleHeight(mountain, 0, 0);
    expect(centerH2).toBeGreaterThan(centerH1 + 10);
  });

  it('samples height bilinearly and normals have unit length', () => {
    const hf = generateHeightfield(createEmptyPlan({ seed: 5 }), 65);
    const h = sampleHeight(hf, 3.7, -12.2);
    expect(Number.isFinite(h)).toBe(true);
    const n = sampleNormal(hf, 3.7, -12.2);
    const len = Math.hypot(n.x, n.y, n.z);
    expect(len).toBeCloseTo(1, 4);
  });

  it('serializes and restores heightfields', () => {
    const hf = generateHeightfield(createEmptyPlan({ seed: 9 }), 33);
    const json = heightfieldToJSON(hf);
    const restored = heightfieldFromJSON(json);
    expect(restored.resolution).toBe(33);
    expect(restored.heights[10]).toBeCloseTo(hf.heights[10], 6);
  });

  it('supports all generator kinds without NaN', () => {
    for (const generator of ['fbm', 'islands', 'canyons', 'mountains', 'flat'] as const) {
      const plan = createEmptyPlan({ seed: 11 });
      plan.terrain.generator = generator;
      const hf = generateHeightfield(plan, 33);
      for (let i = 0; i < hf.heights.length; i += 7) {
        expect(Number.isFinite(hf.heights[i])).toBe(true);
      }
    }
  });
});

describe('Object placement (scatter)', () => {
  it('places objects deterministically per seed', () => {
    const plan = createEmptyPlan({ seed: 101 });
    const hf = generateHeightfield(plan, 65);
    const r1 = scatterWorld(plan, hf);
    const r2 = scatterWorld(plan, hf);
    expect(r1.clusters.length).toBe(r2.clusters.length);
    for (let i = 0; i < r1.clusters.length; i++) {
      expect(r1.clusters[i].instances?.length).toBe(r2.clusters[i].instances?.length);
    }
  });

  it('does not place vegetation underwater', () => {
    const plan = createEmptyPlan({ seed: 202 });
    const hf = generateHeightfield(plan, 65);
    const result = scatterWorld(plan, hf);
    for (const cluster of result.clusters) {
      if (cluster.kind === 'tree' || cluster.kind === 'bush' || cluster.kind === 'flower') {
        for (const inst of cluster.instances ?? []) {
          expect(inst.position[1]).toBeGreaterThan(hf.waterLevel - 1);
        }
      }
    }
  });

  it('respects density settings', () => {
    const plan = createEmptyPlan({ seed: 303 });
    plan.settings.density.vegetation = 0.05;
    const hf = generateHeightfield(plan, 65);
    const sparse = scatterWorld(plan, hf);
    plan.settings.density.vegetation = 1;
    const dense = scatterWorld(plan, hf);
    const count = (r: ReturnType<typeof scatterWorld>) =>
      r.clusters.reduce((n, c) => n + (c.instances?.length ?? 1), 0);
    expect(count(dense)).toBeGreaterThan(count(sparse));
  });

  it('restricts scatter to a region when asked', () => {
    const plan = createEmptyPlan({ seed: 404 });
    const hf = generateHeightfield(plan, 65);
    const result = scatterWorld(plan, hf, { region: { center: [0, 0], radius: 10 } });
    for (const cluster of result.clusters) {
      for (const inst of cluster.instances ?? []) {
        expect(Math.hypot(inst.position[0], inst.position[2])).toBeLessThan(16);
      }
    }
  });

  it('places props around a center', () => {
    const plan = createEmptyPlan({ seed: 505 });
    const hf = generateHeightfield(plan, 65);
    const props = placePropsAround(plan, hf, [0, 0], 12, ['crate', 'barrel'], 5, 'test');
    expect(props.length).toBeGreaterThan(0);
    for (const p of props) {
      expect(Math.hypot(p.position[0], p.position[2])).toBeLessThan(16);
    }
  });
});

describe('Structure expansion', () => {
  it('expands a village with houses and roads', () => {
    const plan = createEmptyPlan({ seed: 606 });
    plan.settings.density.structures = 0.8;
    const hf = generateHeightfield(plan, 65);
    const region = { id: 'v', kind: 'village' as const, center: [0, 0] as [number, number], radius: 30 };
    const expansion = expandRegion(plan, hf, region);
    const houses = expansion.objects.filter((o) => o.kind === 'house' || o.kind === 'hut');
    expect(houses.length).toBeGreaterThanOrEqual(2);
    expect(expansion.paths.length).toBeGreaterThan(0);
  });

  it('expands a castle with towers and walls', () => {
    const plan = createEmptyPlan({ seed: 707 });
    const hf = generateHeightfield(plan, 65);
    const region = { id: 'c', kind: 'castle' as const, center: [0, 0] as [number, number], radius: 35 };
    const expansion = expandRegion(plan, hf, region);
    expect(expansion.objects.some((o) => o.kind === 'tower')).toBe(true);
    expect(expansion.objects.some((o) => o.kind === 'wall')).toBe(true);
  });

  it('is deterministic per plan seed', () => {
    const plan = createEmptyPlan({ seed: 808 });
    const hf = generateHeightfield(plan, 65);
    const region = { id: 'f', kind: 'farm' as const, center: [5, 5] as [number, number], radius: 25 };
    const e1 = expandRegion(plan, hf, region);
    const e2 = expandRegion(plan, hf, region);
    expect(e1.objects.length).toBe(e2.objects.length);
  });
});

describe('World generation orchestrator', () => {
  it('generates a full world with progress and stats', async () => {
    const plan = createEmptyPlan({ seed: 909 });
    plan.regions = [{ id: 'r', kind: 'village', center: [0, 0], radius: 25 }];
    const phases: string[] = [];
    const result = await generateWorld(plan, (p) => phases.push(p.phase));
    expect(result.heightfield.resolution).toBeGreaterThan(60);
    expect(result.derivedObjects.length).toBeGreaterThan(0);
    expect(result.stats.instanceCount).toBeGreaterThan(0);
    expect(phases).toContain('terrain');
    expect(phases).toContain('scatter');
  });

  it('cancellation throws a CancelledError', async () => {
    const plan = createEmptyPlan({ seed: 111 });
    const token = createCancelToken();
    token.cancelled = true;
    await expect(generateWorld(plan, () => undefined, token)).rejects.toThrow(/cancelled/i);
  });
});
