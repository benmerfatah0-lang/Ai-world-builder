import { describe, it, expect } from 'vitest';
import { mulberry32, rngFrom, hashString, randInt, shuffle, pick } from '../src/core/rng';
import { Noise2D, clamp, smoothstep } from '../src/core/noise';

describe('RNG', () => {
  it('is deterministic for the same seed', () => {
    const a = mulberry32(42);
    const b = mulberry32(42);
    for (let i = 0; i < 100; i++) expect(a()).toBe(b());
  });

  it('produces different sequences for different seeds', () => {
    const a = mulberry32(1);
    const b = mulberry32(2);
    const seqA = Array.from({ length: 10 }, () => a());
    const seqB = Array.from({ length: 10 }, () => b());
    expect(seqA).not.toEqual(seqB);
  });

  it('stays within [0, 1)', () => {
    const r = mulberry32(7);
    for (let i = 0; i < 1000; i++) {
      const v = r();
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThan(1);
    }
  });

  it('hashes strings deterministically', () => {
    expect(hashString('hello')).toBe(hashString('hello'));
    expect(hashString('hello')).not.toBe(hashString('hello!'));
  });

  it('shuffles deterministically', () => {
    const arr = [1, 2, 3, 4, 5, 6, 7, 8];
    const s1 = shuffle(mulberry32(5), arr);
    const s2 = shuffle(mulberry32(5), arr);
    expect(s1).toEqual(s2);
    expect(s1.slice().sort()).toEqual(arr);
  });

  it('randInt stays within bounds', () => {
    const r = mulberry32(9);
    for (let i = 0; i < 200; i++) {
      const v = randInt(r, 3, 7);
      expect(v).toBeGreaterThanOrEqual(3);
      expect(v).toBeLessThanOrEqual(7);
    }
  });

  it('rngFrom accepts string seeds', () => {
    const r1 = rngFrom('world-1');
    const r2 = rngFrom('world-1');
    expect(r1()).toBe(r2());
  });
});

describe('Noise', () => {
  it('is deterministic per seed', () => {
    const n1 = new Noise2D(123);
    const n2 = new Noise2D(123);
    expect(n1.noise(3.4, 7.2)).toBeCloseTo(n2.noise(3.4, 7.2), 10);
    expect(n1.fbm(1.5, 2.5, 4)).toBeCloseTo(n2.fbm(1.5, 2.5, 4), 10);
  });

  it('differs across seeds', () => {
    const n1 = new Noise2D(1);
    const n2 = new Noise2D(2);
    expect(n1.fbm(3.3, 9.1, 4)).not.toBeCloseTo(n2.fbm(3.3, 9.1, 4), 6);
  });

  it('fbm output stays in a sane range', () => {
    const n = new Noise2D(99);
    for (let i = 0; i < 200; i++) {
      const v = n.fbm(i * 0.37, i * 0.51, 5);
      expect(Math.abs(v)).toBeLessThan(2);
    }
  });

  it('ridged noise is non-negative', () => {
    const n = new Noise2D(7);
    for (let i = 0; i < 100; i++) {
      expect(n.ridged(i * 0.2, i * 0.13, 3)).toBeGreaterThanOrEqual(0);
    }
  });

  it('clamp and smoothstep behave', () => {
    expect(clamp(5, 0, 3)).toBe(3);
    expect(clamp(-1, 0, 3)).toBe(0);
    expect(smoothstep(0, 1, -1)).toBe(0);
    expect(smoothstep(0, 1, 2)).toBe(1);
    expect(smoothstep(0, 1, 0.5)).toBeCloseTo(0.5, 5);
  });
});
