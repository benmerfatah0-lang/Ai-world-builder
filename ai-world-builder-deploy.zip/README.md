# AI World Builder

A free-first, Blender-inspired **AI-powered 3D world creation platform**: describe a world in
natural language, watch it planned as an editable **WorldPlan**, generate terrain / vegetation /
structures procedurally, edit everything in a real-time three.js viewport, and export to
**GLB / glTF, Godot, and Unity**.

Runs in modern desktop and mobile browsers and now ships as an **installable PWA**, a
**Capacitor Android project**, and an **Electron desktop project**. Core procedural planning,
editing, local persistence and export work without API keys or paid services; hosted AI and
internet research naturally require a network and optional provider configuration.

---

## Quick start

```bash
npm install
npm run dev          # starts backend (port 8787) + frontend (port 5173) together
```

Open the printed URL (default `http://localhost:5173`). Other scripts:

| Command | What it does |
|---|---|
| `npm run dev` | Backend + Vite dev server (one process tree) |
| `npm run dev:client` | Frontend only |
| `npm run dev:server` | Backend only |
| `npm run build` | Typecheck + production build → `dist/` |
| `npm test` | Run the full test suite (79 tests) |
| `npm run typecheck` | TypeScript only |
| `npm run preview` | Serve the production build |
| `npm run pwa:build` | Build the installable web/PWA version |
| `npm run android:sync` | Build and copy the app into the committed Capacitor Android project |
| `npm run android:open` | Open the Android project in Android Studio |
| `npm run desktop:pack` | Build an unpacked Electron app for the current OS |
| `npm run desktop:dist` | Build an Electron installer/package for the current OS |

See [`PLATFORMS.md`](PLATFORMS.md) for complete PWA, APK and desktop instructions, requirements, security notes and verified limitations.

## Permanent hosting

The production Express server serves both the PWA and `/api` from one origin. A Docker image
and Render Blueprint are included (`Dockerfile`, `render.yaml`). Run `npm run build:deploy`
then `npm run start:deploy` for a production-like local deployment. Arabic step-by-step manual
upload instructions are in [`DEPLOY_AR.md`](DEPLOY_AR.md). The downloadable
`ai-world-builder-deploy.zip` contains the complete source without generated dependencies.

## First steps in the app

1. Type a description in the top prompt bar — e.g.
   *“a snowy mountain village at sunset with a frozen lake and pine forest, low-poly style”* —
   and press **Generate world**.
2. Inspect the result: orbit (drag), pan (right-drag / two-finger), zoom (wheel / pinch).
3. Click any object to select it; move/rotate/scale with the gizmo (**G / R / S**).
4. Use the editor command bar for natural-language edits:
   *“add three pines near the lake”*, *“make it sunset”*, *“increase vegetation density”* —
   every command shows a **preview diff** before it is applied.
5. **Save** (Ctrl+S) stores the project in your browser (IndexedDB). Checkpoints and autosave included.
6. **Export** a GLB scene or a full project package (plan + scene + heightmap + assets +
   Godot/Unity conversion tools + validation reports).

## Optional AI providers (all free-tier friendly, all keys server-side only)

The app is fully functional without keys. To enable hosted AI:

| Provider | Env var (on the server) | Enables |
|---|---|---|
| OpenAI-compatible | `OPENAI_API_KEY` (+ optional `OPENAI_BASE_URL`, `OPENAI_MODEL`) | Remote LLM world planning |
| Anthropic | `ANTHROPIC_API_KEY` (+ optional `ANTHROPIC_MODEL`) | Remote LLM world planning |
| Tripo 3D | `TRIPO_API_KEY` | External text-to-3D and image-to-3D task submission/polling (provider credits may be required) |

Example:

```bash
OPENAI_API_KEY=sk-... TRIPO_API_KEY=... npm run dev
```

**Security:** keys live only in server-side environment variables; the browser talks to
`/api/*` on the same origin and never sees secrets. Unconfigured providers report exactly
that — the app never pretends a model was generated.

**Provider limitations:** Tripo requires an account, API key, network access, and may consume
paid credits. Text-to-3D accepts a prompt. Image-to-3D currently accepts an HTTPS image URL
or an existing Tripo upload token; direct browser image upload and automatic import of the
resulting GLB are not yet implemented. The current adapter uses Tripo v2, which its published
documentation schedules for retirement on 2026-11-01; migration to v3 is the next provider task.

## Tech stack

- **Frontend:** React 18 + TypeScript + Vite, zustand state, three.js viewport (orbit + gizmo
  transforms, instanced scatter, procedural sky/water/lighting)
- **Generators:** deterministic seeded noise terrain (5 generator kinds + terrain features),
  biome-driven scatter with slope/water awareness and spacing constraints, region expansion
  (villages, castles, farms, ruins, temples, graveyards…)
- **AI layer:** pluggable providers — built-in rule-based planner (offline), remote LLM via
  backend, Tripo 3D, procedural modeling; natural-language editor commands with preview diffs
- **Backend:** Express + TypeScript (`server/`) — LLM/Tripo proxy, web research
  (Wikipedia + DuckDuckGo, sources + timestamps), file classification/validation
- **Persistence:** IndexedDB (projects, checkpoints, asset blobs) — no cloud storage needed
- **Export:** GLB via GLTFExporter; project ZIP with WorldPlan (versioned JSON schema),
  heightmap, assets, reports, Godot (`.gd` + docs) and Unity (`.cs` + docs) helpers

## Documentation

- [`PROJECT_CONTEXT.md`](PROJECT_CONTEXT.md) — goals, scope, conventions for continuing work
- [`ARCHITECTURE.md`](ARCHITECTURE.md) — system design, modules, data flow, APIs
- [`PLATFORMS.md`](PLATFORMS.md) — PWA installation, Android/APK and desktop packaging
- [`FEATURE_AUDIT.md`](FEATURE_AUDIT.md) — requirement-by-requirement evidence matrix, limitations, repairs, and priorities
- [`FEATURES.md`](FEATURES.md) — compact implemented-vs-pending overview (the audit is authoritative)
- [`schemas/worldplan.schema.json`](schemas/worldplan.schema.json) — the versioned WorldPlan schema

## Testing

```bash
npm test
```

79 tests cover: seeded RNG/noise determinism, WorldPlan schema validation, plan ops &
undo/redo, terrain generation (all generator kinds, features, serialization), scatter
placement (determinism, underwater exclusion, density, regional restriction), structure
expansion (village/castle/farm), project save/reopen/checkpoints, asset classification,
export validation reports, package ZIP structure, command parsing, and local planning.

The tests do **not** currently automate WebGL rendering, mobile gestures, browser download
behavior, real external-provider calls, or Godot/Unity editor execution. See
[`FEATURE_AUDIT.md`](FEATURE_AUDIT.md) before treating a feature as complete.

## License

Code is provided for this project workspace. Respect the licenses of any asset packs you
import — the app preserves attribution/license metadata per asset.
