import { build } from 'esbuild';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';

execFileSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'build'], { stdio: 'inherit' });
fs.rmSync('desktop-server', { recursive: true, force: true });
fs.mkdirSync('desktop-server', { recursive: true });
await build({
  entryPoints: ['server/index.ts'],
  outfile: 'desktop-server/index.cjs',
  bundle: true,
  platform: 'node',
  target: 'node20',
  format: 'cjs',
  packages: 'bundle',
  sourcemap: false,
});
console.log('Desktop web and API bundles are ready.');
