import { build } from 'esbuild';
import fs from 'node:fs';

fs.rmSync('server-dist', { recursive: true, force: true });
fs.mkdirSync('server-dist', { recursive: true });
await build({
  entryPoints: ['server/index.ts'],
  outfile: 'server-dist/index.cjs',
  bundle: true,
  platform: 'node',
  target: 'node20',
  format: 'cjs',
  packages: 'bundle',
  sourcemap: false,
});
console.log('Production server bundle ready: server-dist/index.cjs');
