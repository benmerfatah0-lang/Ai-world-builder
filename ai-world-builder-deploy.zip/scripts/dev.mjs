#!/usr/bin/env node
/**
 * Starts the backend API server and the Vite dev server together,
 * so `npm run dev` brings up the whole application in one process tree.
 */
import { spawn } from 'node:child_process';

const procs = [];

function run(name, cmd, args) {
  const p = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'], shell: false });
  const prefix = `[${name}]`;
  p.stdout.on('data', (d) => process.stdout.write(`${prefix} ${d}`));
  p.stderr.on('data', (d) => process.stderr.write(`${prefix} ${d}`));
  p.on('exit', (code) => {
    console.log(`${prefix} exited with code ${code}`);
    shutdown(code ?? 0);
  });
  procs.push(p);
  return p;
}

function shutdown(code) {
  for (const p of procs) {
    try { p.kill('SIGTERM'); } catch { /* already gone */ }
  }
  process.exit(code);
}

process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));

run('server', 'npx', ['tsx', 'server/index.ts']);
run('client', 'npx', ['vite']);
