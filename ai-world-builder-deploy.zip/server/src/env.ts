/**
 * Server environment access. Secrets live ONLY here (server-side env vars) —
 * never in frontend bundles, never returned to clients.
 */
export interface ServerEnv {
  port: number;
  openaiApiKey: string | null;
  openaiBaseUrl: string;
  openaiModel: string;
  anthropicApiKey: string | null;
  anthropicModel: string;
  tripoApiKey: string | null;
  maxUploadMb: number;
}

export function loadEnv(): ServerEnv {
  const num = (v: string | undefined, fallback: number): number => {
    const n = v ? parseInt(v, 10) : NaN;
    return Number.isFinite(n) ? n : fallback;
  };
  return {
    port: num(process.env.PORT, 8787),
    openaiApiKey: process.env.OPENAI_API_KEY || null,
    openaiBaseUrl: (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, ''),
    openaiModel: process.env.OPENAI_MODEL || 'gpt-4o-mini',
    anthropicApiKey: process.env.ANTHROPIC_API_KEY || null,
    anthropicModel: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
    tripoApiKey: process.env.TRIPO_API_KEY || null,
    maxUploadMb: num(process.env.MAX_UPLOAD_MB, 64),
  };
}

/** Redacted status — safe to send to the browser. */
export function providerStatus(env: ServerEnv): Record<string, { configured: boolean; detail: string }> {
  return {
    llm: {
      configured: Boolean(env.openaiApiKey || env.anthropicApiKey),
      detail: env.openaiApiKey
        ? `OpenAI-compatible provider ready (model: ${env.openaiModel}).`
        : env.anthropicApiKey
          ? `Anthropic provider ready (model: ${env.anthropicModel}).`
          : 'No LLM API key configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY on the server to enable remote planning; the local planner works without keys.',
    },
    tripo: {
      configured: Boolean(env.tripoApiKey),
      detail: env.tripoApiKey
        ? 'Tripo 3D generation is configured.'
        : 'Tripo 3D is not configured. Set TRIPO_API_KEY on the server for AI mesh generation; procedural modeling and asset import remain available.',
    },
  };
}
