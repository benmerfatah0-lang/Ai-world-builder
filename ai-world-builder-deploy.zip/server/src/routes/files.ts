/**
 * File-processing routes: shared classification + safety checks for uploads.
 * (ZIP extraction happens client-side with the same rules; this endpoint lets
 * other tools classify files server-side and doubles as a validation service.)
 */
import { Router, type Request, type Response } from 'express';
import type { ServerEnv } from '../env.js';
import { classifyFile } from '../../../src/assets/classify.js';

const MAX_FILES_PER_REQUEST = 500;

export function filesRouter(env: ServerEnv): Router {
  const router = Router();

  /** Classify a list of {path, size} entries. */
  router.post('/classify', (req: Request, res: Response) => {
    const entries = Array.isArray(req.body?.files) ? req.body.files : null;
    if (!entries) {
      res.status(400).json({ error: 'files must be an array of { path, size }' });
      return;
    }
    if (entries.length > MAX_FILES_PER_REQUEST) {
      res.status(413).json({ error: `Too many files — max ${MAX_FILES_PER_REQUEST} per request` });
      return;
    }

    const issues: Array<{ path: string; message: string; severity: 'error' | 'warning' }> = [];
    const classified = [];
    for (const entry of entries) {
      const path = String(entry?.path ?? '');
      const size = Number(entry?.size ?? 0);
      if (!path || !Number.isFinite(size)) {
        issues.push({ path: '(invalid entry)', message: 'Each file needs a string path and numeric size.', severity: 'error' });
        continue;
      }
      // Path safety.
      if (path.includes('..') || path.startsWith('/') || /^[a-zA-Z]:/.test(path)) {
        issues.push({ path, message: 'Suspicious path rejected (path traversal guard).', severity: 'error' });
        continue;
      }
      const maxBytes = env.maxUploadMb * 1024 * 1024;
      if (size > maxBytes) {
        issues.push({ path, message: `File exceeds ${env.maxUploadMb} MB server limit.`, severity: 'error' });
        continue;
      }
      const result = classifyFile(path, size);
      if (!result.supported && result.reason) {
        issues.push({ path, message: result.reason, severity: 'warning' });
      }
      classified.push(result);
    }

    res.json({
      classified,
      issues,
      limits: { maxUploadMb: env.maxUploadMb, maxFilesPerRequest: MAX_FILES_PER_REQUEST },
    });
  });

  /** Health/ping for upload tooling. */
  router.get('/limits', (_req: Request, res: Response) => {
    res.json({ maxUploadMb: env.maxUploadMb, maxFilesPerRequest: MAX_FILES_PER_REQUEST });
  });

  return router;
}
