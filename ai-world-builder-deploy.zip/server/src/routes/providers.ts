/**
 * Provider status + research routes.
 */
import { Router, type Request, type Response } from 'express';
import type { ServerEnv } from '../env.js';
import { providerStatus } from '../env.js';
import { searchAll } from '../providers/research.js';

export function providersRouter(env: ServerEnv): Router {
  const router = Router();
  const status = providerStatus(env);

  router.get('/', (_req: Request, res: Response) => {
    res.json({ providers: status });
  });

  router.get('/llm', (_req: Request, res: Response) => {
    res.json(status.llm);
  });

  router.get('/tripo', (_req: Request, res: Response) => {
    res.json(status.tripo);
  });

  return router;
}

export function researchRouter(_env: ServerEnv): Router {
  const router = Router();

  router.post('/search', async (req: Request, res: Response) => {
    const query = String(req.body?.query ?? '').slice(0, 300);
    const limit = Math.min(10, Math.max(2, Number(req.body?.limit) || 6));
    if (!query.trim()) {
      res.status(400).json({ error: 'query is required' });
      return;
    }
    try {
      const { results, errors } = await searchAll(query, limit);
      res.json({ results, errors, query, retrievedAt: new Date().toISOString() });
    } catch (e) {
      res.status(502).json({ error: e instanceof Error ? e.message : String(e) });
    }
  });

  return router;
}
