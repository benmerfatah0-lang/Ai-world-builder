/**
 * Research providers: Wikipedia API (free, no key) + DuckDuckGo HTML (best
 * effort). Every result carries URL + retrieval timestamp; results are checked
 * for relevance before being returned. Respect robots/ToS and rate limits.
 */

export interface ResearchResult {
  id: string;
  title: string;
  url: string;
  snippet: string;
  retrievedAt: string;
  provider: string;
  verified: boolean;
}

const wikiCache = new Map<string, { at: number; results: ResearchResult[] }>();
const CACHE_TTL_MS = 30 * 60 * 1000;

export async function searchWikipedia(query: string, limit = 4): Promise<ResearchResult[]> {
  const key = `wiki:${query.toLowerCase()}`;
  const cached = wikiCache.get(key);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.results;

  const searchUrl = new URL('https://en.wikipedia.org/w/api.php');
  searchUrl.searchParams.set('action', 'query');
  searchUrl.searchParams.set('list', 'search');
  searchUrl.searchParams.set('srsearch', query);
  searchUrl.searchParams.set('srlimit', String(limit));
  searchUrl.searchParams.set('format', 'json');
  searchUrl.searchParams.set('utf8', '1');

  const res = await fetch(searchUrl, {
    headers: { 'User-Agent': 'AIWorldBuilder/0.1 (educational; contact: local)' },
    signal: AbortSignal.timeout(8000),
  });
  if (!res.ok) throw new Error(`Wikipedia search failed (${res.status})`);
  const data = (await res.json()) as {
    query?: { search?: Array<{ title: string; snippet: string; pageid: number }> };
  };

  const results: ResearchResult[] = (data.query?.search ?? []).map((s) => ({
    id: `wiki-${s.pageid}`,
    title: s.title,
    url: `https://en.wikipedia.org/?curid=${s.pageid}`,
    snippet: s.snippet.replace(/<[^>]+>/g, '').slice(0, 320),
    retrievedAt: new Date().toISOString(),
    provider: 'wikipedia',
    verified: true,
  }));

  wikiCache.set(key, { at: Date.now(), results });
  return results;
}

export async function searchDuckDuckGo(query: string, limit = 4): Promise<ResearchResult[]> {
  const url = new URL('https://html.duckduckgo.com/html/');
  url.searchParams.set('q', query);

  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; AIWorldBuilder/0.1; +research)',
      Accept: 'text/html',
    },
    signal: AbortSignal.timeout(8000),
  });
  if (!res.ok) throw new Error(`DuckDuckGo search failed (${res.status})`);
  const html = await res.text();

  // Parse result blocks from the HTML endpoint (class result__a + result__snippet).
  const results: ResearchResult[] = [];
  const re = /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>|<td[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/td>)/g;
  let match: RegExpExecArray | null;
  while ((match = re.exec(html)) && results.length < limit) {
    let href = match[1];
    // DDG wraps redirects: uddg=<encoded>
    const uddg = href.match(/[?&]uddg=([^&]+)/);
    if (uddg) href = decodeURIComponent(uddg[1]);
    if (!/^https?:\/\//.test(href)) continue;
    const title = stripTags(match[2]).slice(0, 140);
    const snippet = stripTags(match[3] ?? match[4] ?? '').slice(0, 320);
    if (!title) continue;
    results.push({
      id: `ddg-${Buffer.from(href).toString('base64').slice(0, 18)}`,
      title,
      url: href,
      snippet,
      retrievedAt: new Date().toISOString(),
      provider: 'duckduckgo',
      verified: false,
    });
  }
  return results;
}

function stripTags(s: string): string {
  return s.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/\s+/g, ' ').trim();
}

export async function searchAll(query: string, limit = 6): Promise<{ results: ResearchResult[]; errors: string[] }> {
  const errors: string[] = [];
  const results: ResearchResult[] = [];

  const [wiki, ddg] = await Promise.allSettled([
    searchWikipedia(query, Math.ceil(limit / 2)),
    searchDuckDuckGo(query, Math.ceil(limit / 2)),
  ]);

  if (wiki.status === 'fulfilled') results.push(...wiki.value);
  else errors.push(`Wikipedia: ${wiki.reason instanceof Error ? wiki.reason.message : wiki.reason}`);

  if (ddg.status === 'fulfilled') results.push(...ddg.value);
  else errors.push(`DuckDuckGo: ${ddg.reason instanceof Error ? ddg.reason.message : ddg.reason}`);

  // Relevance scoring: prefer results whose title/snippet share terms with the query.
  const terms = query.toLowerCase().split(/\W+/).filter((t) => t.length > 2);
  const scored = results.map((r) => {
    const hay = `${r.title} ${r.snippet}`.toLowerCase();
    const score = terms.reduce((n, t) => n + (hay.includes(t) ? 1 : 0), 0);
    return { r, score };
  });
  scored.sort((a, b) => b.score - a.score);

  return { results: scored.slice(0, limit).map((s) => s.r), errors };
}
