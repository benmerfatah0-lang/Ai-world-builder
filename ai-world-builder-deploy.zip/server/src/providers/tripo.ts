/**
 * Tripo 3D provider — real text/image-to-3D via Tripo's REST API (API key on
 * the server only). Returns task status + GLB download URL when available.
 * Docs: https://platform.tripo3d.ai/docs
 */
import type { ServerEnv } from '../env.js';

const TRIPO_BASE = 'https://api.tripo3d.ai/v2/openapi';

export class TripoNotConfiguredError extends Error {
  constructor() {
    super('Tripo 3D is not configured on the server (set TRIPO_API_KEY). Procedural modeling and the asset library remain available.');
    this.name = 'TripoNotConfiguredError';
  }
}

interface TripoTaskResponse {
  code: number;
  data?: {
    task_id: string;
    status: 'queued' | 'running' | 'success' | 'failed' | 'cancelled' | 'banned';
    output?: { model?: string; base_model?: string };
    progress?: number;
  };
  message?: string;
}

export async function startTextTo3D(
  env: ServerEnv,
  prompt: string,
  quality: 'draft' | 'standard' | 'high' = 'standard',
): Promise<{ jobId: string; message: string }> {
  if (!env.tripoApiKey) throw new TripoNotConfiguredError();

  const res = await fetch(`${TRIPO_BASE}/task`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${env.tripoApiKey}`,
    },
    body: JSON.stringify({
      type: 'text_to_model',
      prompt: prompt.slice(0, 1500),
      model_version: quality === 'draft' ? 'v2.0-20240919' : 'v2.5-20250123',
      texture: quality !== 'draft',
      pbr: quality === 'high',
      face_limit: quality === 'draft' ? 5000 : quality === 'high' ? 50000 : 18000,
    }),
    signal: AbortSignal.timeout(15000),
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Tripo task creation failed (${res.status}): ${detail.slice(0, 300)}`);
  }
  const data = (await res.json()) as TripoTaskResponse;
  if (!data.data?.task_id) {
    throw new Error(`Tripo did not return a task id: ${data.message ?? 'unknown error'}`);
  }
  return {
    jobId: data.data.task_id,
    message: `Tripo task ${data.data.task_id} queued (status: ${data.data.status}). Poll /api/ai/text-to-3d/:jobId for the GLB URL.`,
  };
}

export async function startImageTo3D(
  env: ServerEnv,
  input: { imageUrl?: string; fileToken?: string; quality?: 'draft' | 'standard' | 'high' },
): Promise<{ jobId: string; message: string }> {
  if (!env.tripoApiKey) throw new TripoNotConfiguredError();
  if (!input.imageUrl && !input.fileToken) {
    throw new Error('A public imageUrl or Tripo fileToken is required for image-to-3D.');
  }

  const quality = input.quality ?? 'standard';
  const file = input.fileToken
    ? { type: 'jpg', file_token: input.fileToken }
    : { type: inferImageType(input.imageUrl!), url: input.imageUrl };
  const res = await fetch(`${TRIPO_BASE}/task`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${env.tripoApiKey}`,
    },
    body: JSON.stringify({
      type: 'image_to_model',
      file,
      model_version: quality === 'draft' ? 'v2.0-20240919' : 'v2.5-20250123',
      texture: quality !== 'draft',
      pbr: quality === 'high',
      face_limit: quality === 'draft' ? 5000 : quality === 'high' ? 50000 : 18000,
    }),
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Tripo image task creation failed (${res.status}): ${detail.slice(0, 300)}`);
  }
  const data = (await res.json()) as TripoTaskResponse;
  if (!data.data?.task_id) {
    throw new Error(`Tripo did not return an image task id: ${data.message ?? 'unknown error'}`);
  }
  return {
    jobId: data.data.task_id,
    message: `Tripo image task ${data.data.task_id} queued (status: ${data.data.status}). Poll /api/ai/text-to-3d/${data.data.task_id} for the GLB URL.`,
  };
}

function inferImageType(url: string): 'png' | 'jpg' {
  return /\.png(?:$|[?#])/i.test(url) ? 'png' : 'jpg';
}

export async function pollTask(env: ServerEnv, jobId: string): Promise<{
  jobId: string;
  status: 'queued' | 'running' | 'succeeded' | 'failed';
  modelUrl?: string;
  message: string;
  provider: string;
}> {
  if (!env.tripoApiKey) throw new TripoNotConfiguredError();

  const res = await fetch(`${TRIPO_BASE}/task/${encodeURIComponent(jobId)}`, {
    headers: { Authorization: `Bearer ${env.tripoApiKey}` },
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => res.statusText);
    throw new Error(`Tripo task query failed (${res.status}): ${detail.slice(0, 300)}`);
  }
  const data = (await res.json()) as TripoTaskResponse;
  const task = data.data;
  if (!task) throw new Error(`Tripo returned no task data: ${data.message ?? 'unknown error'}`);

  const status = task.status === 'success' ? 'succeeded' : task.status === 'failed' || task.status === 'banned' ? 'failed' : task.status === 'cancelled' ? 'failed' : task.status === 'running' ? 'running' : 'queued';
  return {
    jobId,
    status,
    modelUrl: task.output?.model ?? task.output?.base_model,
    message:
      status === 'succeeded'
        ? 'Model ready — modelUrl points to the GLB produced by Tripo.'
        : status === 'failed'
          ? 'Tripo reported the task failed.'
          : `Task ${task.status} (progress: ${task.progress ?? 0}%).`,
    provider: 'tripo-3d',
  };
}
