/**
 * LLM providers: OpenAI-compatible chat completions and Anthropic messages.
 * Called only from the backend; keys never leave the server.
 */
import type { ServerEnv } from '../env.js';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface LlmResult {
  text: string;
  provider: string;
  model: string;
}

export async function completeChat(env: ServerEnv, messages: ChatMessage[], opts: { json?: boolean } = {}): Promise<LlmResult> {
  if (env.openaiApiKey) {
    return completeOpenAI(env, messages, opts);
  }
  if (env.anthropicApiKey) {
    return completeAnthropic(env, messages, opts);
  }
  throw new LlmNotConfiguredError();
}

export class LlmNotConfiguredError extends Error {
  constructor() {
    super('No LLM API key configured on the server (set OPENAI_API_KEY or ANTHROPIC_API_KEY). The local planner can be used instead.');
    this.name = 'LlmNotConfiguredError';
  }
}

async function completeOpenAI(env: ServerEnv, messages: ChatMessage[], opts: { json?: boolean }): Promise<LlmResult> {
  const res = await fetch(`${env.openaiBaseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${env.openaiApiKey}`,
    },
    body: JSON.stringify({
      model: env.openaiModel,
      messages,
      temperature: 0.4,
      max_tokens: 4000,
      ...(opts.json ? { response_format: { type: 'json_object' } } : {}),
    }),
  });

  if (!res.ok) {
    const detail = await safeText(res);
    throw new Error(`LLM request failed (${res.status}): ${detail}`);
  }
  const data = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
  const text = data.choices?.[0]?.message?.content ?? '';
  return { text, provider: 'openai-compatible', model: env.openaiModel };
}

async function completeAnthropic(env: ServerEnv, messages: ChatMessage[], opts: { json?: boolean }): Promise<LlmResult> {
  const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n');
  const rest = messages.filter((m) => m.role !== 'system');
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': env.anthropicApiKey ?? '',
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: env.anthropicModel,
      max_tokens: 4000,
      system: system || undefined,
      messages: rest.map((m) => ({ role: m.role, content: m.content })),
      ...(opts.json ? undefined : {}),
    }),
  });

  if (!res.ok) {
    const detail = await safeText(res);
    throw new Error(`Anthropic request failed (${res.status}): ${detail}`);
  }
  const data = (await res.json()) as { content?: Array<{ type: string; text?: string }> };
  const text = (data.content ?? []).filter((c) => c.type === 'text').map((c) => c.text ?? '').join('');
  return { text, provider: 'anthropic', model: env.anthropicModel };
}

async function safeText(res: Response): Promise<string> {
  try {
    return (await res.text()).slice(0, 500);
  } catch {
    return res.statusText;
  }
}

/** Extract the first JSON object/array from an LLM response. */
export function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fenced ? fenced[1] : text;
  const startObj = candidate.indexOf('{');
  const startArr = candidate.indexOf('[');
  const start = startObj === -1 ? startArr : startArr === -1 ? startObj : Math.min(startObj, startArr);
  if (start === -1) throw new Error('No JSON found in model response');
  // Try progressively smaller slices to find valid JSON.
  for (let end = candidate.length; end > start; end--) {
    const slice = candidate.slice(start, end).trim();
    if (!slice.endsWith('}') && !slice.endsWith(']')) continue;
    try {
      return JSON.parse(slice);
    } catch {
      /* keep trimming */
    }
  }
  throw new Error('Could not parse JSON from model response');
}
