/**
 * Express app factory. Mounts API routers with JSON limits and CORS for local
 * development. Secrets are never exposed through any route.
 */
import express, { type Express, type Request, type Response, type NextFunction } from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import type { ServerEnv } from './env.js';
import { providerStatus } from './env.js';
import { aiRouter } from './routes/ai.js';
import { providersRouter, researchRouter } from './routes/providers.js';
import { filesRouter } from './routes/files.js';

export function createApp(env: ServerEnv): Express {
  const app = express();

  app.use(cors({ origin: true }));
  app.use(express.json({ limit: '8mb' }));

  // Basic request log (no secrets).
  app.use((req: Request, _res: Response, next: NextFunction) => {
    if (req.path.startsWith('/api')) {
      console.log(`[api] ${req.method} ${req.path}`);
    }
    next();
  });

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      service: 'ai-world-builder-api',
      time: new Date().toISOString(),
      providers: providerStatus(env),
    });
  });

  app.use('/api/ai', aiRouter(env));
  app.use('/api/providers', providersRouter(env));
  app.use('/api/research', researchRouter(env));
  app.use('/api/files', filesRouter(env));

  app.use('/api', (_req: Request, res: Response) => {
    res.status(404).json({ error: 'Unknown API route' });
  });

  // In production the same Express process serves the built PWA. This keeps
  // deployment simple (one service, one URL) and preserves same-origin /api.
  const webRoot = path.resolve(process.cwd(), 'dist');
  if (fs.existsSync(path.join(webRoot, 'index.html'))) {
    app.use(express.static(webRoot, {
      index: false,
      maxAge: '1y',
      immutable: true,
      setHeaders(res, file) {
        if (file.endsWith('sw.js') || file.endsWith('manifest.webmanifest')) {
          res.setHeader('Cache-Control', 'no-cache');
        }
      },
    }));
    app.get('*', (_req: Request, res: Response) => {
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(path.join(webRoot, 'index.html'));
    });
  }

  // JSON error handler — never leak stack traces or secrets.
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    const message = err instanceof Error ? err.message : 'Internal server error';
    console.error('[api] error:', message);
    res.status(500).json({ error: message });
  });

  return app;
}
