/**
 * AI World Builder backend entry point.
 *
 * Responsibilities:
 *  - Hold provider API keys in server-side env vars (never sent to the browser)
 *  - Proxy LLM planning/completion requests (OpenAI-compatible / Anthropic)
 *  - Proxy Tripo text/image-to-3D jobs
 *  - Web research (Wikipedia + DuckDuckGo) with source URLs + timestamps
 *  - File classification/validation service
 *
 * Run: npm run dev:server  (or npm run dev for client+server together)
 */
import { loadEnv } from './src/env.js';
import { createApp } from './src/app.js';

const env = loadEnv();
const app = createApp(env);

app.listen(env.port, '0.0.0.0', () => {
  console.log(`[api] AI World Builder backend listening on http://0.0.0.0:${env.port}`);
  const st = Object.entries(env.openaiApiKey || env.anthropicApiKey ? { llm: 'configured' } : { llm: 'local-only' });
  console.log(`[api] providers: ${st.map(([k, v]) => `${k}=${v}`).join(', ')}, tripo=${env.tripoApiKey ? 'configured' : 'local-only'}`);
});
