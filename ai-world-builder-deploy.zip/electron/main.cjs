const { app, BrowserWindow, shell } = require('electron');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { fork } = require('node:child_process');

let server;
let apiProcess;
const isDev = !app.isPackaged;

function mime(file) {
  const ext = path.extname(file).toLowerCase();
  return ({ '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.glb': 'model/gltf-binary' })[ext] || 'application/octet-stream';
}

function proxyApi(req, res) {
  const proxy = http.request({ hostname: '127.0.0.1', port: 8787, path: req.url, method: req.method, headers: req.headers }, (upstream) => {
    res.writeHead(upstream.statusCode || 502, upstream.headers);
    upstream.pipe(res);
  });
  proxy.on('error', () => {
    res.writeHead(503, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: 'Desktop API is starting. Try again shortly.' }));
  });
  req.pipe(proxy);
}

function startProductionServers() {
  const resources = process.resourcesPath;
  const apiEntry = path.join(resources, 'server', 'index.cjs');
  apiProcess = fork(apiEntry, [], { env: { ...process.env, PORT: '8787' }, stdio: 'pipe' });
  const webRoot = path.join(resources, 'web');
  server = http.createServer((req, res) => {
    if ((req.url || '').startsWith('/api/')) return proxyApi(req, res);
    const clean = decodeURIComponent((req.url || '/').split('?')[0]);
    let file = path.join(webRoot, clean === '/' ? 'index.html' : clean.replace(/^\//, ''));
    if (!file.startsWith(webRoot) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(webRoot, 'index.html');
    res.writeHead(200, { 'content-type': mime(file), 'cache-control': file.endsWith('index.html') ? 'no-cache' : 'public, max-age=31536000' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server.address().port)));
}

async function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 900, minHeight: 600,
    backgroundColor: '#14161a', title: 'AI World Builder',
    webPreferences: { contextIsolation: true, sandbox: true, nodeIntegration: false },
  });
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  if (isDev) await win.loadURL('http://127.0.0.1:5173');
  else await win.loadURL(`http://127.0.0.1:${await startProductionServers()}`);
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
app.on('before-quit', () => { server?.close(); apiProcess?.kill(); });
