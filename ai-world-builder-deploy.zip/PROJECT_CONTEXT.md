# PROJECT_CONTEXT — AI World Builder

> Context for future development sessions. Read this + `ARCHITECTURE.md` before changing code.

## What this project is

A **free-first, Blender-inspired application where AI creates 3D worlds from text
descriptions**. Users can inspect, edit, save, and export worlds to Godot and Unity.
It must work in modern desktop **and Android browsers**.

## Core principles (do not violate)

1. **Free-first** — no paid APIs required for core functionality. Optional paid providers
   (e.g. Tripo, hosted LLMs) are pluggable extras, never dependencies.
2. **Honesty** — never fake working features. If no AI generation provider is configured,
   say so plainly and offer procedural/asset-library alternatives. Every visible control must
   actually work.
3. **Deterministic generation** — the WorldPlan + seed fully determine the generated world.
   Same plan ⇒ same world, in tests and at runtime.
4. **Editable intermediate representation** — AI output is always a validated **WorldPlan**
   JSON document (versioned, `schemas/worldplan.schema.json`) that the user can inspect and
   edit before/while it is executed.
5. **Modular & replaceable** — providers (planner, 3D-gen, research) sit behind interfaces
   in `src/ai/provider.ts`; swapping one must not touch the engine or UI.
6. **Local-first persistence** — projects save to IndexedDB; export/import via files.
   No paid cloud storage.
7. **Security** — API keys only in server-side env vars. Uploads validated (type, size,
   path-traversal guards). No arbitrary code execution.
8. **Preserve what works** — extend, don't rebuild. Keep the test suite green.

## Preserved product specification

Future sessions must preserve and extend—not replace—the existing application. The target is:

- professional text-described 3D worlds with an editable, versioned plan before execution;
- user controls for size, density, quality, style, terrain, biomes, structures, props,
  environment, lighting, atmosphere and points of interest;
- a real-time desktop/mobile viewport with orbit/pan/zoom/view modes, selection,
  transforms, duplication/deletion, hierarchy, assets, properties, materials and terrain tools;
- deterministic procedural terrain/environment/structure generation and non-destructive
  object/region regeneration with progress, cancellation and undo/redo;
- natural-language editor commands with preview-before-apply;
- text-to-3D and image-to-3D through honest replaceable providers, with procedural/library
  fallbacks, materials, optimization/LOD paths and no fake generation;
- safe intelligent ZIP/loose-asset processing: classify, index, preview, preserve originals,
  licensing and errors, then terrain-aligned scale/rotation/spacing-aware placement;
- public web research with URLs/timestamps, verified-vs-inferred distinctions, caching,
  refresh and optional persisted project RAG—without claiming the base model learns;
- IndexedDB projects, autosave, checkpoints and portable project packages;
- validated GLB/glTF export plus documented Godot and Unity conversion workflows;
- backend-only secrets, upload limits/traversal prevention, modular APIs, replaceable
  providers, robust states, tests and future-session documentation.

The authoritative mapping from this specification to actual behavior is
[`FEATURE_AUDIT.md`](FEATURE_AUDIT.md). Never infer completion from UI presence.

## Current state (2026-10-21 audit)

- `npm run typecheck`, `npm test` (**79/79**) and `npm run build` all pass after the audit.
- Dev stack: Express :8787 + Vite :5173 with a same-origin `/api` proxy.
- Runtime-verified previously: frontend/modules, health/provider status, traversal rejection,
  and live DuckDuckGo/Wikipedia research with URLs and timestamps.
- Audit repair: backend `/api/ai/image-to-3d` now exists and accepts a public HTTPS image URL
  or Tripo upload token. Direct browser Blob upload, provider-token upload flow and automatic
  GLB result import remain pending. Tripo is external/keyed and the current v2 adapter must
  migrate before the provider's announced 2026-11-01 v2 retirement.
- Audit repair: both ZIP and loose imports merge asset metadata into the WorldPlan and preserve
  original readable bytes in project-scoped IndexedDB. Loading those files into the scene and
  including stored bytes automatically in package export remain pending.
- Cross-platform integration: installable PWA assets/service worker/install prompt, committed
  Capacitor Android project, and Electron desktop wrapper with bundled Express API are present.
  `PLATFORMS.md` is authoritative for build commands and limitations. Desktop web/API bundles
  and Linux unpacked packaging were verified. Android sync succeeded, but APK compilation in
  this sandbox is blocked by Java 11 (Android Gradle plugin requires JDK 17+). Physical mobile
  GPU/touch testing and signed installers remain release-environment tasks.
- Initial text-to-WorldPlan generation currently executes immediately. Only editor commands
  have Apply/Discard preview. A plan review/editor step is still required to satisfy the full spec.
- Research search works, but results/RAG are not yet persisted per project; server cache is
  process-memory only.
- Unverified in a real browser: WebGL visual correctness, transforms/touch on Android, large
  runtime GLB downloads, and real configured Tripo/LLM calls. Do not report these as verified.

## Key conventions

- **Plan ops** (`src/core/world/planOps.ts`) are the only way the plan changes; every editor
  action becomes an op → undo/redo snapshots → autosave → viewport sync.
- **IDs** come from `newId(prefix)` in `src/core/types.ts`.
- **RNG** is always seeded (`src/core/rng.ts`) — never `Math.random()` in generators.
- **Derived objects** (scatter clusters, region expansions) live outside `plan.objects` in
  app state (`derivedObjects`) but are rendered/exported with the scene. Plan `objects` hold
  user-authored and explicitly committed objects.
- **Validation before use**: any WorldPlan from a remote model is validated
  (`src/core/schema/validate.ts`) before it enters state — client *and* server side.
- CSS is hand-written (`src/styles.css`), dark Blender-like theme, mobile layout via
  `.app` grid + `MobileNav` (breakpoint 960px).

## Environment facts

- Node v20, npm 10. Single package (no monorepo workspaces): `src/` client, `server/` backend,
  `tests/` vitest, `schemas/` JSON schema.
- ~2 GB sandbox RAM — keep the vite build lean; three.js dominates the bundle (~1 MB raw).
- Preview: dev server binds 0.0.0.0:5173 with `allowedHosts: true`; `/api` proxies to 8787.

## Where to continue (see FEATURES.md for full list)

Highest-value next steps (ordered from the full audit):

1. **WorldPlan review stage** — show structured/JSON plan diff after text planning, allow edits,
   then Apply/Generate or Discard. Preserve the current command-preview workflow.
2. **Finish external 3D generation** — migrate Tripo v2→v3, implement bounded validated image
   upload/token acquisition, poll jobs, download GLB before signed URLs expire, save it as an
   asset, and expose generation UI. Keep the procedural fallback.
3. **Imported asset scene pipeline** — parse GLB/OBJ, thumbnails, placeable asset definitions,
   real bounds-based scaling, orientation, terrain alignment and spacing. Package/restore the
   persisted originals. Never overwrite source bytes.
4. **Persistent research/RAG** — project-scoped source library, explicit refresh, selected-source
   planner context, provenance, and separate facts from assumptions.
5. **Terrain and regional tools** — height paint/flatten/smooth, circle/box region selection,
   snapping and non-destructive regeneration semantics.
6. **Browser verification** — Playwright WebGL/persistence/export smoke tests plus physical
   Android touch checks and Godot/Unity converter runs.
7. **Maintenance** — split the large Zustand store into domain slices while preserving APIs;
   add mocked provider contract tests and asset-persistence/package integration tests.
