# ARCHITECTURE — AI World Builder

## System overview

```
┌────────────────────────────── Browser (React + three.js) ─────────────────────────────┐
│                                                                                       │
│  UI (src/ui/*)  ──►  zustand store (src/state/store.ts)  ──►  Viewport (src/engine)   │
│                            │                    │                     │                │
│                            ▼                    ▼                     ▼                │
│                  planOps / history        generators/*          three.js scene         │
│                  (core/world)             (terrain, scatter,    (terrain mesh,         │
│                            │               structures)          instanced scatter,    │
│                            ▼                    │                sky/water/lights)     │
│                  WorldPlan (core/types)  ◄──────┘                                     │
│                            │                                                          │
│        ┌───────────────────┼───────────────────────┐                                   │
│        ▼                   ▼                       ▼                                   │
│  persistence/         ai/ (providers)          export/ & assets/                      │
│  IndexedDB store      local planner,           GLB, project ZIP,                      │
│  (projects,           remote planner,          Godot/Unity helpers,                   │
│  checkpoints,         command parser           ZIP import & classify                  │
│  asset blobs)                                                            │            │
└───────────────────────────────────┬─────────────────────────────────────┘            │
                                    │ fetch /api/* (same origin, Vite proxy in dev)     │
┌───────────────────────────────────▼──────────────────────────────────────────────────┐
│  Backend (Express, server/) — secrets live HERE ONLY                                  │
│  /api/health · /api/ai/plan · /api/ai/complete · /api/ai/text-to-3d[/:id]             │
│  /api/providers/{llm,tripo} · /api/research/search · /api/files/{classify,limits}     │
│                                                                                       │
│  providers/llm.ts (OpenAI-compatible + Anthropic)   providers/tripo.ts (3D gen)        │
│  providers/research.ts (Wikipedia + DuckDuckGo, cached, URL+timestamp per source)     │
└───────────────────────────────────────────────────────────────────────────────────────┘
```

## The WorldPlan — heart of the system

Every feature revolves around the **WorldPlan**: a versioned JSON document
(`schemas/worldplan.schema.json`, `SCHEMA_VERSION = "1.0.0"` in `src/core/types.ts`).

```
WorldPlan
├── schemaVersion, id, name, seed, createdAt/updatedAt
├── settings   { style, size, density, quality, environment(time/weather/fog/sky) }
├── biomes[]   { type, center, radius, weight }
├── terrain    { generator(fbm|islands|canyons|mountains|flat), params, waterLevel, features[] }
├── regions[]  { kind(village|castle|farm|ruins|…), center, radius }   → expanded to structures
├── paths[]    { kind(road|path|river|…), width, points[] }            → terrain ribbons
├── objects[]  { kind, prefab, position/rotation/scale, material, instances[] (scatter clusters) }
├── lighting   { sun/ambient params }
├── assets[]   { name, kind, source, license, attribution, tags }
└── meta       { generator, notes, provenance[] (ai|user|procedural|research) }
```

**Data flow:** prompt → **planner** (local or remote) → WorldPlan → **validation** →
**generator** (heightfield + derived objects) → **viewport** (meshes) → edits as **plan ops**
→ autosave/checkpoints → **export** (GLB / package).

Determinism: generators only consume `plan + seed` via seeded RNG (`mulberry32`) and seeded
noise. `tests/generators.test.ts` enforces this.

## Module map

### `src/core` — engine-agnostic core
| File | Responsibility |
|---|---|
| `types.ts` | WorldPlan types, `createEmptyPlan`, `newId`, `SCHEMA_VERSION` |
| `schema/validate.ts` | Dependency-free WorldPlan validator (mirrors the JSON schema) |
| `world/planOps.ts` | Pure plan operations (the only mutation path) + `diffPlans` for previews |
| `world/history.ts` | Snapshot undo/redo (bounded) |
| `rng.ts`, `noise.ts` | Seeded RNG + value-noise/fbm/ridged noise |
| `events.ts` | Tiny typed emitter |

### `src/generators` — procedural generation
| File | Responsibility |
|---|---|
| `terrain.ts` | Heightfield from terrain spec (5 generators + 10 feature types), sampling, serialization |
| `scatter.ts` | Density/slope/water-aware placement with spacing (“collision-aware”), clustered instanced output |
| `structures.ts` | Region expansion: settlements (houses/roads/props/walls), castles, farms, ruins, temples, graveyards |
| `presets.ts` | Style palettes + biome presets |
| `index.ts` | Orchestrator with progress callbacks + cancellation; regional regeneration |

### `src/engine` — three.js viewport (framework-free)
| File | Responsibility |
|---|---|
| `Viewport.ts` | Renderer/camera/orbit/TransformControls (gizmo), sky shader, sun/ambient, terrain+water, entity sync (unique meshes + `InstancedMesh` clusters), raycast selection, view modes, render loop |
| `entityFactory.ts` | ~50 procedural prefab builders (trees, rocks, houses, towers, props…) + geometry merge for instancing |
| `materials.ts` | Cached palette-driven materials |
| `terrainMesh.ts` | Heightfield → vertex-colored terrain mesh, water plane, path ribbons |

### `src/ai` — pluggable intelligence
| File | Responsibility |
|---|---|
| `provider.ts` | Interfaces: `AIPlannerProvider`, `Asset3DProvider`, `ResearchProvider`, `CommandParser` |
| `localPlanner.ts` | Rule-based NL → WorldPlan (offline default; keyword/phrase inference for biomes, regions, features, style, weather, time, size, density) |
| `remotePlanner.ts` | Backend-backed LLM planner (validated output), Tripo 3D provider, research client |
| `commandParser.ts` | Editor commands (add/remove/style/weather/density/rename/regenerate) → intents → previewable ops |

### `src/state` — `store.ts`
Zustand store: plan + history, derived objects/paths/heightfield, selection, jobs
(cancellable, progress), console log, dialogs, research cache, provider status.
Viewport is driven imperatively via `viewportRef`.

### `src/persistence`
`db.ts` (typed IndexedDB wrapper: projects / checkpoints / projectData blobs),
`projectStore.ts` (save/open/autosave/checkpoints), `memoryStore.ts` (tests/fallback).

### `src/assets` — `classify.ts`, `zipImport.ts`
ZIP/loose-file import: extraction guards (traversal, size budgets), format detection,
tag/attribution/license extraction, unsupported-file reporting.

### `src/export`
`glbExporter.ts` (GLTFExporter + WorldPlan metadata in extras), `packageExporter.ts`
(project ZIP: plan, scene.glb, heightmap, assets+meta, checkpoints, reports, Godot `.gd` +
Unity `.cs` converters + docs), `validate.ts` (per-target capability reports — nothing is
silently lost).

### `server/`
| File | Responsibility |
|---|---|
| `index.ts` / `src/app.ts` | Express bootstrap, JSON limits, CORS, error handler (no secret leakage) |
| `src/env.ts` | Env access + redacted provider status |
| `src/routes/ai.ts` | `/plan` (LLM → validated WorldPlan JSON), `/complete`, `/text-to-3d` (+ poll) |
| `src/routes/providers.ts` | `/providers/{llm,tripo}` status, `/research/search` |
| `src/routes/files.ts` | `/files/classify` (shared classifier), limits |
| `src/providers/llm.ts` | OpenAI-compatible + Anthropic adapters, `extractJson` |
| `src/providers/tripo.ts` | Tripo v2 REST (task create/poll) |
| `src/providers/research.ts` | Wikipedia API + DuckDuckGo HTML (cached, relevance-scored) |

## Frontend ↔ backend API

All calls go to same-origin `/api/*` (Vite proxies to `127.0.0.1:8787` in dev).

| Endpoint | Method | Body / params | Returns |
|---|---|---|---|
| `/api/health` | GET | — | `{ ok, providers }` |
| `/api/ai/plan` | POST | `{ prompt, basePlan?, seed? }` | `{ plan, explanation, assumptions, provider }` (validated) |
| `/api/ai/complete` | POST | `{ prompt, system? }` | `{ text, provider }` |
| `/api/ai/text-to-3d` | POST | `{ prompt, quality? }` | `{ jobId, status, message }` |
| `/api/ai/text-to-3d/:id` | GET | — | `{ status, modelUrl?, message }` |
| `/api/providers/llm` | GET | — | `{ configured, detail }` |
| `/api/providers/tripo` | GET | — | `{ configured, detail }` |
| `/api/research/search` | POST | `{ query, limit? }` | `{ results[{title,url,snippet,retrievedAt,provider,verified}], errors }` |
| `/api/files/classify` | POST | `{ files[{path,size}] }` | `{ classified, issues, limits }` |

Errors: `{ error, code? }` with `code: 'provider-not-configured'` (503) for missing keys —
the UI surfaces this honestly.

## Persistence strategy (no paid cloud)

- **IndexedDB** (`ai-world-builder` DB): `projects` (plan JSON + thumbnail),
  `checkpoints` (snapshots), `projectData` (heightmap Float32 JSON, asset blobs).
- Debounced autosave (2.5 s) + manual save + checkpoints (named snapshots, restore/rebuild).
- **File export/import** for backup and device transfer: WorldPlan JSON and full project ZIP.
- Memory-store fallback when IndexedDB is unavailable (tests).

## Generation jobs & cancellation

`generateWorld()` runs in phases (terrain → regions → scatter → finalize), yielding to the
event loop between phases, reporting `GenerationProgress`, and honoring a `CancelToken`
(`CancelledError`). Jobs appear in the Jobs panel with progress + Cancel.

## Security notes

- API keys only in server env (`server/src/env.ts`); status endpoints return redacted flags.
- Uploads: per-file 64 MB cap, 256 MB unpacked budget, 4000-file cap, path-traversal
  rejection (`..`, absolute paths, drive letters), nested ZIPs refused.
- JSON body limit 8 MB; no server-side code execution from user content.
- Exported packages preserve per-asset license/attribution metadata.

## Testing strategy

Vitest (node env) over pure logic: determinism (RNG/noise/terrain/scatter), schema
validation, plan ops + history, persistence (memory store), asset classification, export
validation + package ZIP structure, command parsing, local planning. The three.js Viewport
is kept framework-free for future headless testing; browser smoke tests remain manual
(see PROJECT_CONTEXT.md).
