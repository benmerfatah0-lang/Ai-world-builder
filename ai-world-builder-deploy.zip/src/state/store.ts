/**
 * App state store (zustand). Single source of truth for project data, UI state,
 * jobs and history. The Viewport is driven imperatively through viewportRef.
 */
import { create } from 'zustand';
import type {
  WorldPlan, WorldObject, PathSpec, Vec3, ArtStyle, Weather, SkyPreset,
} from '../core/types';
import { createEmptyPlan, newId } from '../core/types';
import { validateWorldPlan } from '../core/schema/validate';
import { applyOp, diffPlans, type PlanOp } from '../core/world/planOps';
import { PlanHistory } from '../core/world/history';
import {
  generateWorld, regenerateRegion, createCancelToken, type CancelToken,
  type GenerationProgress, type Heightfield,
} from '../generators/index';
import { generateHeightfield } from '../generators/terrain';
import type { Viewport } from '../engine/Viewport';
import { LocalPlannerProvider } from '../ai/localPlanner';
import { RemotePlannerProvider, WebResearchProvider, ProceduralAssetProvider, TripoAssetProvider } from '../ai/remotePlanner';
import { LocalCommandParser } from '../ai/commandParser';
import type { PlannerOutput, ResearchSource, AIPlannerProvider } from '../ai/provider';
import { ProjectStore } from '../persistence/projectStore';
import { openDatabase, KeyValueStore } from '../persistence/db';
import { MemoryKeyValueStore } from '../persistence/memoryStore';
import { importZipPack, importLooseFiles, type PackImportResult } from '../assets/zipImport';
import { exportSceneToGlb } from '../export/glbExporter';
import { exportProjectPackage } from '../export/packageExporter';
import { placePropsAround } from '../generators/scatter';
import type { ObjectKind } from '../core/types';

export type LogLevel = 'info' | 'success' | 'warn' | 'error';
export interface LogEntry { id: string; ts: string; level: LogLevel; message: string }

export interface Job {
  id: string;
  label: string;
  progress: GenerationProgress | null;
  status: 'running' | 'done' | 'error' | 'cancelled';
  error?: string;
  token?: CancelToken;
  startedAt: number;
  finishedAt?: number;
}

export interface DialogState {
  projects: boolean;
  export: boolean;
  providers: boolean;
  import: boolean;
  research: boolean;
  checkpoints: boolean;
  about: boolean;
}

export interface CommandState {
  text: string;
  lastSummary: string | null;
  lastIntent: string | null;
  pendingPreview: {
    before: WorldPlan;
    after: WorldPlan;
    summary: string[];
  } | null;
}

const history = new PlanHistory(createEmptyPlan());
const planner = new LocalPlannerProvider();
const remotePlanner = new RemotePlannerProvider();
const commandParser = new LocalCommandParser();
const researchProvider = new WebResearchProvider();
const asset3dProviders = [new ProceduralAssetProvider(), new TripoAssetProvider()];

export let projectStore: ProjectStore | null = null;
export let viewportRef: Viewport | null = null;

export function setViewportRef(v: Viewport | null): void {
  viewportRef = v;
}

async function ensureProjectStore(): Promise<ProjectStore> {
  if (projectStore) return projectStore;
  try {
    const db = await openDatabase();
    projectStore = new ProjectStore(new KeyValueStore(db));
  } catch {
    projectStore = new ProjectStore(new MemoryKeyValueStore() as never);
  }
  return projectStore;
}

export interface AppState {
  plan: WorldPlan;
  derivedObjects: WorldObject[];
  derivedPaths: PathSpec[];
  heightfield: Heightfield | null;
  generationStats: { objectCount: number; instanceCount: number; durationMs: number } | null;

  projectId: string | null;
  dirty: boolean;
  lastSaved: string | null;
  saveError: string | null;

  selection: string[];
  transformMode: 'translate' | 'rotate' | 'scale';
  viewMode: 'rendered' | 'solid' | 'wireframe';
  activeMobilePanel: 'viewport' | 'hierarchy' | 'assets' | 'properties' | 'console';
  busy: boolean;

  logs: LogEntry[];
  jobs: Job[];
  dialogs: DialogState;
  command: CommandState;
  research: { query: string; results: ResearchSource[]; searching: boolean; error: string | null };
  importedPack: PackImportResult | null;
  providerStatus: Record<string, { ok: boolean; message: string } | null>;
  worldPrompt: string;

  // core actions
  log(level: LogLevel, message: string): void;
  clearLogs(): void;
  setSelection(ids: string[]): void;
  setTransformMode(mode: 'translate' | 'rotate' | 'scale'): void;
  setViewMode(mode: 'rendered' | 'solid' | 'wireframe'): void;
  setMobilePanel(panel: AppState['activeMobilePanel']): void;
  toggleDialog(name: keyof DialogState, open?: boolean): void;
  setWorldPrompt(text: string): void;

  applyPlanOp(op: PlanOp, opts?: { silent?: boolean }): void;
  undo(): void;
  redo(): void;

  newWorld(): Promise<void>;
  generateWorldFromPrompt(prompt: string): Promise<void>;
  runGeneration(): Promise<void>;
  regenerateSelected(): Promise<void>;
  regenerateArea(center: [number, number], radius: number, kind?: string): Promise<void>;
  refreshDerived(): Promise<void>;

  // object editing
  addObject(kind: ObjectKind, prefab: string, position: Vec3): void;
  duplicateSelection(): void;
  deleteSelection(): void;
  transformObject(id: string, position: Vec3, rotation: Vec3, scale: Vec3 | number, commit: boolean): void;

  // world settings
  setStyle(style: ArtStyle): void;
  setWeather(weather: Weather, sky?: SkyPreset, timeOfDay?: number): void;
  setDensity(target: string, delta: number): void;
  renameWorld(name: string): void;
  setSeed(seed: number): void;

  // commands
  setCommandText(text: string): void;
  runCommand(text: string): Promise<void>;
  applyPendingCommand(): Promise<void>;
  discardPendingCommand(): void;

  // persistence
  saveNow(label?: string): Promise<void>;
  openProject(id: string): Promise<void>;
  listProjectSummaries(): Promise<Awaited<ReturnType<ProjectStore['listProjects']>>>;
  deleteProjectById(id: string): Promise<void>;
  createCheckpointNow(label: string): Promise<void>;
  listCheckpointEntries(): Promise<Awaited<ReturnType<ProjectStore['listCheckpoints']>>>;
  restoreCheckpoint(id: string): Promise<void>;

  // assets
  importPackFile(file: File): Promise<void>;
  importFiles(files: FileList | File[]): Promise<void>;
  clearImportedPack(): void;
  placeAssetPrefab(kind: ObjectKind, prefab: string, at?: Vec3): void;

  // export
  exportGlbFile(): Promise<void>;
  exportPackageFile(): Promise<void>;
  exportPlanJson(): Promise<void>;
  importPlanJson(file: File): Promise<void>;

  // providers
  testProviders(): Promise<void>;
  searchResearch(query: string): Promise<void>;
}

function nowTs(): string {
  return new Date().toISOString();
}

let autosaveTimer: ReturnType<typeof setTimeout> | null = null;

export const useApp = create<AppState>((set, get) => {
  const syncViewport = (): void => {
    const s = get();
    if (!viewportRef || !s.heightfield) return;
    viewportRef.setWorld({
      plan: s.plan,
      heightfield: s.heightfield,
      derivedObjects: s.derivedObjects,
      derivedPaths: s.derivedPaths,
    });
  };

  const scheduleAutosave = (): void => {
    if (autosaveTimer) clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(() => {
      void get().saveNow('autosave');
    }, 2500);
  };

  return {
    plan: history.current,
    derivedObjects: [],
    derivedPaths: [],
    heightfield: null,
    generationStats: null,

    projectId: null,
    dirty: false,
    lastSaved: null,
    saveError: null,

    selection: [],
    transformMode: 'translate',
    viewMode: 'rendered',
    activeMobilePanel: 'viewport',
    busy: false,

    logs: [{ id: newId('log'), ts: nowTs(), level: 'info', message: 'AI World Builder ready. Describe a world and press Generate.' }],
    jobs: [],
    dialogs: { projects: false, export: false, providers: false, import: false, research: false, checkpoints: false, about: false },
    command: { text: '', lastSummary: null, lastIntent: null, pendingPreview: null },
    research: { query: '', results: [], searching: false, error: null },
    importedPack: null,
    providerStatus: {},
    worldPrompt: '',

    log(level, message) {
      set((s) => ({ logs: [...s.logs.slice(-249), { id: newId('log'), ts: nowTs(), level, message }] }));
    },
    clearLogs() {
      set({ logs: [] });
    },

    setSelection(ids) {
      set({ selection: ids });
      viewportRef?.select(ids);
    },
    setTransformMode(mode) {
      set({ transformMode: mode });
      viewportRef?.setTransformMode(mode);
    },
    setViewMode(mode) {
      set({ viewMode: mode });
      viewportRef?.setViewMode(mode);
    },
    setMobilePanel(panel) {
      set({ activeMobilePanel: panel });
    },
    toggleDialog(name, open) {
      set((s) => ({ dialogs: { ...s.dialogs, [name]: open ?? !s.dialogs[name] } }));
    },
    setWorldPrompt(text) {
      set({ worldPrompt: text });
    },

    applyPlanOp(op, opts) {
      const before = get().plan;
      const { plan: after, label } = applyOp(before, op);
      history.commit(after);
      set({ plan: after, dirty: true, selection: get().selection.filter((id) => after.objects.some((o) => o.id === id)) });
      if (!opts?.silent) get().log('info', label);
      syncViewport();
      scheduleAutosave();
    },

    undo() {
      const prev = history.undo();
      if (!prev) return;
      set({ plan: prev, dirty: true });
      get().log('info', 'Undo');
      syncViewport();
      scheduleAutosave();
    },
    redo() {
      const next = history.redo();
      if (!next) return;
      set({ plan: next, dirty: true });
      get().log('info', 'Redo');
      syncViewport();
      scheduleAutosave();
    },

    async newWorld() {
      const plan = createEmptyPlan({ name: 'Untitled World', seed: Math.floor(Math.random() * 0xffffffff) });
      history.reset(plan);
      set({
        plan,
        derivedObjects: [],
        derivedPaths: [],
        heightfield: generateHeightfield(plan),
        projectId: null,
        dirty: false,
        selection: [],
        generationStats: null,
      });
      get().log('success', 'Created a new empty world.');
      syncViewport();
    },

    async generateWorldFromPrompt(prompt) {
      const s = get();
      if (!prompt.trim()) {
        get().log('warn', 'Describe a world first — e.g. "a snowy mountain village at sunset".');
        return;
      }
      set({ busy: true });
      const job = startJob(set, get, 'Planning world from description');
      try {
        let output: PlannerOutput;
        const remoteReady = await remotePlanner.isConfigured();
        if (remoteReady) {
          try {
            output = await remotePlanner.planWorld({ prompt, basePlan: s.plan, seed: s.plan.seed });
            get().log('info', 'Remote LLM produced the WorldPlan.');
          } catch (e) {
            get().log('warn', `Remote LLM failed (${e instanceof Error ? e.message : e}) — using local planner.`);
            output = await planner.planWorld({ prompt, basePlan: s.plan });
          }
        } else {
          output = await planner.planWorld({ prompt, basePlan: s.plan });
        }

        const validation = validateWorldPlan(output.plan);
        if (!validation.valid) {
          const detail = validation.issues.filter((i) => i.severity === 'error').slice(0, 3).map((i) => i.message).join('; ');
          throw new Error(`Generated plan failed validation: ${detail}`);
        }

        history.reset(output.plan);
        set({ plan: output.plan, dirty: true });
        get().log('success', output.explanation);
        for (const a of output.assumptions) get().log('warn', `Assumption: ${a}`);

        await get().runGeneration();
        finishJob(set, get, job.id, 'done');
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        finishJob(set, get, job.id, 'error', msg);
        get().log('error', `Generation failed: ${msg}`);
      } finally {
        set({ busy: false });
      }
    },

    async runGeneration() {
      const s = get();
      set({ busy: true });
      const job = startJob(set, get, 'Generating world');
      const token = createCancelToken();
      set((st) => ({ jobs: st.jobs.map((j) => (j.id === job.id ? { ...j, token } : j)) }));
      try {
        const result = await generateWorld(
          s.plan,
          (p) => {
            set((st) => ({ jobs: st.jobs.map((j) => (j.id === job.id ? { ...j, progress: p } : j)) }));
          },
          token,
          s.heightfield ?? undefined,
        );
        set({
          heightfield: result.heightfield,
          derivedObjects: result.derivedObjects,
          derivedPaths: result.derivedPaths,
          generationStats: result.stats,
          dirty: true,
        });
        get().log('success', `World generated: ${result.stats.objectCount} groups, ${result.stats.instanceCount.toLocaleString()} instances in ${result.stats.durationMs} ms.`);
        finishJob(set, get, job.id, 'done');
        syncViewport();
        scheduleAutosave();
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        finishJob(set, get, job.id, /cancel/i.test(msg) ? 'cancelled' : 'error', msg);
        if (!/cancel/i.test(msg)) get().log('error', `World generation failed: ${msg}`);
      } finally {
        set({ busy: false });
      }
    },

    async refreshDerived() {
      await get().runGeneration();
    },

    async regenerateSelected() {
      const s = get();
      const ids = s.selection;
      if (!ids.length) {
        get().log('warn', 'Select objects or a region to regenerate.');
        return;
      }
      const objects = s.plan.objects.filter((o) => ids.includes(o.id));
      const derived = s.derivedObjects.filter((o) => ids.includes(o.id));
      if (!objects.length && !derived.length) return;

      set({ busy: true });
      const job = startJob(set, get, 'Regenerating selection');
      try {
        // Remove derived groups in the selection and re-run scatter in their area.
        const keepDerived = s.derivedObjects.filter((o) => !ids.includes(o.id));
        const removedObjects = s.plan.objects.filter((o) => !ids.includes(o.id));
        get().applyPlanOp({ type: 'setPlan', plan: { ...s.plan, objects: removedObjects } }, { silent: true });

        const center = centroidOf([...objects, ...derived]);
        const radius = radiusOf([...objects, ...derived], center);
        const result = await regenerateRegion(get().plan, s.heightfield!, { center, radius }, () => undefined);
        set({
          derivedObjects: [...keepDerived, ...result.objects],
          derivedPaths: [...s.derivedPaths.filter((p) => !result.paths.some((np) => np.id === p.id)), ...result.paths],
          dirty: true,
        });
        get().log('success', `Regenerated selection (${result.objects.length} new groups).`);
        finishJob(set, get, job.id, 'done');
        syncViewport();
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        finishJob(set, get, job.id, 'error', msg);
        get().log('error', `Regeneration failed: ${msg}`);
      } finally {
        set({ busy: false });
      }
    },

    async regenerateArea(center, radius, kind) {
      const s = get();
      if (!s.heightfield) return;
      set({ busy: true });
      const job = startJob(set, get, 'Regenerating area');
      try {
        const result = await regenerateRegion(s.plan, s.heightfield, { center, radius, kind }, () => undefined);
        set({ derivedObjects: [...s.derivedObjects, ...result.objects], dirty: true });
        get().log('success', `Area regenerated near (${center[0].toFixed(0)}, ${center[1].toFixed(0)}).`);
        finishJob(set, get, job.id, 'done');
        syncViewport();
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        finishJob(set, get, job.id, 'error', msg);
        get().log('error', `Area regeneration failed: ${msg}`);
      } finally {
        set({ busy: false });
      }
    },

    addObject(kind, prefab, position) {
      const obj: WorldObject = {
        id: newId(kind),
        name: `${kind[0].toUpperCase()}${kind.slice(1)}`,
        kind,
        prefab,
        position,
        rotation: [0, 0, 0],
        scale: 1,
        tags: ['user'],
      };
      get().applyPlanOp({ type: 'addObject', object: obj });
      set({ selection: [obj.id] });
      viewportRef?.select([obj.id]);
    },

    duplicateSelection() {
      const s = get();
      for (const id of s.selection) {
        get().applyPlanOp({ type: 'duplicateObject', id }, { silent: true });
      }
      if (s.selection.length) get().log('info', `Duplicated ${s.selection.length} object(s).`);
    },

    deleteSelection() {
      const s = get();
      if (!s.selection.length) return;
      const ids = s.selection;

      // Derived scatter clusters are stored outside plan.objects.
      const derivedIds = new Set(ids.filter((id) => s.derivedObjects.some((o) => o.id === id)));
      if (derivedIds.size) {
        set({ derivedObjects: s.derivedObjects.filter((o) => !derivedIds.has(o.id)), dirty: true });
      }
      const planIds = ids.filter((id) => !derivedIds.has(id));
      if (planIds.length) {
        get().applyPlanOp({ type: 'removeObjects', ids: planIds }, { silent: true });
      }
      get().log('info', `Deleted ${ids.length} object(s).`);
      set({ selection: [] });
      viewportRef?.select([]);
      syncViewport();
    },

    transformObject(id, position, rotation, scale, commit) {
      const s = get();
      const inPlan = s.plan.objects.some((o) => o.id === id);
      const inDerived = s.derivedObjects.some((o) => o.id === id);
      if (inPlan) {
        if (commit) {
          get().applyPlanOp({ type: 'transformObject', id, position, rotation, scale }, { silent: true });
        } else {
          // Live drag: update present without flooding undo history.
          const next = applyOp(s.plan, { type: 'transformObject', id, position, rotation, scale }).plan;
          history.replacePresent(next);
          set({ plan: next, dirty: true });
        }
      } else if (inDerived) {
        set({
          derivedObjects: s.derivedObjects.map((o) => (o.id === id ? { ...o, position, rotation, scale } : o)),
          dirty: true,
        });
      }
      if (commit) {
        get().log('info', 'Transformed object.');
        scheduleAutosave();
      }
    },

    setStyle(style) {
      get().applyPlanOp({ type: 'setSettings', patch: { style } });
      get().log('success', `Art style set to ${style}.`);
      void get().runGeneration();
    },

    setWeather(weather, sky, timeOfDay) {
      const s = get();
      const env = { ...(s.plan.settings.environment ?? {}), weather };
      if (sky) env.skyPreset = sky;
      if (timeOfDay !== undefined) env.timeOfDay = timeOfDay;
      get().applyPlanOp({ type: 'setSettings', patch: { environment: env } });
      if (timeOfDay !== undefined || sky) {
        get().applyPlanOp({
          type: 'setLighting',
          patch: {
            ...(sky === 'sunset' ? { sunColor: '#ffb27a', sunIntensity: 1.9, ambientColor: '#c98a68' } : {}),
            ...(sky === 'night' ? { sunColor: '#7f93c9', sunIntensity: 0.5, ambientColor: '#2b3a66' } : {}),
            ...(timeOfDay !== undefined ? { sunElevation: elevationForTime(timeOfDay), sunAzimuth: 60 + (timeOfDay / 24) * 240 } : {}),
          },
        }, { silent: true });
      }
      get().log('success', `Environment updated (${weather}${sky ? `, ${sky}` : ''}).`);
    },

    setDensity(target, delta) {
      const s = get();
      const density = { ...s.plan.settings.density };
      const key = target.includes('vegetation') || target.includes('tree') || target.includes('plant')
        ? 'vegetation'
        : target.includes('prop') || target.includes('clutter')
          ? 'props'
          : 'structures';
      density[key] = Math.min(1, Math.max(0, (density[key] ?? 0.5) + delta));
      get().applyPlanOp({ type: 'setSettings', patch: { density } });
      get().log('success', `${key} density → ${(density[key] * 100).toFixed(0)}%. Regenerating…`);
      void get().runGeneration();
    },

    renameWorld(name) {
      get().applyPlanOp({ type: 'renameWorld', name });
    },

    setSeed(seed) {
      get().applyPlanOp({ type: 'setSeed', seed });
      void get().runGeneration();
    },

    setCommandText(text) {
      set((s) => ({ command: { ...s.command, text } }));
    },

    async runCommand(text) {
      const intent = commandParser.parse(text);
      set((s) => ({ command: { ...s.command, lastIntent: intent.intent, lastSummary: intent.summary } }));
      get().log('info', `Command: ${intent.summary} (confidence ${(intent.confidence * 100).toFixed(0)}%)`);

      switch (intent.intent) {
        case 'generate-world':
          await get().generateWorldFromPrompt(String(intent.params.prompt ?? text));
          return;

        case 'set-style': {
          const style = intent.params.style as ArtStyle;
          const after = applyOp(get().plan, { type: 'setSettings', patch: { style } }).plan;
          previewCommand(set, get, after, [`Switch art style to ${style}`, 'World will be regenerated']);
          return;
        }

        case 'set-weather': {
          const { sky, weather, timeOfDay } = intent.params as { sky?: SkyPreset; weather?: Weather; timeOfDay?: number };
          let after = get().plan;
          const env = { ...(after.settings.environment ?? {}) };
          if (sky) env.skyPreset = sky;
          if (weather) env.weather = weather;
          if (timeOfDay !== undefined) env.timeOfDay = timeOfDay;
          after = applyOp(after, { type: 'setSettings', patch: { environment: env } }).plan;
          previewCommand(set, get, after, [`Environment → ${sky ?? weather ?? 'updated'}`]);
          return;
        }

        case 'set-density': {
          const { target, delta } = intent.params as { target: string; delta: number };
          const density = { ...get().plan.settings.density };
          const key = target.includes('vegetation') || target.includes('tree') ? 'vegetation' : target.includes('prop') ? 'props' : 'structures';
          density[key] = Math.min(1, Math.max(0, (density[key] ?? 0.5) + delta));
          const after = applyOp(get().plan, { type: 'setSettings', patch: { density } }).plan;
          previewCommand(set, get, after, [`${key} density → ${(density[key] * 100).toFixed(0)}%`]);
          return;
        }

        case 'rename': {
          const name = String(intent.params.name ?? 'World');
          const after = applyOp(get().plan, { type: 'renameWorld', name }).plan;
          previewCommand(set, get, after, [`Rename to "${name}"`]);
          return;
        }

        case 'add-object': {
          const kind = String(intent.params.kind ?? '');
          const count = Number(intent.params.count ?? 1);
          const near = intent.params.near as string | undefined;
          await applyAddObjectCommand(set, get, kind, count, near);
          return;
        }

        case 'remove-object': {
          const scope = intent.params.scope as string;
          const target = intent.params.target as string;
          const s = get();
          if (scope === 'selection') {
            get().deleteSelection();
          } else {
            const tagOrKind = (o: WorldObject) =>
              target === 'vegetation' ? ['tree', 'bush', 'grass', 'flower', 'cactus'].includes(o.kind)
                : target === 'structure' ? ['house', 'hut', 'tower', 'castle', 'wall', 'temple', 'farm', 'windmill', 'bridge'].includes(o.kind)
                  : target === 'rock' ? o.kind === 'rock'
                    : true;
            const keep = s.plan.objects.filter((o) => !tagOrKind(o));
            const keepDerived = s.derivedObjects.filter((o) => !tagOrKind(o));
            get().applyPlanOp({ type: 'setPlan', plan: { ...s.plan, objects: keep } }, { silent: true });
            set({ derivedObjects: keepDerived });
            get().log('success', `Removed all ${target}.`);
            syncViewport();
          }
          return;
        }

        case 'regenerate-region': {
          if (intent.params.scope === 'world') await get().runGeneration();
          else await get().regenerateSelected();
          return;
        }

        default:
          get().log('warn', intent.summary);
      }
    },

    async applyPendingCommand() {
      const s = get();
      const preview = s.command.pendingPreview;
      if (!preview) return;
      const diff = diffPlans(preview.before, preview.after);
      history.reset(preview.after);
      set({ plan: preview.after, dirty: true, command: { ...s.command, pendingPreview: null } });
      get().log('success', `Applied command (${diff.summary.join(', ')}).`);
      if (diff.settingsChanged || diff.terrainChanged || diff.added.length > 3) {
        await get().runGeneration();
      }
      syncViewport();
      scheduleAutosave();
    },

    discardPendingCommand() {
      set((s) => ({ command: { ...s.command, pendingPreview: null } }));
      get().log('info', 'Command discarded.');
    },

    async saveNow(label = 'save') {
      const s = get();
      try {
        const store = await ensureProjectStore();
        const result = await store.saveProject(s.plan);
        set({ projectId: result.projectId, lastSaved: result.savedAt, dirty: false, saveError: null });
        if (label !== 'autosave') get().log('success', `Project saved locally (IndexedDB) at ${result.savedAt.slice(11, 19)}.`);
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        set({ saveError: msg });
        get().log('error', `Save failed: ${msg}`);
      }
    },

    async openProject(id) {
      try {
        const store = await ensureProjectStore();
        const loaded = await store.loadProject(id);
        if (!loaded) {
          get().log('error', `Project ${id} not found in local storage.`);
          return;
        }
        history.reset(loaded.plan);
        set({
          plan: loaded.plan,
          projectId: id,
          dirty: false,
          selection: [],
          derivedObjects: [],
          derivedPaths: [],
          lastSaved: loaded.record.updatedAt,
        });
        get().log('success', `Opened "${loaded.plan.name}".`);
        await get().runGeneration();
      } catch (e) {
        get().log('error', `Failed to open project: ${e instanceof Error ? e.message : e}`);
      }
    },

    async listProjectSummaries() {
      const store = await ensureProjectStore();
      return store.listProjects();
    },

    async deleteProjectById(id) {
      const store = await ensureProjectStore();
      await store.deleteProject(id);
      get().log('info', 'Project deleted from local storage.');
    },

    async createCheckpointNow(label) {
      const s = get();
      const store = await ensureProjectStore();
      await store.createCheckpoint(s.plan, label || 'manual checkpoint');
      get().log('success', `Checkpoint "${label}" created.`);
    },

    async listCheckpointEntries() {
      const s = get();
      const store = await ensureProjectStore();
      return store.listCheckpoints(s.plan.id);
    },

    async restoreCheckpoint(id) {
      const s = get();
      const store = await ensureProjectStore();
      const plan = await store.restoreCheckpoint(id, s.plan.id);
      if (!plan) {
        get().log('error', 'Checkpoint not found.');
        return;
      }
      history.reset(plan);
      set({ plan, dirty: true });
      get().log('success', 'Checkpoint restored.');
      await get().runGeneration();
    },

    async importPackFile(file) {
      set({ busy: true });
      try {
        const result = await importZipPack(file);
        set({ importedPack: result });
        get().log('success', `Pack "${result.packName}" imported: ${result.stats.supported} supported, ${result.stats.unsupported} unsupported of ${result.stats.total} files.`);
        for (const issue of result.issues.slice(0, 12)) {
          get().log(issue.severity === 'error' ? 'error' : 'warn', `${issue.path}: ${issue.message}`);
        }
        // Merge metadata and preserve each original file in project-scoped IndexedDB.
        // Unsupported originals are retained too, so a package can be recovered or
        // converted externally without destructive import behavior.
        const importedAssets = result.assets.map((a) => ({
          ...a,
          license: result.license ?? a.license,
          attribution: result.attribution ?? a.attribution,
        }));
        get().applyPlanOp({
          type: 'setPlan',
          plan: { ...get().plan, assets: [...(get().plan.assets ?? []), ...importedAssets] },
        }, { silent: true });
        const store = await ensureProjectStore();
        await Promise.all(result.files.map(async (f, index) => {
          if (!f.data) return;
          const asset = importedAssets[index];
          await store.putData(get().plan.id, 'asset', asset?.id ?? f.classified.path, f.data, {
            path: f.classified.path,
            format: f.classified.format,
            supported: f.classified.supported,
            license: result.license,
            attribution: result.attribution,
          });
        }));
        get().log('info', `Preserved ${result.files.filter((f) => f.data).length} original pack files in project storage.`);
      } catch (e) {
        get().log('error', `Import failed: ${e instanceof Error ? e.message : e}`);
      } finally {
        set({ busy: false });
      }
    },

    async importFiles(files) {
      set({ busy: true });
      try {
        const result = await importLooseFiles(files);
        set({ importedPack: result });
        get().log('success', `Imported ${result.stats.total} files (${result.stats.supported} supported).`);
        for (const issue of result.issues.slice(0, 12)) {
          get().log(issue.severity === 'error' ? 'error' : 'warn', `${issue.path}: ${issue.message}`);
        }
        const importedAssets = result.assets.map((a) => ({
          ...a,
          license: result.license ?? a.license,
          attribution: result.attribution ?? a.attribution,
        }));
        get().applyPlanOp({
          type: 'setPlan',
          plan: { ...get().plan, assets: [...(get().plan.assets ?? []), ...importedAssets] },
        }, { silent: true });
        const store = await ensureProjectStore();
        await Promise.all(result.files.map(async (f, index) => {
          if (!f.data) return;
          const asset = importedAssets[index];
          await store.putData(get().plan.id, 'asset', asset?.id ?? f.classified.path, f.data, {
            path: f.classified.path,
            format: f.classified.format,
            supported: f.classified.supported,
            license: result.license,
            attribution: result.attribution,
          });
        }));
        get().log('info', `Preserved ${result.files.filter((f) => f.data).length} original files in project storage.`);
      } catch (e) {
        get().log('error', `Import failed: ${e instanceof Error ? e.message : e}`);
      } finally {
        set({ busy: false });
      }
    },

    clearImportedPack() {
      set({ importedPack: null });
    },

    placeAssetPrefab(kind, prefab, at) {
      const s = get();
      const pos: Vec3 = at ?? [0, viewportRef?.getTerrainHeight(0, 0) ?? 0, 0];
      get().addObject(kind, prefab, pos);
    },

    async exportGlbFile() {
      const s = get();
      if (!viewportRef) {
        get().log('error', 'Viewport not ready.');
        return;
      }
      set({ busy: true });
      try {
        const result = await exportSceneToGlb(viewportRef.scene, s.plan, { binary: true });
        triggerDownload(result.blob, `${safeName(s.plan.name)}.glb`);
        get().log('success', `GLB exported (${(result.bytes / 1024).toFixed(0)} KB, ${result.nodeCount} nodes).`);
      } catch (e) {
        get().log('error', `GLB export failed: ${e instanceof Error ? e.message : e}`);
      } finally {
        set({ busy: false });
      }
    },

    async exportPackageFile() {
      const s = get();
      set({ busy: true });
      try {
        let glb: Blob | null = null;
        try {
          if (viewportRef) glb = (await exportSceneToGlb(viewportRef.scene, s.plan, { binary: true })).blob;
        } catch {
          get().log('warn', 'GLB could not be embedded in the package (scene export failed). Continuing with plan data.');
        }
        const store = await ensureProjectStore();
        const checkpoints = await store.listCheckpoints(s.plan.id);
        const thumbnail = viewportRef?.screenshot() ?? null;
        const result = await exportProjectPackage(s.plan, {
          glb,
          thumbnail,
          heightfield: s.heightfield,
          checkpoints,
        });
        triggerDownload(result.blob, result.filename);
        get().log('success', `Project package exported: ${result.filename} (${(result.blob.size / 1024).toFixed(0)} KB).`);
        for (const w of result.planValidation.issues.filter((i) => i.severity === 'warning').slice(0, 5)) {
          get().log('warn', `Plan validation: ${w.path} — ${w.message}`);
        }
      } catch (e) {
        get().log('error', `Package export failed: ${e instanceof Error ? e.message : e}`);
      } finally {
        set({ busy: false });
      }
    },

    async exportPlanJson() {
      const s = get();
      const blob = new Blob([JSON.stringify(s.plan, null, 2)], { type: 'application/json' });
      triggerDownload(blob, `${safeName(s.plan.name)}-worldplan.json`);
      get().log('success', 'WorldPlan JSON exported.');
    },

    async importPlanJson(file) {
      try {
        const text = await file.text();
        const plan = JSON.parse(text) as WorldPlan;
        const validation = validateWorldPlan(plan);
        if (!validation.valid) {
          const detail = validation.issues.filter((i) => i.severity === 'error').slice(0, 3).map((i) => `${i.path}: ${i.message}`).join('; ');
          get().log('error', `Imported WorldPlan is invalid — ${detail}`);
          return;
        }
        history.reset(plan);
        set({ plan, dirty: true, selection: [] });
        get().log('success', `WorldPlan "${plan.name}" imported and validated.`);
        await get().runGeneration();
      } catch (e) {
        get().log('error', `Could not import plan: ${e instanceof Error ? e.message : e}`);
      }
    },

    async testProviders() {
      const status: Record<string, { ok: boolean; message: string }> = {};
      const checks: Array<[string, () => Promise<{ ok: boolean; message: string }>]> = [
        ['local-planner', () => planner.testConnection()],
        ['remote-llm', () => remotePlanner.testConnection()],
        ['procedural-3d', () => asset3dProviders[0].testConnection()],
        ['tripo-3d', () => asset3dProviders[1].testConnection()],
        ['web-research', async () => ({ ok: true, message: 'Research provider ready (Wikipedia + DuckDuckGo via backend).' })],
      ];
      for (const [id, fn] of checks) {
        try {
          status[id] = await fn();
        } catch (e) {
          status[id] = { ok: false, message: e instanceof Error ? e.message : String(e) };
        }
      }
      set({ providerStatus: status });
      get().log('info', 'Provider connections tested — see Provider Settings.');
    },

    async searchResearch(query) {
      set((s) => ({ research: { ...s.research, query, searching: true, error: null } }));
      try {
        const results = await researchProvider.search(query, 6);
        set((s) => ({ research: { ...s.research, results, searching: false } }));
        get().log('success', `Research: ${results.length} sources for "${query}".`);
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        set((s) => ({ research: { ...s.research, searching: false, error: msg } }));
        get().log('error', `Research failed: ${msg}`);
      }
    },
  };
});

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

function startJob(
  set: (partial: Partial<AppState>) => void,
  get: () => AppState,
  label: string,
): Job {
  const job: Job = {
    id: newId('job'),
    label,
    progress: null,
    status: 'running',
    startedAt: Date.now(),
  };
  set({ jobs: [...get().jobs.slice(-7), job] });
  return job;
}

function finishJob(
  set: (partial: Partial<AppState>) => void,
  get: () => AppState,
  jobId: string,
  status: Job['status'],
  error?: string,
): void {
  set({
    jobs: get().jobs.map((j) =>
      j.id === jobId ? { ...j, status, error, finishedAt: Date.now() } : j,
    ),
  });
}

function previewCommand(
  set: (partial: Partial<AppState>) => void,
  get: () => AppState,
  after: WorldPlan,
  summary: string[],
): void {
  const before = get().plan;
  const s = get();
  set({ command: { ...s.command, pendingPreview: { before, after, summary } } });
  get().log('info', `Preview ready: ${summary.join('; ')}. Apply or discard.`);
}

async function applyAddObjectCommand(
  set: (partial: Partial<AppState>) => void,
  get: () => AppState,
  kindWithOptionalRegion: string,
  count: number,
  near?: string,
): Promise<void> {
  const s = get();
  if (kindWithOptionalRegion.startsWith('region:')) {
    const kind = kindWithOptionalRegion.slice(7) as WorldObject['kind'];
    const center: [number, number] = near ? findNamedLocation(s, near) : [0, 0];
    const after = applyOp(s.plan, {
      type: 'addRegion',
      region: {
        id: newId('region'),
        kind: kind as never,
        name: near ? `Near ${near}` : undefined,
        center,
        radius: 28,
        source: 'user',
      },
    }).plan;
    previewCommand(set, get, after, [`Add ${kind}${near ? ` near ${near}` : ''}`, 'Region will be expanded on apply']);
    return;
  }

  const kind = kindWithOptionalRegion as ObjectKind;
  const center = near ? findNamedLocation(s, near) : [0, 0] as [number, number];
  const objects: WorldObject[] = [];
  for (let i = 0; i < Math.min(count, 12); i++) {
    const angle = (i / Math.max(count, 1)) * Math.PI * 2;
    const r = 2.2 + (i % 3) * 1.4;
    const x = center[0] + Math.cos(angle) * r;
    const z = center[1] + Math.sin(angle) * r;
    const y = viewportRef?.getTerrainHeight(x, z) ?? 0;
    objects.push({
      id: newId(kind),
      name: `${kind} ${i + 1}`,
      kind,
      prefab: defaultPrefabFor(kind),
      position: [Math.round(x * 100) / 100, Math.round(y * 100) / 100, Math.round(z * 100) / 100],
      rotation: [0, (i * 1.1) % (Math.PI * 2), 0],
      scale: 1,
      tags: ['user', 'command'],
    });
  }
  const after = applyOp(s.plan, { type: 'addObjects', objects }).plan;
  previewCommand(set, get, after, [`Add ${objects.length} × ${kind}${near ? ` near ${near}` : ''}`]);
}

function findNamedLocation(s: AppState, name: string): [number, number] {
  const lower = name.toLowerCase();
  const region = (s.plan.regions ?? []).find((r) => (r.name ?? r.kind).toLowerCase().includes(lower));
  if (region) return region.center;
  const feature = (s.plan.terrain.features ?? []).find((f) => f.type.includes(lower));
  if (feature) return feature.position;
  if (lower.includes('lake') || lower.includes('water') || lower.includes('river')) {
    const feat = (s.plan.terrain.features ?? []).find((f) => f.type === 'lake' || f.type === 'river');
    return feat ? feat.position : [0, 0];
  }
  if (lower.includes('center') || lower.includes('middle')) return [0, 0];
  return [0, 0];
}

function defaultPrefabFor(kind: ObjectKind): string {
  const map: Partial<Record<ObjectKind, string>> = {
    tree: 'tree.oak_a', bush: 'bush.small', rock: 'rock.a', grass: 'grass.tuft',
    flower: 'flower.mixed', cactus: 'cactus.tall', crystal: 'crystal.blue',
    mushroom: 'mushroom.red', house: 'structure.house_a', hut: 'structure.hut_a',
    tower: 'structure.tower_round', castle: 'structure.tower_keep',
    bridge: 'structure.bridge', wall: 'structure.wall_segment', fence: 'prop.fence',
    well: 'prop.well', lamp: 'prop.lamp', crate: 'prop.crate', barrel: 'prop.barrel',
    bench: 'prop.bench', campfire: 'prop.campfire', windmill: 'structure.windmill',
    temple: 'structure.temple', ruin: 'structure.ruin_column', farm: 'structure.barn',
    dock: 'prop.bench', boat: 'prop.boat', road: 'prop.crate', path: 'prop.crate',
    custom: 'prop.crate',
  };
  return map[kind] ?? 'prop.crate';
}

function centroidOf(objects: Array<{ position: Vec3 }>): [number, number] {
  if (!objects.length) return [0, 0];
  let x = 0;
  let z = 0;
  for (const o of objects) {
    x += o.position[0];
    z += o.position[2];
  }
  return [x / objects.length, z / objects.length];
}

function radiusOf(objects: Array<{ position: Vec3 }>, center: [number, number]): number {
  let maxR = 8;
  for (const o of objects) {
    const d = Math.hypot(o.position[0] - center[0], o.position[2] - center[1]);
    if (d > maxR) maxR = d;
  }
  return Math.min(maxR + 4, 120);
}

function elevationForTime(t: number): number {
  const x = Math.abs(t - 12) / 12;
  return Math.max(4, 62 * Math.cos(x * Math.PI * 0.5));
}

function safeName(name: string): string {
  return name.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-').toLowerCase() || 'world';
}

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export { planner, remotePlanner, commandParser, researchProvider, asset3dProviders };
export type { ProjectSummary } from '../persistence/projectStore';
