/**
 * LocalPlannerProvider — deterministic natural-language → WorldPlan planning.
 *
 * This is NOT a fake LLM: it is a transparent rule-based planner (keyword +
 * phrase inference) that produces a fully editable WorldPlan. It runs offline,
 * needs no API key, and is the default provider. When a remote provider is
 * configured, the same plan pipeline can be filled by a real model instead.
 */
import type {
  AIPlannerProvider, PlannerInput, PlannerOutput,
} from './provider';
import type {
  WorldPlan, Biome, BiomeType, Region, RegionKind, TerrainFeature, ArtStyle, Vec2, Weather, SkyPreset,
} from '../core/types';
import { createEmptyPlan, newId, SCHEMA_VERSION } from '../core/types';
import { rngFrom, pick, chance, randInt, randRange } from '../core/rng';

interface PlanHints {
  biomes: Set<BiomeType>;
  regions: Array<{ kind: RegionKind; strength: number }>;
  features: Array<TerrainFeature['type']>;
  style?: ArtStyle;
  weather?: Weather;
  sky?: SkyPreset;
  timeOfDay?: number;
  sizeScale: number;
  densityScale: number;
  waterWish: 'none' | 'lake' | 'river' | 'ocean' | 'island';
  named?: string;
  extras: string[];
}

const BIOME_KEYWORDS: Array<[BiomeType, RegExp]> = [
  ['desert', /\b(desert|dune|sahara|arid|sand[y]? desert|oasis)\b/i],
  ['forest', /\b(forest|woodland|woods|jungle|rainforest|trees? everywhere|pine)\b/i],
  ['snow', /\b(snow|snowy|winter|frozen|ice|icy|glacier|arctic|tundra)\b/i],
  ['tundra', /\b(tundra|frost|permafrost)\b/i],
  ['swamp', /\b(swamp|marsh|bog|fen|mangrove|wetland)\b/i],
  ['volcanic', /\b(volcan|lava|magma|ashen|obsidian)\b/i],
  ['canyon', /\b(canyon|mesa|gorge|badlands|cliff[s]?|plateau)\b/i],
  ['mountains', /\b(mountain|mountains|alpine|peak[s]?|himalaya|highlands)\b/i],
  ['hills', /\b(hill[sy]?|rolling|meadow|foothill)\b/i],
  ['beach', /\b(beach|coast|coastal|seaside|shore|tropical)\b/i],
  ['ocean', /\b(ocean|sea|open water|archipelago)\b/i],
  ['island', /\b(island|isles?|atoll|archipelago)\b/i],
  ['river', /\b(river|stream|creek|waterfall)\b/i],
  ['lake', /\b(lake|pond|lagoon)\b/i],
  ['plains', /\b(plains?|grassland|prairie|savanna|field[s]?|countryside)\b/i],
];

const REGION_KEYWORDS: Array<[RegionKind, RegExp]> = [
  ['village', /\b(village|hamlet|small town|settlement|cottage[s]?|homes?)\b/i],
  ['city', /\b(city|metropolis|urban|town\b|streets?|skyscraper)/i],
  ['castle', /\b(castle|fortress|fort|keep|kingdom|medieval)\b/i],
  ['temple', /\b(temple|shrine|sanctuary|monastery|church|cathedral)\b/i],
  ['ruins', /\b(ruins?|ancient|abandoned|crumbling|lost city|archaeolog)/i],
  ['farm', /\b(farm|ranch|barn|crops?|fields of|wheat|harvest|orchard|vineyard)\b/i],
  ['industrial', /\b(factory|industrial|mine|quarry|refinery|warehouse|plant\b)/i],
  ['camp', /\b(camp|campfire|tent|nomad|outpost)\b/i],
  ['harbor', /\b(harbor|harbour|port|dock[s]?|pier|boats?|fishing village)\b/i],
  ['graveyard', /\b(graveyard|cemetery|tomb[s]?|mausoleum)\b/i],
];

const FEATURE_KEYWORDS: Array<[TerrainFeature['type'], RegExp]> = [
  ['mountain', /\b(mountain|peak|summit)\b/i],
  ['hill', /\b(hill|knoll|butte)\b/i],
  ['valley', /\b(valley|dale|glen|hollow)\b/i],
  ['cliff', /\b(cliff|escarpment|overhang)\b/i],
  ['canyon', /\b(canyon|gorge|ravine)\b/i],
  ['crater', /\b(crater|caldera|impact)\b/i],
  ['lake', /\b(lake|pond|lagoon)\b/i],
  ['river', /\b(river|stream|creek)\b/i],
  ['beach', /\b(beach|shoreline|coast)\b/i],
  ['plateau', /\b(plateau|mesa|tableland)\b/i],
];

const STYLE_KEYWORDS: Array<[ArtStyle, RegExp]> = [
  ['voxel', /\b(voxel|minecraft|blocky|block-like)\b/i],
  ['low-poly', /\b(low[- ]?poly|lowpoly|stylized low)\b/i],
  ['cartoon', /\b(cartoon|comic|cel[- ]?shaded|whimsical|pixar)\b/i],
  ['stylized', /\b(stylized|stylised|hand[- ]?painted|painterly|fantasy art)\b/i],
  ['realistic', /\b(realistic|photoreal|photo[- ]?real|cinematic|lifelike|immersive sim)\b/i],
];

const WEATHER_KEYWORDS: Array<[Weather, RegExp]> = [
  ['storm', /\b(storm|stormy|thunder|thunderstorm|lightning|hurricane|tempest)\b/i],
  ['rain', /\b(rain|rainy|downpour|drizzle)\b/i],
  ['snow', /\b(snowing|snowfall|blizzard)\b/i],
  ['fog', /\b(fog|foggy|mist|misty|haze|hazy)\b/i],
  ['cloudy', /\b(cloudy|overcast|gloomy|grey sky|gray sky)\b/i],
  ['clear', /\b(clear sky|sunny|sunshine|clear weather)\b/i],
];

const TIME_KEYWORDS: Array<[number, RegExp]> = [
  [6, /\b(dawn|sunrise|early morning|first light)\b/i],
  [12.5, /\b(noon|midday|noonday)\b/i],
  [18.5, /\b(sunset|dusk|evening|golden hour|twilight)\b/i],
  [22.5, /\b(night|nighttime|midnight|moonlit|starlit|stars)\b/i],
];

const SIZE_KEYWORDS: Array<[number, RegExp]> = [
  [0.55, /\b(tiny|small|cozy|compact|mini)\b/i],
  [1, /\b(medium|normal|standard)\b/i],
  [1.55, /\b(huge|massive|sprawling|vast|enormous|epic|expansive|large|big)\b/i],
];

function extractHints(prompt: string): PlanHints {
  const hints: PlanHints = {
    biomes: new Set(),
    regions: [],
    features: [],
    sizeScale: 1,
    densityScale: 1,
    waterWish: 'none',
    extras: [],
  };

  for (const [type, re] of BIOME_KEYWORDS) if (re.test(prompt)) hints.biomes.add(type);
  for (const [kind, re] of REGION_KEYWORDS) if (re.test(prompt)) hints.regions.push({ kind, strength: 1 });
  for (const [type, re] of FEATURE_KEYWORDS) if (re.test(prompt)) hints.features.push(type);
  for (const [style, re] of STYLE_KEYWORDS) if (re.test(prompt)) hints.style = style;
  // First match wins for weather (keywords are ordered specific → general).
  for (const [weather, re] of WEATHER_KEYWORDS) {
    if (re.test(prompt)) {
      hints.weather = weather;
      break;
    }
  }
  for (const [t, re] of TIME_KEYWORDS) if (re.test(prompt)) hints.timeOfDay = t;
  for (const [scale, re] of SIZE_KEYWORDS) if (re.test(prompt)) hints.sizeScale = scale;

  if (/\b(dense|thick|lush|overgrown|abundant)\b/i.test(prompt)) hints.densityScale = 1.5;
  if (/\b(sparse|barren|empty|desolate|scarce|minimal)\b/i.test(prompt)) hints.densityScale = 0.45;

  if (/\bisland\b/i.test(prompt)) hints.waterWish = 'island';
  else if (/\bocean|sea\b/i.test(prompt)) hints.waterWish = 'ocean';
  else if (/\briver|stream|waterfall\b/i.test(prompt)) hints.waterWish = 'river';
  else if (/\blake|pond|lagoon\b/i.test(prompt)) hints.waterWish = 'lake';

  if (/\bsunset|dusk\b/i.test(prompt)) hints.sky = 'sunset';
  else if (/\bnight|midnight|moonlit|starlit\b/i.test(prompt)) hints.sky = 'night';
  else if (/\bdawn|sunrise\b/i.test(prompt)) hints.sky = 'dawn';
  else if (/\bovercast|gloomy\b/i.test(prompt)) hints.sky = 'overcast';

  const named = prompt.match(/(?:called|named)\s+["']?([A-Z][\w\s'-]{1,40})["']?/);
  if (named) hints.named = named[1].trim().replace(/\s+$/, '');

  // Camera/POI phrases
  if (/\b(view|overlook|panorama|scenic)\b/i.test(prompt)) hints.extras.push('scenic overlook requested');
  if (/\b(snow[- ]?capped|snowy peak)/i.test(prompt)) hints.extras.push('snow-capped peaks requested');

  return hints;
}

function titleFromPrompt(prompt: string, rng: () => number): string {
  const named = prompt.match(/(?:called|named)\s+["']?([A-Z][\w\s'-]{1,40})["']?/);
  if (named) return named[1].trim().replace(/[.,;!?]+$/, '');
  const heads = ['Enchanted', 'Forgotten', 'Emerald', 'Crimson', 'Silent', 'Golden', 'Wild', 'Misty', 'Iron', 'Verdant', 'Ancient', 'Crystal'];
  const tails = ['Vale', 'Hollow', 'Reach', 'Wilds', 'Basin', 'Highlands', 'Shores', 'Realm', 'Expanse', 'Sanctuary', 'Frontier', 'Grove'];
  return `${pick(rng, heads)} ${pick(rng, tails)}`;
}

export class LocalPlannerProvider implements AIPlannerProvider {
  id = 'local-planner';
  name = 'Local Rule-Based Planner';
  kind = 'local' as const;

  describe(): string {
    return 'Transparent, deterministic rule-based planning. Works fully offline. Parses biomes, regions, terrain features, style, weather and scale from your description and produces an editable WorldPlan.';
  }

  async isConfigured(): Promise<boolean> {
    return true;
  }

  async testConnection(): Promise<{ ok: boolean; message: string }> {
    return { ok: true, message: 'Local planner is built in and always available.' };
  }

  async planWorld(input: PlannerInput): Promise<PlannerOutput> {
    const prompt = input.prompt || '';
    const hints = extractHints(prompt + ' ' + (input.imageHints ?? []).map((h) => (h.labels ?? []).join(' ')).join(' '));
    const seed = input.seed ?? hashPrompt(prompt);
    const rng = rngFrom(seed);
    const assumptions: string[] = [];

    const base = input.basePlan ?? createEmptyPlan({ seed });
    const sizeBase = 256 * hints.sizeScale;

    // ---- Biomes ----
    const biomes: Biome[] = [];
    const half = sizeBase / 2;
    const biomeTypes = [...hints.biomes];
    if (!biomeTypes.length) {
      biomeTypes.push('plains');
      assumptions.push('No biome was specified — defaulted to rolling plains.');
    }
    if (biomeTypes.length === 1 && (biomeTypes[0] === 'ocean' || biomeTypes[0] === 'lake')) {
      biomeTypes.push('beach');
    }

    biomeTypes.slice(0, 5).forEach((type, i) => {
      const angle = (i / Math.max(biomeTypes.length, 1)) * Math.PI * 2 + rng() * 0.6;
      const dist = biomeTypes.length === 1 ? 0 : randRange(rng, half * 0.15, half * 0.5);
      biomes.push({
        id: newId('biome'),
        type,
        center: [Math.round(Math.cos(angle) * dist), Math.round(Math.sin(angle) * dist)] as Vec2,
        radius: Math.round(randRange(rng, half * 0.45, half * 0.85)),
        weight: 1,
      });
    });

    // ---- Terrain ----
    const mountains = hints.biomes.has('mountains') || hints.features.includes('mountain');
    const islands = hints.waterWish === 'island' || hints.biomes.has('island');
    const canyons = hints.biomes.has('canyon') || hints.features.includes('canyon');
    const generator = islands ? 'islands' : canyons ? 'canyons' : mountains ? 'mountains' : 'fbm';
    const heightScale = Math.round(48 * (mountains ? 1.6 : 1) * (hints.sizeScale > 1.2 ? 1.15 : 1));

    const waterLevel = hints.waterWish === 'ocean' ? 6 : hints.waterWish === 'island' ? 5 : hints.waterWish === 'lake' ? 3 : 2.5;

    const features: TerrainFeature[] = [];
    const featureTypes = [...new Set(hints.features)];
    for (const ft of featureTypes.slice(0, 6)) {
      const angle = rng() * Math.PI * 2;
      const dist = randRange(rng, 0, half * 0.55);
      const pos: Vec2 = [Math.round(Math.cos(angle) * dist), Math.round(Math.sin(angle) * dist)];
      switch (ft) {
        case 'mountain':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 45, 85)), height: randRange(rng, 35, 70), falloff: 0.55 });
          break;
        case 'hill':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 25, 50)), height: randRange(rng, 8, 18), falloff: 0.6 });
          break;
        case 'valley':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 35, 70)), height: randRange(rng, 12, 24), falloff: 0.5 });
          break;
        case 'cliff':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 30, 55)), height: randRange(rng, 14, 30), falloff: 0.35 });
          break;
        case 'canyon':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 40, 80)), height: randRange(rng, 18, 35), falloff: 0.4 });
          break;
        case 'crater':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 30, 55)), height: randRange(rng, 10, 22), falloff: 0.5 });
          break;
        case 'lake':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 35, 65)), height: 14, falloff: 0.75 });
          break;
        case 'plateau':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 40, 75)), height: randRange(rng, 12, 26), falloff: 0.3 });
          break;
        case 'beach':
          features.push({ id: newId('feat'), type: ft, position: pos, radius: Math.round(randRange(rng, 45, 80)), height: 2, falloff: 0.8 });
          break;
        case 'river': {
          const pts: Vec2[] = [];
          let x = pos[0] - half * 0.5;
          let z = pos[1];
          for (let i = 0; i < 6; i++) {
            pts.push([Math.round(x), Math.round(z)]);
            x += half * 0.2;
            z += (rng() - 0.5) * 40;
          }
          features.push({ id: newId('feat'), type: ft, position: pos, radius: 12, height: 7, falloff: 0.8, params: { points: pts } });
          break;
        }
      }
    }

    if (hints.waterWish === 'river' && !features.some((f) => f.type === 'river')) {
      const pts: Vec2[] = [];
      let z = -half * 0.7;
      for (let i = 0; i < 6; i++) {
        pts.push([Math.round((rng() - 0.5) * half * 0.8), Math.round(z)]);
        z += half * 0.28;
      }
      features.push({ id: newId('feat'), type: 'river', position: pts[2], radius: 11, height: 7, falloff: 0.8, params: { points: pts } });
    }

    // ---- Regions ----
    const regions: Region[] = [];
    const wanted = hints.regions.length ? hints.regions : deriveRegionsFromContext(prompt, hints);
    const placed: Array<Vec2> = [];
    for (const w of wanted.slice(0, 5)) {
      let center: Vec2 = [0, 0];
      let tries = 0;
      do {
        const angle = rng() * Math.PI * 2;
        const dist = randRange(rng, half * 0.1, half * 0.55);
        center = [Math.round(Math.cos(angle) * dist), Math.round(Math.sin(angle) * dist)];
        tries++;
      } while (placed.some((p) => (p[0] - center[0]) ** 2 + (p[1] - center[1]) ** 2 < 55 * 55) && tries < 12);
      placed.push(center);
      regions.push({
        id: newId('region'),
        kind: w.kind,
        name: regionName(w.kind, rng),
        center,
        radius: Math.round(regionRadius(w.kind, hints.sizeScale, rng)),
        source: 'ai',
        params: { fromPrompt: prompt.slice(0, 280) },
      });
    }

    // ---- Assemble plan ----
    const style: ArtStyle = hints.style ?? inferStyleFallback(prompt);
    const env = base.settings.environment ?? {};
    const plan: WorldPlan = {
      schemaVersion: SCHEMA_VERSION,
      id: newId('world'),
      name: hints.named ?? titleFromPrompt(prompt, rng),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      seed,
      settings: {
        style,
        size: {
          widthMeters: Math.round(sizeBase),
          depthMeters: Math.round(sizeBase),
          heightScale,
        },
        density: {
          vegetation: clamp01(0.55 * hints.densityScale),
          props: clamp01(0.5 * hints.densityScale),
          structures: clamp01(0.55 * hints.densityScale),
        },
        quality: base.settings.quality ?? 'standard',
        environment: {
          timeOfDay: hints.timeOfDay ?? env.timeOfDay ?? 10.5,
          weather: hints.weather ?? env.weather ?? 'clear',
          fogDensity: hints.weather === 'fog' ? 0.03 : hints.weather === 'rain' ? 0.012 : 0.006,
          skyPreset: hints.sky ?? (hints.timeOfDay !== undefined ? timeToSky(hints.timeOfDay) : 'day'),
        },
      },
      biomes,
      terrain: {
        generator,
        params: {
          octaves: 5,
          frequency: 0.008 / Math.max(1, hints.sizeScale * 0.75),
          amplitude: heightScale * 0.62,
          ridgeMix: mountains ? 0.6 : canyons ? 0.45 : 0.3,
          persistence: 0.5,
          lacunarity: 2.1,
          terracing: hints.style === 'voxel' ? 12 : 0,
          warpStrength: 0.18,
        },
        waterLevel,
        features,
      },
      regions,
      paths: [],
      objects: [],
      lighting: {
        ...base.lighting,
        sunElevation: elevationForTime(hints.timeOfDay ?? 10.5),
        sunAzimuth: azimuthForTime(hints.timeOfDay ?? 10.5),
        sunColor: hints.sky === 'sunset' || hints.timeOfDay === 18.5 ? '#ffb27a' : '#fff4e0',
        ambientColor: hints.sky === 'night' ? '#2b3a66' : '#9db8d6',
        sunIntensity: hints.sky === 'night' ? 0.45 : 2.4,
        shadows: true,
      },
      assets: [],
      meta: {
        generator: this.id,
        notes: [`Plan derived from prompt: "${prompt.slice(0, 200)}"`],
        provenance: [
          { type: 'ai', detail: `local-planner parsed ${hints.biomes.size} biome hints, ${regions.length} regions`, ts: new Date().toISOString() },
        ],
      },
    };

    if (input.basePlan) {
      // Preserve user's existing objects when refining a plan.
      plan.objects = input.basePlan.objects;
      plan.assets = input.basePlan.assets;
      plan.meta.provenance = [
        ...(input.basePlan.meta.provenance ?? []),
        ...(plan.meta.provenance ?? []),
      ];
    }

    if (hints.extras.length) assumptions.push(...hints.extras);
    if (!hints.style) assumptions.push('No art style specified — defaulted to low-poly (fast and clean for browser rendering).');
    if (!hints.regions.length) assumptions.push('No structures mentioned — added a small camp so the world has a point of interest.');

    const explanation = [
      `Created "${plan.name}" (seed ${seed}).`,
      `Style: ${style}. Size: ${plan.settings.size.widthMeters}×${plan.settings.size.depthMeters} m.`,
      `Biomes: ${biomes.map((b) => b.type).join(', ')}.`,
      `Terrain: ${generator}${features.length ? ` with ${features.length} feature(s)` : ''}, water level ${waterLevel} m.`,
      regions.length ? `Points of interest: ${regions.map((r) => `${r.kind}${r.name ? ` (${r.name})` : ''}`).join(', ')}.` : 'No settlements.',
    ].join(' ');

    return { plan, explanation, assumptions, provider: this.id, usedRemoteModel: false };
  }
}

function deriveRegionsFromContext(prompt: string, hints: PlanHints): Array<{ kind: RegionKind; strength: number }> {
  const out: Array<{ kind: RegionKind; strength: number }> = [];
  if (/\bmedieval|fantasy|kingdom|knight\b/i.test(prompt)) {
    out.push({ kind: 'castle', strength: 1 }, { kind: 'village', strength: 1 });
  } else if (/\bcity|urban|modern\b/i.test(prompt)) {
    out.push({ kind: 'city', strength: 1 });
  } else if (/\b(adventure|explore|exploration|survival)\b/i.test(prompt)) {
    out.push({ kind: 'camp', strength: 1 }, { kind: 'ruins', strength: 1 });
  } else if (hints.biomes.has('desert')) {
    out.push({ kind: 'ruins', strength: 1 });
  } else {
    out.push({ kind: 'camp', strength: 1 });
  }
  return out;
}

function regionName(kind: RegionKind, rng: () => number): string {
  const map: Record<string, string[]> = {
    village: ['Willowbrook', 'Oakvale', 'Stonewick', 'Millhaven', 'Ashford'],
    city: ['Highcastle', 'Ravenport', 'Ironmark', 'Goldengate', 'Stormbay'],
    castle: ['Fort Aldwin', 'Castle Ravenna', 'High Keep', 'Stonehelm', 'The Bulwark'],
    temple: ['Sunspire Shrine', 'Temple of Echoes', 'The Sanctuary', 'Mooncourt'],
    ruins: ['The Forgotten Ruins', 'Broken Spires', 'Elderwatch Ruins', 'Lost Vardun'],
    farm: ['Red Barn Farm', 'Harveststead', 'Greenmeadow', 'Wheatfield'],
    camp: ['Wanderer’s Rest', 'Pioneer Camp', 'Lakeside Camp', 'The Waystation'],
    harbor: ['Tidewatch Harbor', 'Gull’s Rest Port', 'Salty Dock', 'Windward Pier'],
    industrial: ['Ironworks', 'Blackrock Quarry', 'The Foundry', 'Coppermine'],
    graveyard: ['Silent Hollow', 'Restfield', 'Old Churchyard'],
  };
  const names = map[kind] ?? ['Outpost'];
  return pick(rng, names);
}

function regionRadius(kind: RegionKind, sizeScale: number, rng: () => number): number {
  const base = kind === 'city' ? 42 : kind === 'castle' ? 38 : kind === 'village' ? 30 : kind === 'farm' ? 32 : 22;
  return Math.round(base * sizeScale * randRange(rng, 0.85, 1.15));
}

function inferStyleFallback(prompt: string): ArtStyle {
  if (/fantasy|enchanted|fairy/i.test(prompt)) return 'stylized';
  return 'low-poly';
}

function timeToSky(t: number): SkyPreset {
  if (t <= 5 || t >= 21) return 'night';
  if (t <= 8) return 'dawn';
  if (t >= 17) return 'sunset';
  return 'day';
}

function elevationForTime(t: number): number {
  const noon = 12;
  const span = 12;
  const x = Math.abs(t - noon) / span;
  return Math.max(4, 62 * Math.cos(x * Math.PI * 0.5));
}

function azimuthForTime(t: number): number {
  return 60 + (t / 24) * 240;
}

function clamp01(v: number): number {
  return Math.min(1, Math.max(0, Math.round(v * 100) / 100));
}

function hashPrompt(prompt: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < prompt.length; i++) {
    h ^= prompt.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
