/**
 * Natural-language editor commands ("build a medieval village beside this
 * river", "make it sunset", "add three pines near the lake").
 *
 * Parsed locally into structured CommandIntents; execution turns them into
 * plan ops with a previewable diff. A remote LLM can refine these when
 * configured (RemotePlannerProvider.complete), but local parsing always works.
 */
import type { CommandIntent, CommandParser } from './provider';
import type { ObjectKind, ArtStyle, Weather, SkyPreset, RegionKind } from '../core/types';

const OBJECT_WORDS: Array<[ObjectKind, RegExp]> = [
  ['tree', /\b(trees?|pine|pines|oak|oaks|birch|palm|willow|fir|spruce|conifer)\b/i],
  ['house', /\b(houses?|homes?|cottage|cabins?|huts?)\b/i],
  ['tower', /\b(towers?|spire|turret)\b/i],
  ['castle', /\b(castles?|fortress|fort)\b/i],
  ['bridge', /\b(bridges?)\b/i],
  ['rock', /\b(rocks?|boulders?|stones?)\b/i],
  ['bush', /\b(bushes|shrubs?|bush)\b/i],
  ['flower', /\b(flowers?|blossoms?)\b/i],
  ['well', /\b(wells?)\b/i],
  ['lamp', /\b(lamps?|lanterns?|light posts?)\b/i],
  ['campfire', /\b(campfires?|bonfires?|fire pits?)\b/i],
  ['crate', /\b(crates?|boxes)\b/i],
  ['barrel', /\b(barrels?)\b/i],
  ['bench', /\b(benches|bench)\b/i],
  ['fence', /\b(fences?|walls?)\b/i],
  ['cactus', /\b(cactus|cacti)\b/i],
  ['boat', /\b(boats?|canoes?|ships?)\b/i],
  ['windmill', /\b(windmills?)\b/i],
  ['temple', /\b(temples?|shrines?)\b/i],
  ['farm', /\b(farms?|barns?)\b/i],
];

const REGION_WORDS: Array<[RegionKind, RegExp]> = [
  ['village', /\b(village|hamlet|settlement)\b/i],
  ['city', /\b(city|town)\b/i],
  ['castle', /\b(castle|fortress)\b/i],
  ['farm', /\b(farm|ranch)\b/i],
  ['ruins', /\b(ruins?)\b/i],
  ['temple', /\b(temple|shrine)\b/i],
  ['camp', /\b(camp|outpost)\b/i],
  ['harbor', /\b(harbor|harbour|port|dock)\b/i],
];

function countWords(text: string): number {
  const m = text.match(/\b(\d+|one|two|three|four|five|six|seven|eight|nine|ten|a|an|several|many|few)\b/i);
  if (!m) return 1;
  const w = m[1].toLowerCase();
  const nums: Record<string, number> = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, a: 1, an: 1, several: 4, many: 8, few: 3 };
  return nums[w] ?? (parseInt(w, 10) || 1);
}

export class LocalCommandParser implements CommandParser {
  parse(text: string): CommandIntent {
    const t = text.trim();
    const lower = t.toLowerCase();
    if (!t) return { intent: 'unknown', confidence: 0, params: {}, summary: 'Empty command' };

    // --- Weather / sky ---
    if (/\b(sunset|dusk|evening)\b/i.test(t)) {
      return { intent: 'set-weather', confidence: 0.95, params: { sky: 'sunset' satisfies SkyPreset, timeOfDay: 18.5 }, summary: 'Set sky to sunset' };
    }
    if (/\b(sunrise|dawn)\b/i.test(t)) {
      return { intent: 'set-weather', confidence: 0.95, params: { sky: 'dawn', timeOfDay: 6.5 }, summary: 'Set sky to dawn' };
    }
    if (/\b(night|midnight|moonlit|starry)\b/i.test(t)) {
      return { intent: 'set-weather', confidence: 0.95, params: { sky: 'night', timeOfDay: 23 }, summary: 'Set sky to night' };
    }
    if (/\b(noon|midday)\b/i.test(t)) {
      return { intent: 'set-weather', confidence: 0.9, params: { sky: 'day', timeOfDay: 12 }, summary: 'Set time to noon' };
    }
    const weatherM = t.match(/\b(rain|rainy|snow|snowy|fog|foggy|storm|stormy|cloudy|overcast|clear|sunny)\b/i);
    if (weatherM && /\b(weather|sky|make it|set|turn)\b/i.test(t)) {
      const w = weatherM[1].toLowerCase();
      const weatherMap: Record<string, Weather> = {
        rain: 'rain', rainy: 'rain', snow: 'snow', snowy: 'snow', fog: 'fog', foggy: 'fog',
        storm: 'storm', stormy: 'storm', cloudy: 'cloudy', overcast: 'cloudy', clear: 'clear', sunny: 'clear',
      };
      return { intent: 'set-weather', confidence: 0.9, params: { weather: weatherMap[w] }, summary: `Set weather to ${weatherMap[w]}` };
    }

    // --- Style ---
    const styleM = t.match(/\b(low[- ]?poly|voxel|realistic|stylized|stylised|cartoon)\b/i);
    if (styleM && /\b(style|look|art|render|make (it|the world)|switch to|change to)\b/i.test(t)) {
      const s = styleM[1].toLowerCase().replace(/\s+/g, '-');
      const style = (s === 'stylised' ? 'stylized' : s) as ArtStyle;
      return { intent: 'set-style', confidence: 0.92, params: { style }, summary: `Switch art style to ${style}` };
    }

    // --- Density ---
    const densM = t.match(/\b(density|vegetation|trees|props|clutter)\b/i);
    if (densM && /\b(increase|decrease|more|less|denser|sparser|boost|reduce|double|half)\b/i.test(t)) {
      const dir = /\b(increase|more|denser|boost|double)\b/i.test(t) ? 1 : -1;
      return {
        intent: 'set-density',
        confidence: 0.85,
        params: { delta: dir * 0.2, target: densM[1].toLowerCase() },
        summary: `${dir > 0 ? 'Increase' : 'Decrease'} ${densM[1].toLowerCase()} density`,
      };
    }

    // --- Rename ---
    const renameM = t.match(/^(?:rename (?:the )?world(?: to)?|call (?:it|the world)|name (?:it|the world))\s+["']?([^"']+)["']?$/i);
    if (renameM) {
      return { intent: 'rename', confidence: 0.98, params: { name: renameM[1].trim() }, summary: `Rename world to "${renameM[1].trim()}"` };
    }

    // --- Remove ---
    if (/^(delete|remove|clear|get rid of)\b/i.test(t)) {
      const target = detectRemoveTarget(t);
      return {
        intent: 'remove-object',
        confidence: 0.85,
        params: { target: target.target, scope: target.scope },
        summary: `Remove ${target.scope === 'all' ? 'all ' : ''}${target.target}`,
      };
    }

    // --- Regenerate region ---
    if (/\b(regenerate|rebuild|redo|re-roll)\b/i.test(t)) {
      return {
        intent: 'regenerate-region',
        confidence: 0.8,
        params: { scope: /\b(everything|whole|entire world)\b/i.test(t) ? 'world' : 'selection' },
        summary: 'Regenerate selection / region',
      };
    }

    // --- World generation (top-level prompts take precedence) ---
    if (/^(generate|design|imagine|create a world|make me a world|generate me)\b/i.test(t)) {
      return {
        intent: 'generate-world',
        confidence: 0.85,
        params: { prompt: t },
        summary: 'Generate world from description',
      };
    }

    // --- Add objects ---
    for (const [kind, re] of OBJECT_WORDS) {
      if (re.test(t) && /\b(add|place|put|spawn|grow|build|scatter|plant|create)\b/i.test(t)) {
        const near = t.match(/\b(?:near|beside|by|next to|at|around|along)\b\s+(?:the\s+)?([\w\s]{2,30})/i);
        return {
          intent: 'add-object',
          confidence: 0.88,
          params: {
            kind,
            count: countWords(t),
            near: near ? near[1].trim() : undefined,
          },
          summary: `Add ${countWords(t)} × ${kind}${near ? ` near ${near[1].trim()}` : ''}`,
        };
      }
    }

    // --- Add region / generate world ---
    for (const [kind, re] of REGION_WORDS) {
      if (re.test(t) && /\b(build|add|create|place|generate|make)\b/i.test(t)) {
        const near = t.match(/\b(?:near|beside|by|next to|along)\b\s+(?:the\s+)?([\w\s]{2,30})/i);
        return {
          intent: 'add-object',
          confidence: 0.8,
          params: { kind: `region:${kind}`, count: 1, near: near ? near[1].trim() : undefined },
          summary: `Add a ${kind}${near ? ` beside ${near[1].trim()}` : ''}`,
        };
      }
    }

    if (/^(generate|create|build|make|design)\b/i.test(t)) {
      return {
        intent: 'generate-world',
        confidence: 0.75,
        params: { prompt: t },
        summary: 'Generate world from description',
      };
    }

    return {
      intent: 'unknown',
      confidence: 0.2,
      params: { prompt: t },
      summary: 'Unrecognized command — try "generate a snowy mountain village at sunset"',
    };
  }
}

function detectRemoveTarget(t: string): { target: string; scope: 'all' | 'selection' } {
  if (/\b(all|every|entire)\b/i.test(t)) {
    if (/\b(trees?|vegetation|plants?)\b/i.test(t)) return { target: 'vegetation', scope: 'all' };
    if (/\b(rocks?|stones?)\b/i.test(t)) return { target: 'rock', scope: 'all' };
    if (/\b(buildings?|houses?|structures?)\b/i.test(t)) return { target: 'structure', scope: 'all' };
    if (/\b(props?|clutter|objects?)\b/i.test(t)) return { target: 'prop', scope: 'all' };
    return { target: 'objects', scope: 'all' };
  }
  return { target: 'selection', scope: 'selection' };
}
