/**
 * AI provider interfaces. All providers are pluggable and replaceable;
 * the app works fully offline with the LocalPlannerProvider.
 */
import type { WorldPlan, ArtStyle, BiomeType, RegionKind, WorldObject, Vec3 } from '../core/types';

export interface PlannerInput {
  prompt: string;
  /** Optional reference image descriptors (filenames + detected colors/labels). */
  imageHints?: Array<{ filename: string; labels?: string[]; dominantColors?: string[] }>;
  /** Optional asset pack descriptors for matching. */
  assetHints?: Array<{ name: string; kind: string; tags?: string[] }>;
  basePlan?: WorldPlan;
  seed?: number;
}

export interface PlannerOutput {
  plan: WorldPlan;
  /** Natural-language explanation of what the planner decided. */
  explanation: string;
  /** Details the planner inferred but could not confirm — surfaced in the UI. */
  assumptions: string[];
  provider: string;
  /** true when the plan came from a real remote AI model vs. local heuristics. */
  usedRemoteModel: boolean;
}

export interface AIPlannerProvider {
  id: string;
  name: string;
  kind: 'local' | 'remote';
  describe(): string;
  isConfigured(): Promise<boolean>;
  testConnection(): Promise<{ ok: boolean; message: string }>;
  planWorld(input: PlannerInput): Promise<PlannerOutput>;
  /** Optional free-form completion used by natural-language editor commands. */
  complete?(prompt: string, system?: string): Promise<string>;
}

export interface TextTo3DRequest {
  prompt: string;
  style?: ArtStyle;
  /** In-memory references are useful to local providers. Hosted providers require
   * an uploaded file token or a public URL; blobs are never silently discarded. */
  referenceImages?: Blob[];
  imageUrl?: string;
  imageFileToken?: string;
  quality?: 'draft' | 'standard' | 'high';
}

export interface TextTo3DResult {
  jobId: string;
  status: 'queued' | 'running' | 'succeeded' | 'failed';
  /** URL or blob reference to the produced model (GLB) when succeeded. */
  modelUrl?: string;
  message: string;
  provider: string;
}

export interface Asset3DProvider {
  id: string;
  name: string;
  describe(): string;
  isConfigured(): Promise<boolean>;
  testConnection(): Promise<{ ok: boolean; message: string }>;
  textTo3D(req: TextTo3DRequest, onProgress?: (msg: string) => void): Promise<TextTo3DResult>;
  imageTo3D?(req: TextTo3DRequest, onProgress?: (msg: string) => void): Promise<TextTo3DResult>;
}

export interface ResearchSource {
  id: string;
  title: string;
  url: string;
  snippet: string;
  /** ISO timestamp of retrieval. */
  retrievedAt: string;
  provider: string;
  verified: boolean;
}

export interface ResearchProvider {
  id: string;
  name: string;
  describe(): string;
  isConfigured(): Promise<boolean>;
  search(query: string, limit?: number): Promise<ResearchSource[]>;
}

export interface CommandIntent {
  intent:
    | 'generate-world'
    | 'add-object'
    | 'remove-object'
    | 'set-style'
    | 'set-weather'
    | 'set-time'
    | 'set-density'
    | 'regenerate-region'
    | 'rename'
    | 'unknown';
  confidence: number;
  params: Record<string, unknown>;
  /** Human summary shown in the command bar. */
  summary: string;
}

export interface CommandParser {
  parse(text: string): CommandIntent;
}

export type { WorldPlan, WorldObject, Vec3, BiomeType, RegionKind, ArtStyle };
