/**
 * Remote AI providers call the backend (`/api/ai/*`), which holds API keys in
 * server-side environment variables. Nothing secret ever reaches the browser.
 * If the backend is unreachable or no key is configured these providers report
 * that honestly — they never fabricate a model response.
 */
import type { AIPlannerProvider, PlannerInput, PlannerOutput, Asset3DProvider, TextTo3DRequest, TextTo3DResult, ResearchProvider, ResearchSource } from './provider';
import { createEmptyPlan, type WorldPlan } from '../core/types';
import { validateWorldPlan } from '../core/schema/validate';

const API_BASE = String(import.meta.env.VITE_API_BASE_URL ?? '').replace(/\/$/, '');

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.error ?? body.message ?? detail;
    } catch { /* keep statusText */ }
    throw new Error(`${path} failed (${res.status}): ${detail}`);
  }
  return res.json() as Promise<T>;
}

export class RemotePlannerProvider implements AIPlannerProvider {
  id = 'remote-llm';
  name: string;
  kind = 'remote' as const;

  constructor(providerId = 'openai-compatible', name = 'Remote LLM (via backend)') {
    this.id = `remote-llm:${providerId}`;
    this.name = name;
  }

  describe(): string {
    return 'Calls a hosted LLM through the backend proxy. Requires an API key in the server environment (e.g. OPENAI_API_KEY or ANTHROPIC_API_KEY). Produces structured WorldPlan JSON which is validated before use.';
  }

  async isConfigured(): Promise<boolean> {
    try {
      const info = await api<{ configured: boolean }>('/api/providers/llm');
      return info.configured;
    } catch {
      return false;
    }
  }

  async testConnection(): Promise<{ ok: boolean; message: string }> {
    try {
      const info = await api<{ configured: boolean; message: string }>('/api/providers/llm');
      return { ok: info.configured, message: info.message };
    } catch (e) {
      return { ok: false, message: e instanceof Error ? e.message : 'Backend unreachable' };
    }
  }

  async planWorld(input: PlannerInput): Promise<PlannerOutput> {
    const result = await api<{ plan: unknown; explanation: string; assumptions: string[]; provider: string }>('/api/ai/plan', {
      method: 'POST',
      body: JSON.stringify({ prompt: input.prompt, basePlan: input.basePlan ?? null, seed: input.seed ?? null }),
    });

    const validation = validateWorldPlan(result.plan);
    if (!validation.valid) {
      const detail = validation.issues.filter((i) => i.severity === 'error').slice(0, 3).map((i) => `${i.path}: ${i.message}`).join('; ');
      throw new Error(`Remote model returned an invalid WorldPlan (${detail}). Falling back to the local planner is recommended.`);
    }

    return {
      plan: result.plan as WorldPlan,
      explanation: result.explanation,
      assumptions: result.assumptions ?? [],
      provider: result.provider,
      usedRemoteModel: true,
    };
  }

  async complete(prompt: string, system?: string): Promise<string> {
    const result = await api<{ text: string }>('/api/ai/complete', {
      method: 'POST',
      body: JSON.stringify({ prompt, system }),
    });
    return result.text;
  }
}

export class ProceduralAssetProvider implements Asset3DProvider {
  id = 'procedural-3d';
  name = 'Procedural Modeling (built-in)';
  describe(): string {
    return 'Builds simple parameterized 3D models locally from primitives (trees, houses, rocks, props). Always available, offline, and exports to GLB like any other asset. Not an AI mesh generator — honest about its output.';
  }
  async isConfigured(): Promise<boolean> {
    return true;
  }
  async testConnection(): Promise<{ ok: boolean; message: string }> {
    return { ok: true, message: 'Procedural modeling is built in.' };
  }
  async textTo3D(req: TextTo3DRequest): Promise<TextTo3DResult> {
    return {
      jobId: `proc-${Date.now()}`,
      status: 'succeeded',
      message: `Procedural provider generates parameterized models from the asset library catalog (see Asset Browser → Procedural). Prompt "${req.prompt}" is used to select a prefab family; fine-grained AI mesh generation requires a configured generation provider.`,
      provider: this.id,
    };
  }
}

export class TripoAssetProvider implements Asset3DProvider {
  id = 'tripo-3d';
  name = 'Tripo 3D (via backend)';
  describe(): string {
    return 'Text-to-3D and image-to-3D through Tripo’s API, proxied by the backend. Requires TRIPO_API_KEY in the server environment. Results arrive as GLB models that are imported into the asset library.';
  }
  async isConfigured(): Promise<boolean> {
    try {
      const info = await api<{ configured: boolean }>('/api/providers/tripo');
      return info.configured;
    } catch {
      return false;
    }
  }
  async testConnection(): Promise<{ ok: boolean; message: string }> {
    try {
      const info = await api<{ configured: boolean; message: string }>('/api/providers/tripo');
      return { ok: info.configured, message: info.message };
    } catch (e) {
      return { ok: false, message: e instanceof Error ? e.message : 'Backend unreachable' };
    }
  }
  async textTo3D(req: TextTo3DRequest, onProgress?: (msg: string) => void): Promise<TextTo3DResult> {
    onProgress?.('Submitting text-to-3D job to Tripo…');
    return api<TextTo3DResult>('/api/ai/text-to-3d', {
      method: 'POST',
      body: JSON.stringify({ prompt: req.prompt, style: req.style, quality: req.quality }),
    });
  }
  async imageTo3D(req: TextTo3DRequest, onProgress?: (msg: string) => void): Promise<TextTo3DResult> {
    if (!req.imageUrl && !req.imageFileToken) {
      throw new Error('Tripo image-to-3D requires a public image URL or a Tripo upload file token. Browser Blob upload is not implemented yet; the image is not sent or faked.');
    }
    onProgress?.('Submitting image-to-3D job to Tripo…');
    return api<TextTo3DResult>('/api/ai/image-to-3d', {
      method: 'POST',
      body: JSON.stringify({
        prompt: req.prompt,
        style: req.style,
        quality: req.quality,
        imageUrl: req.imageUrl,
        fileToken: req.imageFileToken,
      }),
    });
  }
}

export class WebResearchProvider implements ResearchProvider {
  id = 'web-research';
  name = 'Web Research (via backend)';
  describe(): string {
    return 'Searches public documentation and reference sources (Wikipedia + DuckDuckGo) through the backend. Results carry URLs and retrieval timestamps so you can inspect the sources. Cached in the project reference library.';
  }
  async isConfigured(): Promise<boolean> {
    return true;
  }
  async search(query: string, limit = 6): Promise<ResearchSource[]> {
    const result = await api<{ results: ResearchSource[] }>('/api/research/search', {
      method: 'POST',
      body: JSON.stringify({ query, limit }),
    });
    return result.results;
  }
}
