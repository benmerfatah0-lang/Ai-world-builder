/**
 * Project package export: a ZIP containing the versioned WorldPlan, heightmap,
 * GLB scene, user assets, validation report, and Godot/Unity conversion
 * helpers + docs. This is the documented interchange format.
 */
import JSZip from 'jszip';
import type { WorldPlan, AssetRecord } from '../core/types';
import { validateWorldPlan } from '../core/schema/validate';
import { validateExport, type ExportValidation } from './validate';
import type { Heightfield } from '../generators/terrain';
import { heightfieldToJSON } from '../generators/terrain';

export interface PackageOptions {
  glb?: Blob | null;
  thumbnail?: string | null;
  assets?: Array<{ record: AssetRecord; data: ArrayBuffer | null }>;
  checkpoints?: Array<{ id: string; ts: string; label: string; plan: unknown }>;
  heightfield?: Heightfield | null;
  targets?: Array<ExportValidation['target']>;
}

export interface PackageResult {
  blob: Blob;
  filename: string;
  reports: ExportValidation[];
  planValidation: ReturnType<typeof validateWorldPlan>;
}

export async function exportProjectPackage(plan: WorldPlan, opts: PackageOptions = {}): Promise<PackageResult> {
  const zip = new JSZip();
  const reports: ExportValidation[] = [];
  const planValidation = validateWorldPlan(plan);

  zip.file('worldplan.json', JSON.stringify(plan, null, 2));
  zip.file('README.md', packageReadme(plan));

  if (opts.heightfield) {
    zip.file('heightmap.json', JSON.stringify(heightfieldToJSON(opts.heightfield)));
  }
  if (opts.glb) {
    zip.file('scene.glb', await opts.glb.arrayBuffer());
  }
  if (opts.thumbnail) {
    const b64 = opts.thumbnail.replace(/^data:image\/\w+;base64,/, '');
    zip.file('thumbnail.png', b64, { base64: true });
  }

  const assetsFolder = zip.folder('assets');
  for (const asset of opts.assets ?? []) {
    const name = asset.record.filename ?? asset.record.name;
    if (asset.data && assetsFolder) {
      assetsFolder.file(name.replace(/[\\/]/g, '_'), asset.data, { binary: true });
    }
    const meta = {
      id: asset.record.id,
      name: asset.record.name,
      kind: asset.record.kind,
      source: asset.record.source,
      license: asset.record.license ?? null,
      attribution: asset.record.attribution ?? null,
      tags: asset.record.tags ?? [],
    };
    zip.file(`assets/meta/${asset.record.id}.json`, JSON.stringify(meta, null, 2));
  }

  const ckFolder = zip.folder('checkpoints');
  for (const ck of opts.checkpoints ?? []) {
    ckFolder?.file(`${ck.ts.replace(/[:.]/g, '-')}_${ck.label.replace(/\W+/g, '_').slice(0, 40)}.json`, JSON.stringify(ck, null, 2));
  }

  // Export target reports + helper docs.
  const targets = opts.targets ?? ['glb', 'godot', 'unity', 'project-package'];
  const reportsFolder = zip.folder('reports');
  for (const t of targets) {
    const report = validateExport(plan, t);
    reports.push(report);
    reportsFolder?.file(`${t}-export-report.json`, JSON.stringify(report, null, 2));
  }
  reportsFolder?.file('worldplan-validation.json', JSON.stringify(planValidation, null, 2));

  const toolsFolder = zip.folder('tools');
  toolsFolder?.file('godot_import.gd', GODOT_SCRIPT);
  toolsFolder?.file('unity_heightmap_import.cs', UNITY_SCRIPT);
  toolsFolder?.file('GODOT_IMPORT.md', GODOT_DOC);
  toolsFolder?.file('UNITY_IMPORT.md', UNITY_DOC);

  const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 5 } });
  const safeName = plan.name.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-').toLowerCase() || 'world';
  return { blob, filename: `${safeName}-package.zip`, reports, planValidation };
}

function packageReadme(plan: WorldPlan): string {
  return `# ${plan.name} — AI World Builder package

Generated: ${new Date().toISOString()}
Schema: WorldPlan ${plan.schemaVersion}
Seed: ${plan.seed}
Generator: ${plan.meta.generator}

## Contents

- worldplan.json — the full, versioned WorldPlan (source of truth for this world)
- scene.glb — GLB export of the rendered scene (geometry, materials, hierarchy)
- heightmap.json — terrain heightfield (regenerates terrain meshes in other tools)
- assets/ — user-imported assets, originals untouched, with license/attribution metadata
- checkpoints/ — saved plan snapshots (if any)
- reports/ — per-target export validation reports (read these to see what was and wasn't preserved)
- tools/ — Godot and Unity import helpers + step-by-step docs

## Regenerating the world

The WorldPlan is deterministic given its seed. Any tool that implements the
schema can rebuild the same world from worldplan.json alone.

## Licenses

Asset licenses and attributions are preserved under assets/meta/. Check each
before redistributing.
`;
}

const GODOT_DOC = `# Importing into Godot 4

1. Copy \`scene.glb\` into your Godot project (e.g. \`res://worlds/\`).
2. Godot imports GLB automatically — double-click it to open the scene.
3. Node names in the glTF match WorldPlan object ids — use \`worldplan.json\` to
   restore semantic metadata (kind, tags, biome) via script.
4. Terrain heightmap: copy \`heightmap.json\` and run \`tools/godot_import.gd\`
   in \`@tool\` mode (see the script header) to build a HeightMapShape3D or a
   Terrain3D-compatible image.
5. Lighting: add a DirectionalLight3D using sunAzimuth/sunElevation from
   \`worldplan.json → lighting\`.
6. Water: create a PlaneMesh at \`terrain.waterLevel\` with a transparent
   StandardMaterial3D (or a water shader of your choice).

Unsupported by the converter (recreate manually): water animation, editor-only
gizmos, AI job history.
`;

const UNITY_DOC = `# Importing into Unity

1. Install a glTF importer:
   - Unity 2022.2+: \`com.unity.cloud.gltf\` (Package Manager), or
   - glTFast (\`com.unity.cloud.gltfast\`), or UnityGLTF (Khronos).
2. Drag \`scene.glb\` into your scene hierarchy. Materials map to URP/Lit or
   Standard depending on your render pipeline.
3. Terrain: either keep the mesh terrain from the GLB, or run
   \`tools/unity_heightmap_import.cs\` (Editor script) to stamp \`heightmap.json\`
   onto a Unity Terrain (Terrain → SetHeights).
4. Lighting: add a Directional Light rotated from \`worldplan.json → lighting\`.
5. Node names match WorldPlan object ids for scripted post-processing.

Unsupported by the converter: prefab connections, water animation, editor gizmos.
`;

const GODOT_SCRIPT = `@tool
# godot_import.gd — build a heightmap resource from heightmap.json (AI World Builder)
# Usage: place next to heightmap.json, run in @tool mode or call build() from an editor script.
extends Node

func build(json_path := "res://worlds/heightmap.json") -> Image:
    var f := FileAccess.open(json_path, FileAccess.READ)
    if f == null:
        push_error("heightmap.json not found at " + json_path)
        return null
    var data: Dictionary = JSON.parse_string(f.get_as_text())
    var res: int = int(data.resolution)
    var heights: Array = data.data
    var img := Image.create(res, res, false, Image.FORMAT_RF)
    var min_h := INF
    var max_h := -INF
    for h in heights:
        min_h = min(min_h, float(h))
        max_h = max(max_h, float(h))
    var span: float = max(max_h - min_h, 0.001)
    for j in res:
        for i in res:
            var v := float(heights[j * res + i])
            img.set_pixel(i, j, Color(v, v, v))
    print("heightmap range: ", min_h, " .. ", max_h, " span=", span)
    return img
`;

const UNITY_SCRIPT = `// unity_heightmap_import.cs — stamp heightmap.json onto a Unity Terrain.
// Place in an Editor/ folder. Usage: Tools → AI World Builder → Import Heightmap.
#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using System.IO;

public static class HeightmapImporter {
    [MenuItem("Tools/AI World Builder/Import Heightmap")]
    public static void Import() {
        string path = EditorUtility.OpenFilePanel("Select heightmap.json", "", "json");
        if (string.IsNullOrEmpty(path)) return;
        string json = File.ReadAllText(path);
        var data = JsonUtility.FromJson<HeightmapData>(json);
        Terrain terrain = Terrain.activeTerrain;
        if (terrain == null) { Debug.LogError("No active terrain in the scene."); return; }

        int res = data.resolution;
        float[] heights = data.data;
        float min = float.MaxValue, max = float.MinValue;
        foreach (float h in heights) { if (h < min) min = h; if (h > max) max = h; }
        float span = Mathf.Max(max - min, 0.001f);

        float[,] map = new float[res, res];
        for (int j = 0; j < res; j++)
            for (int i = 0; i < res; i++)
                map[j, i] = (heights[j * res + i] - min) / span;

        terrain.terrainData.heightmapResolution = res;
        terrain.terrainData.SetHeights(0, 0, map);
        Debug.Log($"Heightmap imported: {res}x{res}, range {min}..{max}");
    }

    [System.Serializable]
    public class HeightmapData {
        public int resolution;
        public float size;
        public float waterLevel;
        public float[] data;
    }
}
#endif
`;
