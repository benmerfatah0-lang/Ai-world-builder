/**
 * GLB/glTF export of the current scene using three.js GLTFExporter.
 */
import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import type { WorldPlan } from '../core/types';

export interface GlbExportResult {
  blob: Blob;
  bytes: number;
  nodeCount: number;
  format: 'glb' | 'gltf';
}

export async function exportSceneToGlb(
  root: THREE.Object3D,
  plan: WorldPlan,
  opts: { binary?: boolean; includeCustomExtensions?: boolean } = {},
): Promise<GlbExportResult> {
  // Embed WorldPlan metadata so exports stay traceable.
  root.userData = {
    ...root.userData,
    worldPlan: {
      schemaVersion: plan.schemaVersion,
      id: plan.id,
      name: plan.name,
      seed: plan.seed,
      generator: plan.meta.generator,
      exportedAt: new Date().toISOString(),
    },
  };

  const exporter = new GLTFExporter();
  const result = await exporter.parseAsync(root, {
    binary: opts.binary ?? true,
    onlyVisible: true,
    truncateDrawRange: true,
    includeCustomExtensions: opts.includeCustomExtensions ?? false,
  });

  let blob: Blob;
  if (result instanceof ArrayBuffer) {
    blob = new Blob([result], { type: 'model/gltf-binary' });
  } else {
    blob = new Blob([JSON.stringify(result, null, 2)], { type: 'model/gltf+json' });
  }

  let nodeCount = 0;
  root.traverse(() => nodeCount++);

  return {
    blob,
    bytes: blob.size,
    nodeCount,
    format: result instanceof ArrayBuffer ? 'glb' : 'gltf',
  };
}
