/**
 * Export validation: reports which scene features the target format supports,
 * so nothing is silently lost.
 */
import type { WorldPlan } from '../core/types';

export interface ExportCapability {
  feature: string;
  supported: boolean;
  note: string;
}

export interface ExportValidation {
  target: 'glb' | 'godot' | 'unity' | 'project-package';
  capabilities: ExportCapability[];
  warnings: string[];
  ok: boolean;
}

const CAPS: Record<ExportValidation['target'], (plan: WorldPlan) => ExportCapability[]> = {
  glb: (plan) => [
    { feature: 'Meshes & hierarchy', supported: true, note: 'Exported as glTF nodes with names and transforms.' },
    { feature: 'PBR materials', supported: true, note: 'Base color, roughness, metalness, emissive exported.' },
    { feature: 'Vertex colors (terrain)', supported: true, note: 'Terrain bakes biome colors into vertex colors.' },
    { feature: 'Shadows & lighting', supported: false, note: 'glTF stores lights only via KHR_lights_punctual; the sun/ambient are exported as nodes when available.' },
    { feature: 'WorldPlan metadata', supported: true, note: 'Embedded in the extras of the root node (schemaVersion, seed, generator).' },
    { feature: 'Instanced scatter', supported: true, note: 'Expanded to individual glTF nodes on export (target format has no native instancing for our clusters).' },
    { feature: 'Water animation', supported: false, note: 'Water is exported as a static transparent mesh; animation is editor-only.' },
    { feature: 'Terrain heightfield', supported: true, note: 'Exported as a terrain mesh. Raw heightmap is included in the project package.' },
    { feature: 'AI generation history', supported: false, note: 'Provenance is kept in the project package, not in GLB.' },
    ...(plan.objects.some((o) => o.meta?.rigged) ? [{ feature: 'Rigging/skins', supported: true, note: 'Skeletons exported when present.' }] : []),
  ],
  godot: () => [
    { feature: 'glTF/GLB scene import', supported: true, note: 'Godot 4 imports GLB natively — drop scene.glb into res://.' },
    { feature: 'Materials', supported: true, note: 'StandardMaterial3D mapping from glTF PBR.' },
    { feature: 'Terrain', supported: true, note: 'Imported as a mesh; HeightMapShape3D generated from heightmap.json via the included converter script.' },
    { feature: 'Lighting', supported: true, note: 'Sun exported as a DirectionalLight3D node in the generated .tscn.' },
    { feature: 'Water animation', supported: false, note: 'Recreate with a shader in Godot (see docs/GODOT_IMPORT.md).' },
    { feature: 'Editor metadata', supported: true, note: 'WorldPlan JSON included; node names match object ids for re-import scripting.' },
  ],
  unity: () => [
    { feature: 'glTF import', supported: true, note: 'Unity 2022+ imports glTF via com.unity.cloud.gltf, or via glTFast package (see docs/UNITY_IMPORT.md).' },
    { feature: 'Materials', supported: true, note: 'Mapped to URP/Lit or Standard shader on import.' },
    { feature: 'Terrain', supported: true, note: 'Mesh terrain included; Unity Terrain conversion helper documented in docs/UNITY_IMPORT.md.' },
    { feature: 'Lighting', supported: true, note: 'Directional light prefab included in the package.' },
    { feature: 'Prefabs', supported: false, note: 'Prefab connections are not recreated automatically — models land as meshes.' },
    { feature: 'Water animation', supported: false, note: 'Use Unity water/shader assets.' },
  ],
  'project-package': () => [
    { feature: 'WorldPlan JSON (versioned)', supported: true, note: 'worldplan.json validated before packaging.' },
    { feature: 'Heightfield', supported: true, note: 'heightmap.json (resolution/size/levels).' },
    { feature: 'User assets', supported: true, note: 'Copied verbatim under assets/ with attribution preserved.' },
    { feature: 'Checkpoints', supported: true, note: 'Included when available as checkpoints/.' },
    { feature: 'Thumbnail', supported: true, note: 'Rendered preview PNG when available.' },
    { feature: 'Conversion scripts', supported: true, note: 'Godot/Unity helper scripts and docs included.' },
  ],
};

export function validateExport(plan: WorldPlan, target: ExportValidation['target']): ExportValidation {
  const capabilities = CAPS[target](plan);
  const warnings: string[] = [];

  if (!plan.objects.length && target !== 'project-package') {
    warnings.push('The world has no objects — the export will contain terrain only.');
  }
  const unsupported = capabilities.filter((c) => !c.supported);
  for (const c of unsupported) {
    if (/animation|rigging|prefab/i.test(c.feature)) {
      warnings.push(`"${c.feature}" is not carried into ${target}: ${c.note}`);
    }
  }
  if (plan.assets?.some((a) => a.meta?.supported === false)) {
    warnings.push('Some imported assets were marked unsupported and will be skipped in the export (they remain in the project package).');
  }

  return { target, capabilities, warnings, ok: true };
}
