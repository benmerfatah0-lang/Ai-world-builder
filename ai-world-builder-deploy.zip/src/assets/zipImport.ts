/**
 * Asset pack import: safely extracts uploaded ZIP packs (or loose files),
 * classifies every entry, and reports unsupported files and extraction errors
 * clearly. Originals are never modified — the pack is copied into project storage.
 */
import JSZip from 'jszip';
import { classifyFile, extractAttribution, toAssetRecord, type ClassifiedFile, type ImportIssue } from './classify';
import type { AssetRecord } from '../core/types';

export interface ImportedFile {
  classified: ClassifiedFile;
  /** Original bytes (kept in memory for preview / placement). */
  data: ArrayBuffer | null;
  /** Text content when the file is textual (license etc.). */
  text?: string;
}

export interface PackImportResult {
  packName: string;
  files: ImportedFile[];
  assets: AssetRecord[];
  issues: ImportIssue[];
  license?: string;
  attribution?: string;
  stats: { total: number; supported: number; unsupported: number; bytes: number };
}

const MAX_TOTAL_SIZE = 256 * 1024 * 1024; // 256 MB unpacked budget
const MAX_FILES = 4000;

export async function importZipPack(file: File): Promise<PackImportResult> {
  const packName = file.name.replace(/\.zip$/i, '');
  const files: ImportedFile[] = [];
  const issues: ImportIssue[] = [];

  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(file);
  } catch (e) {
    return {
      packName,
      files: [],
      assets: [],
      issues: [{ path: file.name, message: `Not a readable ZIP archive: ${e instanceof Error ? e.message : String(e)}`, severity: 'error' }],
      stats: { total: 0, supported: 0, unsupported: 0, bytes: 0 },
    };
  }

  const entries = Object.values(zip.files).filter((e) => !e.dir);
  if (entries.length > MAX_FILES) {
    issues.push({ path: packName, message: `Pack contains ${entries.length} files — over the ${MAX_FILES} file limit. Import a smaller pack.`, severity: 'error' });
  }

  let totalBytes = 0;
  const textFiles: Array<{ path: string; text: string }> = [];

  for (const entry of entries.slice(0, MAX_FILES)) {
    // Path traversal guard: reject entries escaping the pack root.
    if (entry.name.includes('..') || entry.name.startsWith('/') || /^[a-zA-Z]:/.test(entry.name)) {
      issues.push({ path: entry.name, message: 'Blocked suspicious path (possible path traversal).', severity: 'error' });
      continue;
    }

    let data: ArrayBuffer;
    try {
      data = await entry.async('arraybuffer');
    } catch (e) {
      issues.push({ path: entry.name, message: `Extraction failed: ${e instanceof Error ? e.message : String(e)}`, severity: 'error' });
      continue;
    }

    totalBytes += data.byteLength;
    if (totalBytes > MAX_TOTAL_SIZE) {
      issues.push({ path: entry.name, message: 'Pack exceeds the 256 MB unpacked size budget — remaining files skipped.', severity: 'error' });
      break;
    }

    const classified = classifyFile(entry.name, data.byteLength);
    if (!classified.supported && classified.reason) {
      issues.push({ path: entry.name, message: classified.reason, severity: 'warning' });
    }

    const isText = classified.format === 'text' || classified.kind === 'material';
    let text: string | undefined;
    if (isText && data.byteLength < 512 * 1024) {
      try {
        text = new TextDecoder().decode(data);
        textFiles.push({ path: entry.name, text });
      } catch { /* binary that looked textual */ }
    }

    files.push({ classified, data, text });
  }

  const { license, attribution } = extractAttribution(textFiles);
  const assets = files.map((f) => {
    const rec = toAssetRecord(f.classified);
    if (license) rec.license = license.slice(0, 500);
    if (attribution) rec.attribution = attribution.slice(0, 500);
    return rec;
  });

  return {
    packName,
    files,
    assets,
    issues,
    license,
    attribution,
    stats: {
      total: files.length,
      supported: files.filter((f) => f.classified.supported).length,
      unsupported: files.filter((f) => !f.classified.supported).length,
      bytes: totalBytes,
    },
  };
}

export async function importLooseFiles(fileList: FileList | File[]): Promise<PackImportResult> {
  const files: ImportedFile[] = [];
  const issues: ImportIssue[] = [];
  let totalBytes = 0;

  for (const file of Array.from(fileList)) {
    totalBytes += file.size;
    if (totalBytes > MAX_TOTAL_SIZE) {
      issues.push({ path: file.name, message: 'Total import size over 256 MB — remaining files skipped.', severity: 'error' });
      break;
    }
    const classified = classifyFile(file.name, file.size);
    if (!classified.supported && classified.reason) {
      issues.push({ path: file.name, message: classified.reason, severity: 'warning' });
    }
    let data: ArrayBuffer | null = null;
    try {
      data = await file.arrayBuffer();
    } catch (e) {
      issues.push({ path: file.name, message: `Could not read file: ${e instanceof Error ? e.message : String(e)}`, severity: 'error' });
    }
    let text: string | undefined;
    if (classified.format === 'text' && data) {
      try { text = new TextDecoder().decode(data); } catch { /* ignore */ }
    }
    files.push({ classified, data, text });
  }

  const textFiles = files.filter((f) => f.text).map((f) => ({ path: f.classified.path, text: f.text! }));
  const { license, attribution } = extractAttribution(textFiles);

  return {
    packName: 'imported-files',
    files,
    assets: files.map((f) => toAssetRecord(f.classified)),
    issues,
    license,
    attribution,
    stats: {
      total: files.length,
      supported: files.filter((f) => f.classified.supported).length,
      unsupported: files.filter((f) => !f.classified.supported).length,
      bytes: totalBytes,
    },
  };
}
