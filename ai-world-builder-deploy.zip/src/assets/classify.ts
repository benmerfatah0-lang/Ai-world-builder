/**
 * Asset classification: detects file kinds and formats for imported packs.
 * Never overwrites originals; unsupported files are reported, not silently dropped.
 */
import type { AssetRecord } from '../core/types';
import { newId } from '../core/types';

export type AssetKind = AssetRecord['kind'];

export interface ClassifiedFile {
  name: string;
  path: string;
  size: number;
  kind: AssetKind;
  format: string;
  supported: boolean;
  reason?: string;
  /** Suggested tags derived from name and location. */
  tags: string[];
}

export interface ImportIssue {
  path: string;
  message: string;
  severity: 'error' | 'warning';
}

const MODEL_EXT: Record<string, string> = {
  glb: 'glTF Binary', gltf: 'glTF', obj: 'Wavefront OBJ', mtl: 'OBJ Material',
  fbx: 'FBX', dae: 'Collada', stl: 'STL', ply: 'PLY', blend: 'Blender',
};
const TEXTURE_EXT: Record<string, string> = {
  png: 'PNG', jpg: 'JPEG', jpeg: 'JPEG', webp: 'WebP', bmp: 'BMP',
  tga: 'TGA', tif: 'TIFF', tiff: 'TIFF', hdr: 'HDR', ktx2: 'KTX2', dds: 'DDS',
};
const MATERIAL_EXT: Record<string, string> = {
  mtl: 'OBJ Material', mat: 'Material', json: 'JSON material', yml: 'YAML material', yaml: 'YAML material',
};
const IMAGE_EXT: Record<string, string> = { ...TEXTURE_EXT, gif: 'GIF', svg: 'SVG' };

/** Formats the app can actually load in the browser today. */
const SUPPORTED_MODELS = new Set(['glb', 'gltf', 'obj', 'stl', 'ply']);
const SUPPORTED_TEXTURES = new Set(['png', 'jpg', 'jpeg', 'webp', 'bmp', 'gif', 'svg']);

export function classifyFile(path: string, size: number): ClassifiedFile {
  const name = path.split('/').pop() ?? path;
  const ext = (name.split('.').pop() ?? '').toLowerCase();
  const base = name.toLowerCase();

  let kind: AssetKind = 'other';
  let format = ext.toUpperCase() || 'unknown';
  let supported = false;
  let reason: string | undefined;

  if (MODEL_EXT[ext]) {
    kind = 'model';
    format = MODEL_EXT[ext];
    supported = SUPPORTED_MODELS.has(ext);
    if (!supported) {
      reason = `${format} models cannot be loaded in the browser yet — convert to GLB/glTF (e.g. via Blender) or keep it in the pack for later.`;
    }
    if (ext === 'mtl') {
      kind = 'material';
      supported = true;
      reason = 'OBJ material library — will be referenced by OBJ models.';
    }
  } else if (MATERIAL_EXT[ext] && !IMAGE_EXT[ext]) {
    kind = 'material';
    format = MATERIAL_EXT[ext];
    supported = ext === 'mtl';
    if (!supported) reason = `${format} material definitions are indexed but not auto-applied yet.`;
  } else if (IMAGE_EXT[ext]) {
    kind = 'texture';
    format = IMAGE_EXT[ext];
    supported = SUPPORTED_TEXTURES.has(ext);
    if (!supported) reason = `${format} textures are not decodable by the browser — convert to PNG/JPG/WebP.`;
    if (/preview|thumb|render|screenshot|cover/.test(base)) kind = 'image';
  } else if (ext === 'txt' || ext === 'md' || base === 'license' || base.startsWith('license') || base === 'readme') {
    kind = 'other';
    format = 'text';
    supported = true;
    if (/license|copying|attribution/.test(base)) reason = 'License/attribution file — preserved with the pack.';
  } else if (ext === 'zip') {
    kind = 'other';
    format = 'ZIP archive';
    supported = false;
    reason = 'Nested ZIP archives are not extracted automatically (security). Extract manually and re-upload.';
  } else {
    reason = `Unrecognized file type .${ext} — stored but not used in the scene.`;
  }

  if (size > 64 * 1024 * 1024) {
    supported = false;
    reason = `File is ${(size / 1024 / 1024).toFixed(1)} MB — over the 64 MB per-file import limit.`;
  }

  const tags = deriveTags(path);
  return { name, path, size, kind, format, supported, reason, tags };
}

function deriveTags(path: string): string[] {
  const tags = new Set<string>();
  const parts = path.toLowerCase().split(/[\\/._\-\s]+/).filter(Boolean);
  const vocab = [
    'tree', 'rock', 'house', 'building', 'character', 'prop', 'grass', 'nature',
    'stone', 'wood', 'metal', 'tile', 'brick', 'ground', 'terrain', 'vehicle',
    'weapon', 'animal', 'plant', 'foliage', 'wall', 'roof', 'door', 'window',
    'lowpoly', 'low', 'poly', 'pbr', '4k', '2k', '1k', 'texture', 'material', 'seamless',
  ];
  for (const p of parts) if (vocab.includes(p)) tags.add(p);
  return [...tags];
}

export function toAssetRecord(file: ClassifiedFile, source: AssetRecord['source'] = 'user'): AssetRecord {
  return {
    id: newId('asset'),
    name: file.name.replace(/\.[^.]+$/, ''),
    kind: file.kind,
    source,
    filename: file.path,
    tags: file.tags,
    meta: {
      format: file.format,
      size: file.size,
      supported: file.supported,
      ...(file.reason ? { note: file.reason } : {}),
    },
  };
}

/** Extract attribution/license text files from a list of text contents. */
export function extractAttribution(textFiles: Array<{ path: string; text: string }>): {
  license?: string;
  attribution?: string;
} {
  let license: string | undefined;
  let attribution: string | undefined;
  for (const f of textFiles) {
    const base = f.path.split('/').pop()?.toLowerCase() ?? '';
    if (/license|copying/.test(base)) {
      license = f.text.slice(0, 2000);
    } else if (/credit|author|attribution|readme/.test(base)) {
      const authored = f.text.match(/author[s]?\s*[:\-]\s*(.+)/i);
      const licensed = f.text.match(/license[s]?\s*[:\-]\s*(.+)/i);
      attribution = (authored?.[1] ?? f.text).slice(0, 2000);
      if (!license && licensed) license = licensed[1];
    }
  }
  return { license, attribution };
}
