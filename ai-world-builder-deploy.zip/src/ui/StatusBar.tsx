import React from 'react';
import { useApp } from '../state/store';

export function StatusBar(): React.ReactElement {
  const busy = useApp((s) => s.busy);
  const dirty = useApp((s) => s.dirty);
  const lastSaved = useApp((s) => s.lastSaved);
  const plan = useApp((s) => s.plan);
  const generationStats = useApp((s) => s.generationStats);
  const selection = useApp((s) => s.selection);
  const saveError = useApp((s) => s.saveError);

  return (
    <footer className="statusbar">
      <span className={`dot ${busy ? 'busy' : ''}`} />
      <span>{busy ? 'Working…' : 'Ready'}</span>
      <span>{plan.meta.generator}</span>
      <span>WorldPlan {plan.schemaVersion}</span>
      {generationStats && <span>{generationStats.instanceCount.toLocaleString()} instances</span>}
      {selection.length > 0 && <span>{selection.length} selected</span>}
      <span style={{ marginLeft: 'auto' }}>
        {saveError ? <span style={{ color: 'var(--red)' }}>Save error: {saveError}</span>
          : dirty ? 'Unsaved changes — autosave on'
            : lastSaved ? `Saved ${lastSaved.slice(11, 19)}` : 'Not saved yet'}
      </span>
    </footer>
  );
}
