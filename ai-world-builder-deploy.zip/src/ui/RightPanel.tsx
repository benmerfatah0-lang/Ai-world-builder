import React, { useState } from 'react';
import { useApp } from '../state/store';
import type { ArtStyle, Weather, SkyPreset } from '../core/types';

export function RightPanel(): React.ReactElement {
  const [tab, setTab] = useState<'object' | 'world'>('object');
  const plan = useApp((s) => s.plan);
  const selection = useApp((s) => s.selection);
  const applyPlanOp = useApp((s) => s.applyPlanOp);
  const transformObject = useApp((s) => s.transformObject);
  const setStyle = useApp((s) => s.setStyle);
  const setWeather = useApp((s) => s.setWeather);
  const setSeed = useApp((s) => s.setSeed);
  const setDensity = useApp((s) => s.setDensity);
  const deleteSelection = useApp((s) => s.deleteSelection);
  const duplicateSelection = useApp((s) => s.duplicateSelection);
  const regenerateSelected = useApp((s) => s.regenerateSelected);
  const derivedObjects = useApp((s) => s.derivedObjects);

  const selected =
    plan.objects.find((o) => selection.includes(o.id)) ??
    derivedObjects.find((o) => selection.includes(o.id)) ??
    null;

  return (
    <aside className="panel right-panel">
      <div className="panel-tabs">
        <button className={tab === 'object' ? 'active' : ''} onClick={() => setTab('object')}>Properties</button>
        <button className={tab === 'world' ? 'active' : ''} onClick={() => setTab('world')}>World</button>
      </div>

      <div className="panel-body">
        {tab === 'object' ? (
          selected ? (
            <>
              <div className="section">
                <div className="section-title">Object</div>
                <div className="prop-row">
                  <label>Name</label>
                  <input
                    value={selected.name ?? ''}
                    onChange={(e) => applyPlanOp({ type: 'updateObject', id: selected.id, patch: { name: e.target.value } }, { silent: true })}
                  />
                </div>
                <div className="prop-row">
                  <label>Kind</label>
                  <input value={selected.kind} disabled />
                </div>
                <div className="prop-row">
                  <label>Prefab</label>
                  <input value={selected.prefab ?? '—'} disabled />
                </div>
                {selected.instances && (
                  <div className="prop-row">
                    <label>Instances</label>
                    <input value={String(selected.instances.length)} disabled />
                  </div>
                )}
              </div>

              <div className="section">
                <div className="section-title">Transform</div>
                <Vec3Row
                  label="Position"
                  value={selected.position}
                  onChange={(v) => transformObject(selected.id, v, selected.rotation ?? [0, 0, 0], selected.scale ?? 1, true)}
                />
                <Vec3Row
                  label="Rotation"
                  value={selected.rotation ?? [0, 0, 0]}
                  onChange={(v) => transformObject(selected.id, selected.position, v, selected.scale ?? 1, true)}
                  step={0.05}
                />
                <div className="prop-row">
                  <label>Scale</label>
                  <input
                    type="number"
                    step={0.05}
                    value={typeof selected.scale === 'number' ? selected.scale : (selected.scale?.[0] ?? 1)}
                    onChange={(e) => {
                      const v = parseFloat(e.target.value) || 1;
                      transformObject(selected.id, selected.position, selected.rotation ?? [0, 0, 0], v, true);
                    }}
                  />
                </div>
              </div>

              <div className="section">
                <div className="section-title">Material</div>
                <div className="prop-row">
                  <label>Color override</label>
                  <input
                    type="color"
                    style={{ height: 30, padding: 2, flex: 1.6 }}
                    value={selected.material?.color ?? '#8fb86a'}
                    onChange={(e) => applyPlanOp({ type: 'updateObject', id: selected.id, patch: { material: { ...selected.material, color: e.target.value } } }, { silent: true })}
                  />
                </div>
                <SliderRow
                  label="Roughness"
                  min={0} max={1} step={0.01}
                  value={selected.material?.roughness ?? 0.85}
                  onChange={(v) => applyPlanOp({ type: 'updateObject', id: selected.id, patch: { material: { ...selected.material, roughness: v } } }, { silent: true })}
                />
                <SliderRow
                  label="Metalness"
                  min={0} max={1} step={0.01}
                  value={selected.material?.metalness ?? 0.02}
                  onChange={(v) => applyPlanOp({ type: 'updateObject', id: selected.id, patch: { material: { ...selected.material, metalness: v } } }, { silent: true })}
                />
              </div>

              <div className="section flex wrap">
                <button className="small" onClick={duplicateSelection}>Duplicate</button>
                <button className="small" onClick={() => void regenerateSelected()}>Regenerate</button>
                <button className="small danger" onClick={deleteSelection}>Delete</button>
              </div>
            </>
          ) : (
            <div className="section muted">
              Select an object in the viewport or scene list to edit its properties.
              <div className="mt">
                Shortcuts: <strong>G</strong> move · <strong>R</strong> rotate · <strong>S</strong> scale ·
                <strong> Del</strong> delete · <strong>Ctrl+D</strong> duplicate · <strong>Ctrl+Z</strong> undo.
              </div>
            </div>
          )
        ) : (
          <>
            <div className="section">
              <div className="section-title">Art style</div>
              <div className="pill-tabs wrap">
                {(['low-poly', 'stylized', 'cartoon', 'realistic', 'voxel'] as ArtStyle[]).map((st) => (
                  <button key={st} className={plan.settings.style === st ? 'active' : ''} onClick={() => setStyle(st)}>
                    {st}
                  </button>
                ))}
              </div>
            </div>

            <div className="section">
              <div className="section-title">Environment</div>
              <div className="prop-row">
                <label>Weather</label>
                <select
                  value={plan.settings.environment?.weather ?? 'clear'}
                  onChange={(e) => setWeather(e.target.value as Weather)}
                >
                  {['clear', 'cloudy', 'rain', 'snow', 'storm', 'fog'].map((w) => (
                    <option key={w} value={w}>{w}</option>
                  ))}
                </select>
              </div>
              <div className="prop-row">
                <label>Sky</label>
                <select
                  value={plan.settings.environment?.skyPreset ?? 'day'}
                  onChange={(e) => setWeather(plan.settings.environment?.weather ?? 'clear', e.target.value as SkyPreset)}
                >
                  {['day', 'sunset', 'dawn', 'night', 'overcast'].map((w) => (
                    <option key={w} value={w}>{w}</option>
                  ))}
                </select>
              </div>
              <SliderRow
                label="Time of day"
                min={0} max={24} step={0.5}
                value={plan.settings.environment?.timeOfDay ?? 10.5}
                onChange={(v) => setWeather(plan.settings.environment?.weather ?? 'clear', plan.settings.environment?.skyPreset, v)}
              />
            </div>

            <div className="section">
              <div className="section-title">Density</div>
              <SliderRow label="Vegetation" min={0} max={1} step={0.05} value={plan.settings.density.vegetation ?? 0.6}
                onChange={(v) => setDensity('vegetation', v - (plan.settings.density.vegetation ?? 0.6))} />
              <SliderRow label="Props" min={0} max={1} step={0.05} value={plan.settings.density.props ?? 0.5}
                onChange={(v) => setDensity('props', v - (plan.settings.density.props ?? 0.5))} />
              <SliderRow label="Structures" min={0} max={1} step={0.05} value={plan.settings.density.structures ?? 0.5}
                onChange={(v) => setDensity('structures', v - (plan.settings.density.structures ?? 0.5))} />
            </div>

            <div className="section">
              <div className="section-title">World</div>
              <div className="prop-row">
                <label>Seed</label>
                <input
                  type="number"
                  value={plan.seed}
                  onChange={(e) => setSeed(parseInt(e.target.value, 10) || 0)}
                />
              </div>
              <div className="prop-row">
                <label>Size</label>
                <input
                  type="number"
                  value={plan.settings.size.widthMeters}
                  onChange={(e) => {
                    const v = Math.min(4096, Math.max(32, parseInt(e.target.value, 10) || 256));
                    applyPlanOp({ type: 'setSettings', patch: { size: { ...plan.settings.size, widthMeters: v, depthMeters: v } } });
                  }}
                />
              </div>
              <div className="prop-row">
                <label>Quality</label>
                <select
                  value={plan.settings.quality}
                  onChange={(e) => applyPlanOp({ type: 'setSettings', patch: { quality: e.target.value as never } })}
                >
                  <option value="draft">draft</option>
                  <option value="standard">standard</option>
                  <option value="high">high</option>
                </select>
              </div>
              <div className="prop-row">
                <label>Water level</label>
                <input
                  type="number"
                  value={plan.terrain.waterLevel}
                  onChange={(e) => applyPlanOp({ type: 'setTerrain', patch: { waterLevel: parseFloat(e.target.value) || 0 } })}
                />
              </div>
            </div>

            <div className="section">
              <div className="section-title">Terrain features ({(plan.terrain.features ?? []).length})</div>
              {(plan.terrain.features ?? []).map((f) => (
                <div key={f.id} className="hierarchy-item" title={`position ${f.position.join(', ')}`}>
                  <span>⛰️</span>
                  <span className="name">{f.type}</span>
                  <button
                    className="ghost small"
                    onClick={() => applyPlanOp({ type: 'setTerrain', patch: { features: (plan.terrain.features ?? []).filter((x) => x.id !== f.id) } })}
                  >
                    ✕
                  </button>
                </div>
              ))}
              {!(plan.terrain.features ?? []).length && <div className="muted" style={{ fontSize: 11 }}>No explicit features — terrain comes from the noise generator.</div>}
            </div>
          </>
        )}
      </div>
    </aside>
  );
}

function Vec3Row({ label, value, onChange, step = 0.5 }: {
  label: string;
  value: [number, number, number];
  onChange: (v: [number, number, number]) => void;
  step?: number;
}): React.ReactElement {
  return (
    <div className="prop-row">
      <label>{label}</label>
      <div className="vec-inputs">
        {(['x', 'y', 'z'] as const).map((axis, i) => (
          <input
            key={axis}
            type="number"
            step={step}
            value={Number(value[i].toFixed(2))}
            onChange={(e) => {
              const next = [...value] as [number, number, number];
              next[i] = parseFloat(e.target.value) || 0;
              onChange(next);
            }}
            aria-label={`${label} ${axis}`}
          />
        ))}
      </div>
    </div>
  );
}

function SliderRow({ label, min, max, step, value, onChange }: {
  label: string;
  min: number;
  max: number;
  step: number;
  value: number;
  onChange: (v: number) => void;
}): React.ReactElement {
  return (
    <div className="slider-row">
      <label>{label}</label>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
      <span className="value">{value.toFixed(2)}</span>
    </div>
  );
}
