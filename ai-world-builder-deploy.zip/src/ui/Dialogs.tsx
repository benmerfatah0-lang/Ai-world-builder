import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../state/store';
import { Icons } from './icons';
import type { ProjectSummary, Job } from '../state/store';

type CheckpointEntry = Awaited<ReturnType<ReturnType<typeof useApp.getState>['listCheckpointEntries']>>[number];

export function Dialogs(): React.ReactElement | null {
  const dialogs = useApp((s) => s.dialogs);
  return (
    <>
      {dialogs.projects && <ProjectsDialog />}
      {dialogs.export && <ExportDialog />}
      {dialogs.providers && <ProvidersDialog />}
      {dialogs.import && <ImportDialog />}
      {dialogs.checkpoints && <CheckpointsDialog />}
      {dialogs.about && <AboutDialog />}
    </>
  );
}

function DialogShell({ title, onClose, children, footer, wide }: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  footer?: React.ReactNode;
  wide?: boolean;
}): React.ReactElement {
  return (
    <div className="dialog-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`dialog ${wide ? 'wide' : ''}`}>
        <div className="dialog-header">
          <h2>{title}</h2>
          <button className="ghost" onClick={onClose} aria-label="Close dialog">{Icons.x}</button>
        </div>
        <div className="dialog-body">{children}</div>
        {footer && <div className="dialog-footer">{footer}</div>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function ProjectsDialog(): React.ReactElement {
  const toggleDialog = useApp((s) => s.toggleDialog);
  const newWorld = useApp((s) => s.newWorld);
  const saveNow = useApp((s) => s.saveNow);
  const openProject = useApp((s) => s.openProject);
  const deleteProjectById = useApp((s) => s.deleteProjectById);
  const plan = useApp((s) => s.plan);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const fileRef = useRef<HTMLInputElement>(null);
  const importPlanJson = useApp((s) => s.importPlanJson);
  const exportPlanJson = useApp((s) => s.exportPlanJson);

  const refresh = (): void => {
    setLoading(true);
    void useApp.getState().listProjectSummaries().then((p) => {
      setProjects(p);
      setLoading(false);
    });
  };
  useEffect(refresh, []);

  return (
    <DialogShell
      title="Projects"
      onClose={() => toggleDialog('projects', false)}
      footer={
        <>
          <button onClick={() => void exportPlanJson()}>{Icons.download} Export plan JSON</button>
          <button onClick={() => fileRef.current?.click()}>{Icons.upload} Import plan JSON</button>
          <button onClick={() => { void newWorld(); toggleDialog('projects', false); }}>{Icons.plus} New world</button>
          <button className="primary" onClick={() => void saveNow('save')}>{Icons.save} Save current</button>
        </>
      }
    >
      <input
        ref={fileRef}
        type="file"
        accept="application/json,.json"
        style={{ display: 'none' }}
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void importPlanJson(f);
          toggleDialog('projects', false);
        }}
      />

      <div className="hint-box">
        Projects are saved locally in your browser via <strong>IndexedDB</strong> — free, offline-friendly, no account needed.
        Use “Export plan JSON” / “Export package” to back up or move projects between devices.
      </div>

      <div className="section-title mt">Saved locally ({projects.length})</div>
      {loading && <div className="muted">Loading…</div>}
      <div className="card-list">
        {projects.map((p) => (
          <div key={p.id} className="card">
            <div className="info">
              <div className="title">{p.name}</div>
              <div className="subtitle">Updated {new Date(p.updatedAt).toLocaleString()} · created {new Date(p.createdAt).toLocaleDateString()}</div>
              {p.id === plan.id && <span className="badge info">open</span>}
            </div>
            <button onClick={() => { void openProject(p.id); toggleDialog('projects', false); }}>Open</button>
            <button
              className="danger"
              onClick={() => {
                if (confirm(`Delete "${p.name}" from local storage? This cannot be undone.`)) {
                  void deleteProjectById(p.id).then(refresh);
                }
              }}
            >
              {Icons.trash}
            </button>
          </div>
        ))}
        {!loading && !projects.length && (
          <div className="muted">No saved projects yet. Press “Save current” to store this world in your browser.</div>
        )}
      </div>

      <div className="flex mt">
        <button onClick={() => { void useApp.getState().createCheckpointNow(`checkpoint ${new Date().toLocaleTimeString()}`); }}>
          {Icons.plus} Create checkpoint
        </button>
        <button onClick={() => toggleDialog('checkpoints', true)}>{Icons.layers} Manage checkpoints</button>
      </div>
    </DialogShell>
  );
}

/* ------------------------------------------------------------------ */

function CheckpointsDialog(): React.ReactElement {
  const toggleDialog = useApp((s) => s.toggleDialog);
  const [entries, setEntries] = useState<CheckpointEntry[]>([]);

  useEffect(() => {
    void useApp.getState().listCheckpointEntries().then(setEntries);
  }, []);

  return (
    <DialogShell
      title="Checkpoints"
      onClose={() => toggleDialog('checkpoints', false)}
      footer={
        <>
          <button onClick={() => void useApp.getState().createCheckpointNow(`checkpoint ${new Date().toLocaleTimeString()}`)}>
            {Icons.plus} New checkpoint
          </button>
          <button className="primary" onClick={() => toggleDialog('checkpoints', false)}>Done</button>
        </>
      }
    >
      <div className="hint-box">
        Checkpoints are full plan snapshots — restore any of them to roll back the world
        (generation results are rebuilt from the restored plan).
      </div>
      <div className="card-list">
        {entries.map((c) => (
          <div key={c.id} className="card">
            <div className="info">
              <div className="title">{c.label}</div>
              <div className="subtitle">{new Date(c.ts).toLocaleString()}</div>
            </div>
            <button onClick={() => {
              void useApp.getState().restoreCheckpoint(c.id).then(() => toggleDialog('checkpoints', false));
            }}>
              {Icons.refresh} Restore
            </button>
          </div>
        ))}
        {!entries.length && <div className="muted">No checkpoints yet.</div>}
      </div>
    </DialogShell>
  );
}

/* ------------------------------------------------------------------ */

function ExportDialog(): React.ReactElement {
  const toggleDialog = useApp((s) => s.toggleDialog);
  const exportGlbFile = useApp((s) => s.exportGlbFile);
  const exportPackageFile = useApp((s) => s.exportPackageFile);
  const exportPlanJson = useApp((s) => s.exportPlanJson);
  const busy = useApp((s) => s.busy);

  return (
    <DialogShell
      title="Export"
      onClose={() => toggleDialog('export', false)}
      footer={<button className="primary" onClick={() => toggleDialog('export', false)}>Close</button>}
    >
      <div className="card-list">
        <div className="card">
          <div className="info">
            <div className="title">GLB scene (.glb)</div>
            <div className="subtitle">Full scene — geometry, materials, hierarchy. Imports into Godot, Unity, Blender, three.js.</div>
          </div>
          <button className="primary" disabled={busy} onClick={() => void exportGlbFile()}>{Icons.download} Export GLB</button>
        </div>
        <div className="card">
          <div className="info">
            <div className="title">Project package (.zip)</div>
            <div className="subtitle">
              worldplan.json + scene.glb + heightmap + assets + checkpoints + Godot/Unity conversion tools + validation reports.
            </div>
          </div>
          <button className="primary" disabled={busy} onClick={() => void exportPackageFile()}>{Icons.download} Export package</button>
        </div>
        <div className="card">
          <div className="info">
            <div className="title">WorldPlan JSON</div>
            <div className="subtitle">Just the versioned plan document — the source of truth for regenerating the world.</div>
          </div>
          <button disabled={busy} onClick={() => void exportPlanJson()}>{Icons.download} Export JSON</button>
        </div>
      </div>

      <div className="hint-box mt">
        Godot 4 imports GLB natively; Unity uses the glTFast / com.unity.cloud.gltf importer.
        The package includes step-by-step docs (<span className="mono">tools/GODOT_IMPORT.md</span>,{' '}
        <span className="mono">tools/UNITY_IMPORT.md</span>) and per-target validation reports listing
        anything the target format cannot carry (e.g. water animation).
      </div>
    </DialogShell>
  );
}

/* ------------------------------------------------------------------ */

function ProvidersDialog(): React.ReactElement {
  const toggleDialog = useApp((s) => s.toggleDialog);
  const providerStatus = useApp((s) => s.providerStatus);
  const testProviders = useApp((s) => s.testProviders);
  const [tested, setTested] = useState(false);

  const providers = [
    {
      id: 'local-planner',
      name: 'Local Rule-Based Planner',
      kind: 'Built-in · free · offline',
      description: 'Deterministic NL → WorldPlan planning. Always available; no key required.',
      keyless: true,
    },
    {
      id: 'remote-llm',
      name: 'Remote LLM (OpenAI-compatible / Anthropic)',
      kind: 'Optional · via backend',
      description: 'Set OPENAI_API_KEY or ANTHROPIC_API_KEY (and optionally OPENAI_BASE_URL) in the server environment. Keys never reach the browser.',
      keyless: false,
      env: 'OPENAI_API_KEY / ANTHROPIC_API_KEY',
    },
    {
      id: 'procedural-3d',
      name: 'Procedural Modeling',
      kind: 'Built-in · free · offline',
      description: 'Parameterized prefab models (trees, houses, rocks, props). Honest procedural meshes — not AI-generated.',
      keyless: true,
    },
    {
      id: 'tripo-3d',
      name: 'Tripo 3D (text/image-to-3D)',
      kind: 'Optional · via backend',
      description: 'Real AI mesh generation through Tripo’s API. Set TRIPO_API_KEY in the server environment. Results import as GLB assets.',
      keyless: false,
      env: 'TRIPO_API_KEY',
    },
    {
      id: 'web-research',
      name: 'Web Research (Wikipedia + DuckDuckGo)',
      kind: 'Built-in · free',
      description: 'Searches public sources through the backend; results carry URLs + timestamps and are cached per project.',
      keyless: true,
    },
  ];

  return (
    <DialogShell
      title="AI Providers & connections"
      onClose={() => toggleDialog('providers', false)}
      footer={
        <>
          <button onClick={() => { void testProviders().then(() => setTested(true)); }}>
            {Icons.refresh} Test all connections
          </button>
          <button className="primary" onClick={() => toggleDialog('providers', false)}>Done</button>
        </>
      }
      wide
    >
      <div className="hint-box">
        All provider API keys live on the backend (server-side environment variables). The browser only ever
        sees provider status and results. No paid services are required — the app is fully functional offline
        with the built-in planner and procedural modeling.
      </div>

      <div className="card-list">
        {providers.map((p) => {
          const status = providerStatus[p.id];
          return (
            <div key={p.id} className="card" style={{ alignItems: 'flex-start' }}>
              <div className="info">
                <div className="title">
                  {p.name}{' '}
                  {p.keyless
                    ? <span className="badge ok">ready</span>
                    : status
                      ? <span className={`badge ${status.ok ? 'ok' : 'off'}`}>{status.ok ? 'connected' : 'not configured'}</span>
                      : <span className="badge warn">untested</span>}
                </div>
                <div className="subtitle">{p.kind}</div>
                <div className="subtitle" style={{ marginTop: 4 }}>{p.description}</div>
                {p.env && <div className="subtitle mono" style={{ marginTop: 3 }}>env: {p.env}</div>}
                {tested && status && <div className="subtitle" style={{ marginTop: 4 }}>→ {status.message}</div>}
              </div>
            </div>
          );
        })}
      </div>

      <div className="hint-box warn">
        When no 3D generation provider is configured, the app says so plainly and offers procedural modeling
        and the asset library instead — it never pretends a model was generated.
      </div>
    </DialogShell>
  );
}

/* ------------------------------------------------------------------ */

function ImportDialog(): React.ReactElement {
  const toggleDialog = useApp((s) => s.toggleDialog);
  const importPackFile = useApp((s) => s.importPackFile);
  const importFiles = useApp((s) => s.importFiles);
  const importPlanJson = useApp((s) => s.importPlanJson);
  const importedPack = useApp((s) => s.importedPack);
  const clearImportedPack = useApp((s) => s.clearImportedPack);
  const busy = useApp((s) => s.busy);
  const [drag, setDrag] = useState(false);
  const zipRef = useRef<HTMLInputElement>(null);
  const filesRef = useRef<HTMLInputElement>(null);
  const planRef = useRef<HTMLInputElement>(null);

  return (
    <DialogShell
      title="Import assets & plans"
      onClose={() => toggleDialog('import', false)}
      footer={
        <>
          {importedPack && <button onClick={clearImportedPack}>{Icons.x} Clear results</button>}
          <button className="primary" onClick={() => toggleDialog('import', false)}>Done</button>
        </>
      }
      wide
    >
      <div
        className={`file-drop ${drag ? 'drag' : ''}`}
        onClick={() => zipRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          const f = e.dataTransfer.files?.[0];
          if (f && /\.zip$/i.test(f.name)) void importPackFile(f);
          else if (f) void importFiles([f]);
        }}
      >
        <div style={{ fontSize: 26, marginBottom: 6 }}>{Icons.upload}</div>
        <strong>Drop an asset pack (.zip) or click to browse</strong>
        <div className="muted mt">
          ZIPs are extracted safely (path-traversal guarded, size limited). Files are scanned, classified and indexed —
          originals are never modified. License/attribution files are preserved with the pack.
        </div>
      </div>

      <div className="flex wrap mt">
        <button disabled={busy} onClick={() => zipRef.current?.click()}>{Icons.folder} Asset pack (.zip)</button>
        <button disabled={busy} onClick={() => filesRef.current?.click()}>{Icons.plus} Loose files (models/textures)</button>
        <button disabled={busy} onClick={() => planRef.current?.click()}>{Icons.map} WorldPlan JSON</button>
      </div>

      <input ref={zipRef} type="file" accept=".zip" style={{ display: 'none' }}
        onChange={(e) => { const f = e.target.files?.[0]; if (f) void importPackFile(f); }} />
      <input ref={filesRef} type="file" multiple style={{ display: 'none' }}
        onChange={(e) => { if (e.target.files) void importFiles(e.target.files); }} />
      <input ref={planRef} type="file" accept=".json,application/json" style={{ display: 'none' }}
        onChange={(e) => { const f = e.target.files?.[0]; if (f) void importPlanJson(f); }} />

      {importedPack && (
        <div className="mt">
          <div className="section-title">
            {importedPack.packName} — {importedPack.stats.total} files ({importedPack.stats.supported} supported,{' '}
            {importedPack.stats.unsupported} unsupported, {(importedPack.stats.bytes / 1024 / 1024).toFixed(1)} MB)
          </div>

          {(importedPack.license || importedPack.attribution) && (
            <div className="hint-box">
              {importedPack.attribution && <div><strong>Attribution:</strong> {importedPack.attribution.slice(0, 160)}</div>}
              {importedPack.license && <div><strong>License:</strong> {importedPack.license.slice(0, 160)}</div>}
            </div>
          )}

          <div className="card-list" style={{ maxHeight: 220, overflowY: 'auto' }}>
            {importedPack.files.slice(0, 60).map((f) => (
              <div key={f.classified.path} className="card" style={{ padding: '8px 12px' }}>
                <div className="info">
                  <div className="title" style={{ fontSize: 12 }}>
                    {f.classified.name}{' '}
                    <span className={`badge ${f.classified.supported ? 'ok' : 'warn'}`}>
                      {f.classified.supported ? 'supported' : 'unsupported'}
                    </span>
                  </div>
                  <div className="subtitle">
                    {f.classified.format} · {f.classified.kind} · {(f.classified.size / 1024).toFixed(1)} KB
                    {f.classified.tags.length ? ` · ${f.classified.tags.join(', ')}` : ''}
                  </div>
                  {f.classified.reason && <div className="subtitle" style={{ color: 'var(--yellow)' }}>{f.classified.reason}</div>}
                </div>
              </div>
            ))}
          </div>

          {importedPack.issues.length > 0 && (
            <>
              <div className="section-title mt">Issues ({importedPack.issues.length})</div>
              <div className="card-list" style={{ maxHeight: 150, overflowY: 'auto' }}>
                {importedPack.issues.map((issue, i) => (
                  <div key={i} className={`hint-box ${issue.severity === 'error' ? 'error' : 'warn'}`} style={{ margin: '2px 0' }}>
                    <strong>{issue.path}</strong> — {issue.message}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </DialogShell>
  );
}

/* ------------------------------------------------------------------ */

function AboutDialog(): React.ReactElement {
  const toggleDialog = useApp((s) => s.toggleDialog);
  return (
    <DialogShell
      title="About AI World Builder"
      onClose={() => toggleDialog('about', false)}
      footer={<button className="primary" onClick={() => toggleDialog('about', false)}>Close</button>}
    >
      <p style={{ lineHeight: 1.7 }}>
        A free-first, Blender-inspired 3D world creation platform: describe a world in natural language,
        inspect and edit the generated <strong>WorldPlan</strong>, and export to GLB / Godot / Unity.
      </p>
      <div className="hint-box">
        <div><strong>Stack:</strong> React + TypeScript + Vite · three.js viewport · Express backend for AI providers · IndexedDB persistence.</div>
        <div className="mt"><strong>Offline-first:</strong> the local rule-based planner and procedural generator work with no API keys and no network.</div>
        <div className="mt"><strong>Honesty policy:</strong> unconfigured providers are reported as such — the app never fakes AI output.</div>
      </div>
    </DialogShell>
  );
}
