import React from 'react';
import { useApp } from '../state/store';
import { Icons } from './icons';

const PANELS = [
  { id: 'viewport', label: 'View', icon: Icons.map },
  { id: 'hierarchy', label: 'Scene', icon: Icons.layers },
  { id: 'assets', label: 'Assets', icon: Icons.box },
  { id: 'properties', label: 'Props', icon: Icons.settings },
  { id: 'console', label: 'Console', icon: Icons.terminal },
] as const;

export function MobileNav(): React.ReactElement {
  const activeMobilePanel = useApp((s) => s.activeMobilePanel);
  const setMobilePanel = useApp((s) => s.setMobilePanel);

  return (
    <nav className="mobile-nav">
      {PANELS.map((p) => (
        <button
          key={p.id}
          className={activeMobilePanel === p.id ? 'active mobilenav-btn' : 'mobilenav-btn'}
          onClick={() => setMobilePanel(p.id)}
        >
          {p.icon}
          <span>{p.label}</span>
        </button>
      ))}
    </nav>
  );
}
