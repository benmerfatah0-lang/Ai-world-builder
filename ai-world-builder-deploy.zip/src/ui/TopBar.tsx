import React from 'react';
import { useApp } from '../state/store';
import { Icons } from './icons';
import { useInstallApp } from '../pwa';

export function TopBar(): React.ReactElement {
  const plan = useApp((s) => s.plan);
  const busy = useApp((s) => s.busy);
  const transformMode = useApp((s) => s.transformMode);
  const viewMode = useApp((s) => s.viewMode);
  const toggleDialog = useApp((s) => s.toggleDialog);
  const undo = useApp((s) => s.undo);
  const redo = useApp((s) => s.redo);
  const saveNow = useApp((s) => s.saveNow);
  const setTransformMode = useApp((s) => s.setTransformMode);
  const setViewMode = useApp((s) => s.setViewMode);
  const renameWorld = useApp((s) => s.renameWorld);
  const runGeneration = useApp((s) => s.runGeneration);
  const exportGlbFile = useApp((s) => s.exportGlbFile);
  const installApp = useInstallApp();

  return (
    <header className="topbar">
      <div className="logo">
        {Icons.logo}
        <span className="hide-mobile">AI World Builder</span>
        <span className="tag">FREE</span>
      </div>

      <input
        className="world-name-input"
        value={plan.name}
        onChange={(e) => renameWorld(e.target.value)}
        title="World name"
        aria-label="World name"
      />

      <div className="toolbar-group hide-mobile">
        <button className="ghost" onClick={() => toggleDialog('projects')} title="Projects (open, save, manage)">
          {Icons.folder}
        </button>
        <button className="ghost" onClick={() => void saveNow('save')} title="Save (Ctrl+S)">
          {Icons.save}
        </button>
        <button className="ghost" onClick={undo} title="Undo (Ctrl+Z)">
          {Icons.undo}
        </button>
        <button className="ghost" onClick={redo} title="Redo (Ctrl+Shift+Z)">
          {Icons.redo}
        </button>
      </div>

      <div className="toolbar-group">
        <button className={transformMode === 'translate' ? 'active' : ''} onClick={() => setTransformMode('translate')} title="Move (G)">
          {Icons.move}
        </button>
        <button className={transformMode === 'rotate' ? 'active' : ''} onClick={() => setTransformMode('rotate')} title="Rotate (R)">
          {Icons.rotate}
        </button>
        <button className={transformMode === 'scale' ? 'active' : ''} onClick={() => setTransformMode('scale')} title="Scale (S)">
          {Icons.scale}
        </button>
      </div>

      <div className="toolbar-group hide-mobile">
        {(['rendered', 'solid', 'wireframe'] as const).map((m) => (
          <button key={m} className={viewMode === m ? 'active' : ''} onClick={() => setViewMode(m)} title={`View: ${m}`}>
            {m === 'rendered' ? 'Rendered' : m === 'solid' ? 'Solid' : 'Wire'}
          </button>
        ))}
      </div>

      <div className="spacer" />

      <button className="ghost hide-mobile" onClick={() => toggleDialog('import')} title="Import assets / plans">
        {Icons.upload} <span className="hide-mobile">Import</span>
      </button>
      <button className="ghost hide-mobile" onClick={() => toggleDialog('export')} title="Export GLB / package">
        {Icons.download} <span className="hide-mobile">Export</span>
      </button>
      <button className="ghost hide-mobile" onClick={() => toggleDialog('providers')} title="AI provider settings">
        {Icons.settings}
      </button>
      {installApp.canInstall && (
        <button className="ghost install-app" onClick={() => void installApp.install()} title="Install AI World Builder on this device">
          {Icons.download} <span className="hide-mobile">Install</span>
        </button>
      )}
      <button className="primary" onClick={() => void (busy ? undefined : runGeneration())} disabled={busy} title="Generate world from current plan">
        {Icons.play} {busy ? 'Working…' : 'Generate'}
      </button>
    </header>
  );
}
