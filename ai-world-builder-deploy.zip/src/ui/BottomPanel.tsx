import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../state/store';
import { Icons } from './icons';

export function BottomPanel(): React.ReactElement {
  const [tab, setTab] = useState<'console' | 'jobs' | 'research'>('console');
  const [collapsed, setCollapsed] = useState(false);
  const logs = useApp((s) => s.logs);
  const jobs = useApp((s) => s.jobs);
  const research = useApp((s) => s.research);
  const clearLogs = useApp((s) => s.clearLogs);
  const searchResearch = useApp((s) => s.searchResearch);
  const [query, setQuery] = useState('');
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (tab === 'console') logEndRef.current?.scrollIntoView({ block: 'end' });
  }, [logs, tab]);

  return (
    <section className={`panel bottom-panel ${collapsed ? 'bottom-collapsed' : ''}`} style={{ borderRight: 'none', borderTop: '1px solid var(--border)' }}>
      <div className="panel-tabs" style={{ borderBottom: collapsed ? 'none' : undefined }}>
        <button className={tab === 'console' ? 'active' : ''} onClick={() => { setTab('console'); setCollapsed(false); }}>Console</button>
        <button className={tab === 'jobs' ? 'active' : ''} onClick={() => { setTab('jobs'); setCollapsed(false); }}>
          Jobs{jobs.some((j) => j.status === 'running') ? ' •' : ''}
        </button>
        <button className={tab === 'research' ? 'active' : ''} onClick={() => { setTab('research'); setCollapsed(false); }}>Research</button>
        <div style={{ flex: 1 }} />
        {tab === 'console' && !collapsed && (
          <button className="ghost" onClick={clearLogs} title="Clear console">{Icons.trash}</button>
        )}
        <button className="ghost" onClick={() => setCollapsed(!collapsed)} title={collapsed ? 'Expand panel' : 'Collapse panel'}>
          {collapsed ? '▲' : '▼'}
        </button>
      </div>

      {!collapsed && (
        <div className="panel-body" style={{ background: 'var(--bg-0)' }}>
          {tab === 'console' && (
            <>
              {logs.map((l) => (
                <div key={l.id} className={`console-line ${l.level}`}>
                  <span className="ts">{l.ts.slice(11, 19)}</span>
                  <span className="msg">{l.message}</span>
                </div>
              ))}
              <div ref={logEndRef} />
            </>
          )}

          {tab === 'jobs' && (
            <>
              {!jobs.length && <div className="section muted">No jobs yet. Generation runs as cancellable jobs with progress.</div>}
              {[...jobs].reverse().map((j) => (
                <div key={j.id} className="job-card">
                  <div className="row">
                    <span className="label">{j.label}</span>
                    <span className={`status ${j.status}`}>{j.status}</span>
                    {j.status === 'running' && j.token && (
                      <button className="small" onClick={() => { if (j.token) j.token.cancelled = true; }}>Cancel</button>
                    )}
                  </div>
                  {j.progress && (
                    <div className="progress-track">
                      <div className="progress-fill" style={{ width: `${(j.progress.current / Math.max(j.progress.total, 1)) * 100}%` }} />
                    </div>
                  )}
                  <div className="job-msg">{j.error ?? j.progress?.message ?? `${((j.finishedAt ?? Date.now()) - j.startedAt) / 1000 | 0}s`}</div>
                </div>
              ))}
            </>
          )}

          {tab === 'research' && (
            <div className="section">
              <div className="flex gap-sm">
                <input
                  placeholder='Research reference material… e.g. "medieval timber framing construction"'
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && query.trim()) void searchResearch(query); }}
                />
                <button className="primary" disabled={research.searching || !query.trim()} onClick={() => void searchResearch(query)}>
                  {research.searching ? 'Searching…' : 'Search'}
                </button>
              </div>

              {research.error && <div className="hint-box error mt">{research.error}</div>}

              <div className="card-list mt">
                {research.results.map((r) => (
                  <div key={r.url + r.retrievedAt} className="card">
                    <div className="info">
                      <div className="title">{r.title}</div>
                      <div className="subtitle">{r.snippet.slice(0, 180)}…</div>
                      <div className="subtitle mono">
                        <a href={r.url} target="_blank" rel="noreferrer" style={{ color: 'var(--accent)' }}>{r.url}</a>
                        {' · '}
                        {new Date(r.retrievedAt).toLocaleString()} · {r.provider} ·{' '}
                        <span className={`badge ${r.verified ? 'ok' : 'warn'}`}>{r.verified ? 'verified source' : 'unverified snippet'}</span>
                      </div>
                    </div>
                  </div>
                ))}
                {!research.results.length && !research.searching && (
                  <div className="muted">
                    Research results are cached with URLs and timestamps. The base model does not learn from pages —
                    retrieved sources live in your project reference library for retrieval-augmented context.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
