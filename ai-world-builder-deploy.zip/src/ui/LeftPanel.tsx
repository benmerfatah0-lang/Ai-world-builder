import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../state/store';
import { Icons } from './icons';
import { listPrefabs } from '../engine/entityFactory';

const KIND_ICONS: Record<string, string> = {
  tree: '🌲', bush: '🌿', rock: '🪨', grass: '🌾', flower: '🌸', cactus: '🌵', crystal: '💎', mushroom: '🍄',
  house: '🏠', hut: '🛖', tower: '🗼', castle: '🏰', bridge: '🌉', wall: '🧱', fence: '🚧', road: '🛤️',
  well: '⛲', lamp: '🏮', crate: '📦', barrel: '🛢️', bench: '🪑', campfire: '🔥', windmill: '🌬️',
  temple: '🏛️', ruin: '🏚️', farm: '🚜', dock: '⚓', boat: '⛵', custom: '🔷',
};

function placeableKindForPrefab(prefab: string): 'tree' | 'rock' | 'house' | 'hut' | 'tower' | 'wall' | 'bridge' | 'crate' | 'barrel' | 'bench' | 'lamp' | 'well' | 'campfire' | 'fence' | 'temple' | 'ruin' | 'windmill' | 'flower' | 'bush' | 'grass' | 'cactus' | 'crystal' | 'mushroom' | 'boat' | 'custom' {
  if (prefab.startsWith('tree')) return 'tree';
  if (prefab.startsWith('rock')) return 'rock';
  if (prefab.includes('house') || prefab.includes('barn')) return 'house';
  if (prefab.includes('hut')) return 'hut';
  if (prefab.includes('tower') || prefab.includes('gatehouse')) return 'tower';
  if (prefab.includes('wall')) return 'wall';
  if (prefab.includes('bridge')) return 'bridge';
  if (prefab.includes('temple')) return 'temple';
  if (prefab.includes('ruin') || prefab.includes('gravestone')) return 'ruin';
  if (prefab.includes('windmill')) return 'windmill';
  if (prefab.includes('crate')) return 'crate';
  if (prefab.includes('barrel')) return 'barrel';
  if (prefab.includes('bench')) return 'bench';
  if (prefab.includes('lamp')) return 'lamp';
  if (prefab.includes('well')) return 'well';
  if (prefab.includes('campfire')) return 'campfire';
  if (prefab.includes('fence')) return 'fence';
  if (prefab.includes('flower')) return 'flower';
  if (prefab.includes('bush')) return 'bush';
  if (prefab.includes('grass') || prefab.includes('crop')) return 'grass';
  if (prefab.includes('cactus')) return 'cactus';
  if (prefab.includes('crystal')) return 'crystal';
  if (prefab.includes('mushroom')) return 'mushroom';
  if (prefab.includes('boat')) return 'boat';
  return 'custom';
}

export function LeftPanel(): React.ReactElement {
  const [tab, setTab] = useState<'hierarchy' | 'assets'>('hierarchy');
  const [filter, setFilter] = useState('');
  const mobilePanel = useApp((s) => s.activeMobilePanel);

  // Keep the panel's internal tab aligned with the mobile nav.
  useEffect(() => {
    if (mobilePanel === 'assets') setTab('assets');
    else if (mobilePanel === 'hierarchy') setTab('hierarchy');
  }, [mobilePanel]);

  const plan = useApp((s) => s.plan);
  const derivedObjects = useApp((s) => s.derivedObjects);
  const selection = useApp((s) => s.selection);
  const setSelection = useApp((s) => s.setSelection);
  const placeAssetPrefab = useApp((s) => s.placeAssetPrefab);
  const toggleDialog = useApp((s) => s.toggleDialog);
  const importedPack = useApp((s) => s.importedPack);

  const allObjects = useMemo(() => [...plan.objects, ...derivedObjects], [plan.objects, derivedObjects]);
  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return allObjects;
    return allObjects.filter((o) =>
      (o.name ?? '').toLowerCase().includes(q) || o.kind.includes(q) || (o.prefab ?? '').includes(q) ||
      (o.tags ?? []).some((t) => t.includes(q)),
    );
  }, [allObjects, filter]);

  const prefabs = useMemo(() => listPrefabs().filter((p) => !filter || p.includes(filter.toLowerCase())), [filter]);

  return (
    <aside className="panel left-panel">
      <div className="panel-tabs">
        <button className={tab === 'hierarchy' ? 'active' : ''} onClick={() => setTab('hierarchy')}>Scene</button>
        <button className={tab === 'assets' ? 'active' : ''} onClick={() => setTab('assets')}>Assets</button>
      </div>

      <div className="section" style={{ paddingBottom: 8 }}>
        <input
          placeholder={tab === 'hierarchy' ? 'Filter objects…' : 'Filter prefabs…'}
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
      </div>

      <div className="panel-body">
        {tab === 'hierarchy' ? (
          <>
            <div className="section" style={{ display: 'flex', gap: 6, paddingTop: 6, paddingBottom: 6 }}>
              <button className="small" onClick={() => setSelection(allObjects.map((o) => o.id))}>Select all</button>
              <button className="small" onClick={() => setSelection([])}>Clear</button>
              <span className="muted" style={{ marginLeft: 'auto', fontSize: 11 }}>{filtered.length} objects</span>
            </div>

            {(plan.regions ?? []).length > 0 && (
              <div className="section" style={{ paddingTop: 8, paddingBottom: 6 }}>
                <div className="section-title">Regions</div>
                {(plan.regions ?? []).map((r) => (
                  <div key={r.id} className="hierarchy-item" onClick={() => setSelection([])} title={`Region ${r.kind} @ ${r.center.join(', ')}`}>
                    <span>📍</span>
                    <span className="name">{r.name ?? r.kind}</span>
                    <span className="kind">{r.kind}</span>
                  </div>
                ))}
              </div>
            )}

            {filtered.map((o) => (
              <div
                key={o.id}
                className={`hierarchy-item ${selection.includes(o.id) ? 'selected' : ''}`}
                onClick={(e) => {
                  if (e.shiftKey) {
                    setSelection(selection.includes(o.id) ? selection.filter((id) => id !== o.id) : [...selection, o.id]);
                  } else {
                    setSelection([o.id]);
                  }
                }}
              >
                <span>{KIND_ICONS[o.kind] ?? '🔷'}</span>
                <span className="name">{o.name ?? o.kind}</span>
                {o.instances && <span className="count">×{o.instances.length}</span>}
                <span className="kind">{o.kind}</span>
              </div>
            ))}
            {!filtered.length && (
              <div className="section muted">No objects yet — generate a world or add assets.</div>
            )}
          </>
        ) : (
          <>
            <div className="section" style={{ display: 'flex', gap: 6, paddingTop: 6, paddingBottom: 6 }}>
              <button className="small" onClick={() => toggleDialog('import')}>{Icons.upload} Import pack</button>
              <span className="muted" style={{ marginLeft: 'auto', fontSize: 11 }}>{prefabs.length} prefabs</span>
            </div>

            {importedPack && (
              <div className="section" style={{ paddingTop: 4 }}>
                <div className="hint-box" style={{ margin: '4px 0' }}>
                  Pack <strong>{importedPack.packName}</strong>: {importedPack.stats.supported} supported,{' '}
                  {importedPack.stats.unsupported} unsupported of {importedPack.stats.total} files.
                  {importedPack.license && <div className="mt">License: {importedPack.license.slice(0, 90)}…</div>}
                </div>
              </div>
            )}

            <div className="asset-grid">
              {prefabs.map((p) => {
                const kind = placeableKindForPrefab(p);
                return (
                  <div
                    key={p}
                    className="asset-card"
                    title={`Click to place ${p} at world origin — then move it with the gizmo`}
                    onClick={() => placeAssetPrefab(kind as never, p)}
                  >
                    <div className="icon">{KIND_ICONS[kind] ?? '🔷'}</div>
                    <div className="label">{p.split('.').slice(1).join('.') || p}</div>
                  </div>
                );
              })}
            </div>
            <div className="section muted" style={{ fontSize: 11, lineHeight: 1.6 }}>
              Click a prefab to place it at the origin; use Move (G) to position it.
              These are procedural meshes — generated AI meshes appear here too when a 3D generation provider is configured.
            </div>
          </>
        )}
      </div>
    </aside>
  );
}
