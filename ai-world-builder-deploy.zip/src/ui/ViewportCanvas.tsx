import React, { useEffect, useRef } from 'react';
import { useApp, setViewportRef } from '../state/store';
import { Viewport } from '../engine/Viewport';
import { Icons } from './icons';

export function ViewportCanvas(): React.ReactElement {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const viewportInstance = useRef<Viewport | null>(null);
  const plan = useApp((s) => s.plan);
  const heightfield = useApp((s) => s.heightfield);
  const selection = useApp((s) => s.selection);
  const generationStats = useApp((s) => s.generationStats);
  const busy = useApp((s) => s.busy);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const viewport = new Viewport(canvas, 'low-poly');
    viewportInstance.current = viewport;
    setViewportRef(viewport);

    const offTransform = viewport.events.on('transform', (t) => {
      useApp.getState().transformObject(t.id, t.position, t.rotation, t.scale, t.commit);
    });
    const offSelection = viewport.events.on('selection', (e) => {
      const state = useApp.getState();
      if (JSON.stringify(state.selection) !== JSON.stringify(e.ids)) {
        state.setSelection(e.ids);
      }
    });

    // Initial empty world so the viewport shows something immediately.
    void useApp.getState().newWorld();

    return () => {
      offTransform();
      offSelection();
      setViewportRef(null);
      viewport.dispose();
      viewportInstance.current = null;
    };
  }, []);

  // Keep viewport in sync with generation results.
  useEffect(() => {
    const viewport = viewportInstance.current;
    if (!viewport || !heightfield) return;
    viewport.setWorld({
      plan,
      heightfield,
      derivedObjects: useApp.getState().derivedObjects,
      derivedPaths: useApp.getState().derivedPaths,
    });
  }, [plan, heightfield, generationStats]);

  useEffect(() => {
    viewportInstance.current?.select(selection);
  }, [selection]);

  return (
    <div className="viewport-area">
      <canvas ref={canvasRef} />

      <div className="viewport-overlay">
        <div className="viewport-chip">
          {Icons.map} <strong>{plan.settings.style}</strong> · {plan.settings.size.widthMeters}×{plan.settings.size.depthMeters} m · seed {plan.seed}
        </div>
        {generationStats && (
          <div className="viewport-chip">
            {Icons.box} <strong>{generationStats.instanceCount.toLocaleString()}</strong> instances · {generationStats.objectCount} groups · {generationStats.durationMs} ms
          </div>
        )}
      </div>

      <div className="viewport-actions">
        <button className="viewport-chip" style={{ cursor: 'pointer' }} onClick={() => viewportInstance.current?.frameWorld()} title="Frame world">
          {Icons.camera} Frame
        </button>
        <button className="viewport-chip" style={{ cursor: 'pointer' }} onClick={() => viewportInstance.current?.frameSelection()} title="Frame selection">
          {Icons.search} Focus
        </button>
      </div>

      {busy && (
        <div className="empty-viewport" style={{ pointerEvents: 'none', justifyContent: 'flex-end', paddingBottom: 26 }}>
          <div className="viewport-chip" style={{ padding: '8px 16px' }}>
            <span className="statusbar" style={{ border: 'none', background: 'transparent', padding: 0, height: 'auto' }}>
              <span className="dot busy" /> Generating world…
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
