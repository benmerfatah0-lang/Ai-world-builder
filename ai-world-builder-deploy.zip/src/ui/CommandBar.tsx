import React, { useState } from 'react';
import { useApp } from '../state/store';
import { Icons } from './icons';

export function CommandBar(): React.ReactElement {
  const [local, setLocal] = useState('');
  const worldPrompt = useApp((s) => s.worldPrompt);
  const setWorldPrompt = useApp((s) => s.setWorldPrompt);
  const command = useApp((s) => s.command);
  const busy = useApp((s) => s.busy);
  const generateWorldFromPrompt = useApp((s) => s.generateWorldFromPrompt);
  const runCommand = useApp((s) => s.runCommand);
  const applyPendingCommand = useApp((s) => s.applyPendingCommand);
  const discardPendingCommand = useApp((s) => s.discardPendingCommand);

  return (
    <div className="command-bar">
      <div className="command-input-wrap">
        <span className="prompt-icon">✧</span>
        <input
          placeholder='Describe your world… "a snowy mountain village at sunset with a frozen lake"'
          value={worldPrompt}
          onChange={(e) => setWorldPrompt(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !busy) void generateWorldFromPrompt(worldPrompt);
          }}
          aria-label="World description"
        />
        <button className="primary" disabled={busy || !worldPrompt.trim()} onClick={() => void generateWorldFromPrompt(worldPrompt)}>
          {Icons.play} Generate world
        </button>
      </div>

      <div className="command-input-wrap" style={{ maxWidth: 380 }}>
        <span className="prompt-icon" style={{ color: 'var(--purple)' }}>›</span>
        <input
          placeholder='Editor command… "add three pines near the lake"'
          value={local}
          onChange={(e) => setLocal(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && local.trim()) {
              void runCommand(local);
              setLocal('');
            }
          }}
          aria-label="Editor command"
        />
        <button disabled={busy || !local.trim()} onClick={() => { void runCommand(local); setLocal(''); }}>
          Run
        </button>
      </div>

      {command.pendingPreview ? (
        <div className="flex gap-sm wrap">
          <span className="viewport-chip" style={{ borderColor: 'var(--yellow)' }}>
            Preview: {command.pendingPreview.summary.join(' · ')}
          </span>
          <button className="primary small" onClick={() => void applyPendingCommand()}>Apply</button>
          <button className="ghost small" onClick={discardPendingCommand}>Discard</button>
        </div>
      ) : command.lastSummary ? (
        <span className="command-hint">{command.lastSummary}</span>
      ) : (
        <span className="command-hint hide-mobile">Natural-language commands · preview before apply</span>
      )}
    </div>
  );
}
