/**
 * Snapshot-based undo/redo history (bounded). Snapshots are plain WorldPlan
 * JSON documents — small enough that snapshotting is cheap and bulletproof.
 */
import type { WorldPlan } from '../types';

export class PlanHistory {
  private past: WorldPlan[] = [];
  private present: WorldPlan;
  private future: WorldPlan[] = [];
  private readonly limit: number;

  constructor(initial: WorldPlan, limit = 64) {
    this.present = structuredClone(initial);
    this.limit = limit;
  }

  get current(): WorldPlan {
    return this.present;
  }

  get canUndo(): boolean {
    return this.past.length > 0;
  }

  get canRedo(): boolean {
    return this.future.length > 0;
  }

  get undoLabel(): string | null {
    return this.past.length ? 'Undo' : null;
  }

  commit(next: WorldPlan): void {
    this.past.push(this.present);
    if (this.past.length > this.limit) this.past.shift();
    this.present = structuredClone(next);
    this.future = [];
  }

  /** Replace present without creating an undo entry (e.g. live transform drags). */
  replacePresent(next: WorldPlan): void {
    this.present = structuredClone(next);
  }

  undo(): WorldPlan | null {
    if (!this.past.length) return null;
    this.future.push(this.present);
    this.present = this.past.pop()!;
    return this.present;
  }

  redo(): WorldPlan | null {
    if (!this.future.length) return null;
    this.past.push(this.present);
    this.present = this.future.pop()!;
    return this.present;
  }

  reset(plan: WorldPlan): void {
    this.past = [];
    this.future = [];
    this.present = structuredClone(plan);
  }
}
