/**
 * Pure WorldPlan operations. Every editor action becomes one of these ops so
 * undo/redo, autosave, sync to the viewport and job cancellation stay simple.
 */
import type { WorldPlan, WorldObject, Region, PathSpec, Biome, Vec3 } from '../types';
import { newId } from '../types';

export type PlanOp =
  | { type: 'setPlan'; plan: WorldPlan }
  | { type: 'renameWorld'; name: string }
  | { type: 'setSettings'; patch: Partial<WorldPlan['settings']> }
  | { type: 'setSeed'; seed: number }
  | { type: 'addObject'; object: WorldObject }
  | { type: 'removeObject'; id: string }
  | { type: 'updateObject'; id: string; patch: Partial<WorldObject> }
  | { type: 'transformObject'; id: string; position?: Vec3; rotation?: Vec3; scale?: Vec3 | number }
  | { type: 'duplicateObject'; id: string }
  | { type: 'addObjects'; objects: WorldObject[] }
  | { type: 'removeObjects'; ids: string[] }
  | { type: 'addRegion'; region: Region }
  | { type: 'removeRegion'; id: string }
  | { type: 'updateRegion'; id: string; patch: Partial<Region> }
  | { type: 'addPath'; path: PathSpec }
  | { type: 'removePath'; id: string }
  | { type: 'setTerrain'; patch: Partial<WorldPlan['terrain']> }
  | { type: 'setBiomes'; biomes: Biome[] }
  | { type: 'setLighting'; patch: NonNullable<WorldPlan['lighting']> }
  | { type: 'regenerateObjects'; ids: string[]; objects: WorldObject[] };

export interface PlanOpResult {
  plan: WorldPlan;
  /** Human-readable summary used by undo history and the job log. */
  label: string;
}

function touch<T extends { updatedAt?: string }>(plan: T): T {
  return { ...plan, updatedAt: new Date().toISOString() };
}

export function applyOp(plan: WorldPlan, op: PlanOp): PlanOpResult {
  switch (op.type) {
    case 'setPlan':
      return { plan: op.plan, label: 'Load plan' };

    case 'renameWorld':
      return { plan: touch({ ...plan, name: op.name }), label: `Rename world to "${op.name}"` };

    case 'setSettings':
      return {
        plan: touch({
          ...plan,
          settings: {
            ...plan.settings,
            ...op.patch,
            size: { ...plan.settings.size, ...(op.patch.size ?? {}) },
            density: { ...plan.settings.density, ...(op.patch.density ?? {}) },
            environment: { ...plan.settings.environment, ...(op.patch.environment ?? {}) },
          },
        }),
        label: 'Update world settings',
      };

    case 'setSeed':
      return { plan: touch({ ...plan, seed: op.seed }), label: `Set seed to ${op.seed}` };

    case 'addObject':
      return { plan: touch({ ...plan, objects: [...plan.objects, op.object] }), label: `Add ${op.object.kind}` };

    case 'addObjects':
      return { plan: touch({ ...plan, objects: [...plan.objects, ...op.objects] }), label: `Add ${op.objects.length} objects` };

    case 'removeObject':
      return {
        plan: touch({ ...plan, objects: plan.objects.filter((o) => o.id !== op.id) }),
        label: 'Remove object',
      };

    case 'removeObjects': {
      const ids = new Set(op.ids);
      return {
        plan: touch({ ...plan, objects: plan.objects.filter((o) => !ids.has(o.id)) }),
        label: `Remove ${op.ids.length} objects`,
      };
    }

    case 'updateObject':
      return {
        plan: touch({
          ...plan,
          objects: plan.objects.map((o) => (o.id === op.id ? { ...o, ...op.patch, id: o.id } : o)),
        }),
        label: 'Update object',
      };

    case 'transformObject':
      return {
        plan: touch({
          ...plan,
          objects: plan.objects.map((o) =>
            o.id === op.id
              ? {
                  ...o,
                  position: op.position ?? o.position,
                  rotation: op.rotation ?? o.rotation,
                  scale: op.scale ?? o.scale,
                }
              : o,
          ),
        }),
        label: 'Transform object',
      };

    case 'duplicateObject': {
      const src = plan.objects.find((o) => o.id === op.id);
      if (!src) return { plan, label: 'Duplicate failed (not found)' };
      const copy: WorldObject = {
        ...src,
        id: newId(src.kind),
        name: src.name ? `${src.name} copy` : undefined,
        position: [src.position[0] + 2, src.position[1], src.position[2] + 2],
        meta: { ...(src.meta ?? {}), duplicatedFrom: src.id },
      };
      return { plan: touch({ ...plan, objects: [...plan.objects, copy] }), label: `Duplicate ${src.kind}` };
    }

    case 'addRegion':
      return { plan: touch({ ...plan, regions: [...(plan.regions ?? []), op.region] }), label: `Add region ${op.region.kind}` };

    case 'removeRegion':
      return {
        plan: touch({ ...plan, regions: (plan.regions ?? []).filter((r) => r.id !== op.id) }),
        label: 'Remove region',
      };

    case 'updateRegion':
      return {
        plan: touch({
          ...plan,
          regions: (plan.regions ?? []).map((r) => (r.id === op.id ? { ...r, ...op.patch, id: r.id } : r)),
        }),
        label: 'Update region',
      };

    case 'addPath':
      return { plan: touch({ ...plan, paths: [...(plan.paths ?? []), op.path] }), label: `Add ${op.path.kind}` };

    case 'removePath':
      return {
        plan: touch({ ...plan, paths: (plan.paths ?? []).filter((p) => p.id !== op.id) }),
        label: 'Remove path',
      };

    case 'setTerrain':
      return {
        plan: touch({ ...plan, terrain: { ...plan.terrain, ...op.patch } }),
        label: 'Update terrain',
      };

    case 'setBiomes':
      return { plan: touch({ ...plan, biomes: op.biomes }), label: 'Update biomes' };

    case 'setLighting':
      return { plan: touch({ ...plan, lighting: { ...(plan.lighting ?? {}), ...op.patch } }), label: 'Update lighting' };

    case 'regenerateObjects': {
      const ids = new Set(op.ids);
      return {
        plan: touch({
          ...plan,
          objects: [...plan.objects.filter((o) => !ids.has(o.id)), ...op.objects],
        }),
        label: `Regenerate ${op.ids.length} objects`,
      };
    }

    default: {
      const never: never = op;
      return { plan, label: `Unknown op ${JSON.stringify(never)}` };
    }
  }
}

/* ------------------------------------------------------------------ */
/* Diff (used for "preview changes before applying")                   */
/* ------------------------------------------------------------------ */

export interface PlanDiff {
  added: WorldObject[];
  removed: WorldObject[];
  changed: Array<{ before: WorldObject; after: WorldObject }>;
  settingsChanged: boolean;
  terrainChanged: boolean;
  regionDelta: { added: number; removed: number };
  summary: string[];
}

export function diffPlans(a: WorldPlan, b: WorldPlan): PlanDiff {
  const aMap = new Map(a.objects.map((o) => [o.id, o]));
  const bMap = new Map(b.objects.map((o) => [o.id, o]));
  const added: WorldObject[] = [];
  const removed: WorldObject[] = [];
  const changed: Array<{ before: WorldObject; after: WorldObject }> = [];

  for (const [id, ob] of bMap) {
    const before = aMap.get(id);
    if (!before) added.push(ob);
    else if (JSON.stringify(before) !== JSON.stringify(ob)) changed.push({ before, after: ob });
  }
  for (const [id, ob] of aMap) if (!bMap.has(id)) removed.push(ob);

  const settingsChanged = JSON.stringify(a.settings) !== JSON.stringify(b.settings);
  const terrainChanged = JSON.stringify(a.terrain) !== JSON.stringify(b.terrain);
  const aReg = a.regions ?? [];
  const bReg = b.regions ?? [];
  const aRegIds = new Set(aReg.map((r) => r.id));
  const bRegIds = new Set(bReg.map((r) => r.id));
  const regionDelta = {
    added: [...bRegIds].filter((id) => !aRegIds.has(id)).length,
    removed: [...aRegIds].filter((id) => !bRegIds.has(id)).length,
  };

  const summary: string[] = [];
  if (added.length) summary.push(`+${added.length} objects`);
  if (removed.length) summary.push(`-${removed.length} objects`);
  if (changed.length) summary.push(`~${changed.length} objects changed`);
  if (regionDelta.added) summary.push(`+${regionDelta.added} regions`);
  if (regionDelta.removed) summary.push(`-${regionDelta.removed} regions`);
  if (settingsChanged) summary.push('settings changed');
  if (terrainChanged) summary.push('terrain changed');
  if (!summary.length) summary.push('no changes');

  return { added, removed, changed, settingsChanged, terrainChanged, regionDelta, summary };
}
