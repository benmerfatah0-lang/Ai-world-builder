/**
 * WorldPlan — the versioned, editable intermediate representation of a world.
 *
 * Everything the viewport renders is derived deterministically from a WorldPlan
 * plus its seed. The AI produces a WorldPlan; the editor edits a WorldPlan;
 * generators execute a WorldPlan; exporters serialize a WorldPlan.
 *
 * Schema document: schemas/worldplan.schema.json (JSON Schema draft-07).
 * Keep `SCHEMA_VERSION`, `validateWorldPlan` and the JSON schema in sync.
 */

export const SCHEMA_VERSION = '1.0.0';

export type ArtStyle = 'realistic' | 'stylized' | 'cartoon' | 'low-poly' | 'voxel' | 'custom';
export type QualityPreset = 'draft' | 'standard' | 'high';
export type Weather = 'clear' | 'cloudy' | 'rain' | 'snow' | 'storm' | 'fog';
export type SkyPreset = 'day' | 'sunset' | 'night' | 'dawn' | 'overcast';

export type BiomeType =
  | 'plains' | 'forest' | 'desert' | 'snow' | 'tundra' | 'swamp' | 'volcanic'
  | 'beach' | 'ocean' | 'lake' | 'river' | 'canyon' | 'mountains' | 'hills' | 'island' | 'custom';

export type TerrainGeneratorKind = 'fbm' | 'islands' | 'canyons' | 'mountains' | 'flat';

export type TerrainFeatureType =
  | 'mountain' | 'hill' | 'valley' | 'cliff' | 'canyon' | 'crater' | 'lake' | 'river' | 'beach' | 'plateau';

export type RegionKind =
  | 'forest' | 'village' | 'city' | 'castle' | 'farm' | 'ruins' | 'temple' | 'industrial'
  | 'camp' | 'harbor' | 'quarry' | 'meadow' | 'orchard' | 'graveyard' | 'custom';

export type PathKind = 'road' | 'path' | 'river' | 'stream' | 'fence' | 'wall';

export type ObjectKind =
  | 'tree' | 'bush' | 'rock' | 'grass' | 'flower' | 'cactus' | 'crystal' | 'mushroom'
  | 'house' | 'hut' | 'tower' | 'castle' | 'bridge' | 'wall' | 'fence' | 'road' | 'path'
  | 'well' | 'lamp' | 'crate' | 'barrel' | 'bench' | 'campfire' | 'windmill' | 'temple'
  | 'ruin' | 'farm' | 'dock' | 'boat' | 'custom';

export type Vec2 = [number, number];
export type Vec3 = [number, number, number];

export interface MaterialOverride {
  color?: string;
  roughness?: number;
  metalness?: number;
  emissive?: string;
  flatShading?: boolean;
}

export interface ObjectInstance {
  position: Vec3;
  rotation?: Vec3;
  scale?: Vec3 | number;
}

export interface WorldObject {
  id: string;
  name?: string;
  kind: ObjectKind;
  /** Prefab identifier inside the asset library / generator catalog, e.g. "tree.oak_a". */
  prefab?: string;
  position: Vec3;
  rotation?: Vec3;
  scale?: Vec3 | number;
  material?: MaterialOverride;
  tags?: string[];
  locked?: boolean;
  /** Clustered scatter: when present, this object renders as an instanced cluster. */
  instances?: ObjectInstance[];
  meta?: Record<string, unknown>;
}

export interface Biome {
  id: string;
  type: BiomeType;
  center: Vec2;
  radius: number;
  weight?: number;
  params?: Record<string, unknown>;
}

export interface TerrainFeature {
  id: string;
  type: TerrainFeatureType;
  position: Vec2;
  radius?: number;
  height?: number;
  falloff?: number;
  params?: Record<string, unknown>;
}

export interface TerrainSpec {
  generator: TerrainGeneratorKind;
  params?: {
    octaves?: number;
    frequency?: number;
    amplitude?: number;
    ridgeMix?: number;
    persistence?: number;
    lacunarity?: number;
    terracing?: number;
    warpStrength?: number;
  };
  waterLevel: number;
  features?: TerrainFeature[];
}

export interface Region {
  id: string;
  kind: RegionKind;
  name?: string;
  center: Vec2;
  radius: number;
  params?: Record<string, unknown>;
  source?: 'ai' | 'user' | 'procedural';
}

export interface PathSpec {
  id: string;
  kind: PathKind;
  width: number;
  points: Vec2[];
  params?: Record<string, unknown>;
}

export interface LightingSpec {
  sunAzimuth?: number;
  sunElevation?: number;
  sunColor?: string;
  sunIntensity?: number;
  ambientColor?: string;
  ambientIntensity?: number;
  shadows?: boolean;
}

export interface AssetRecord {
  id: string;
  name: string;
  kind: 'model' | 'texture' | 'material' | 'image' | 'other';
  source?: 'user' | 'library' | 'generated';
  filename?: string;
  license?: string;
  attribution?: string;
  tags?: string[];
  meta?: Record<string, unknown>;
}

export interface ProvenanceEntry {
  type: 'ai' | 'user' | 'procedural' | 'research';
  detail?: string;
  ts?: string;
}

export interface WorldSettings {
  style: ArtStyle;
  size: {
    widthMeters: number;
    depthMeters: number;
    heightScale?: number;
  };
  density: {
    vegetation?: number;
    props?: number;
    structures?: number;
  };
  quality: QualityPreset;
  environment?: {
    timeOfDay?: number;
    weather?: Weather;
    fogDensity?: number;
    skyPreset?: SkyPreset;
  };
}

export interface WorldPlan {
  schemaVersion: string;
  id: string;
  name: string;
  createdAt?: string;
  updatedAt?: string;
  seed: number;
  settings: WorldSettings;
  biomes?: Biome[];
  terrain: TerrainSpec;
  regions?: Region[];
  paths?: PathSpec[];
  objects: WorldObject[];
  lighting?: LightingSpec;
  assets?: AssetRecord[];
  meta: {
    generator: string;
    notes?: string[];
    provenance?: ProvenanceEntry[];
  };
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

export function createEmptyPlan(overrides: Partial<WorldPlan> = {}): WorldPlan {
  const now = new Date().toISOString();
  return {
    schemaVersion: SCHEMA_VERSION,
    id: overrides.id ?? newId(),
    name: overrides.name ?? 'Untitled World',
    createdAt: now,
    updatedAt: now,
    seed: overrides.seed ?? 1337,
    settings: overrides.settings ?? {
      style: 'low-poly',
      size: { widthMeters: 256, depthMeters: 256, heightScale: 48 },
      density: { vegetation: 0.6, props: 0.5, structures: 0.5 },
      quality: 'standard',
      environment: { timeOfDay: 10.5, weather: 'clear', fogDensity: 0.006, skyPreset: 'day' },
    },
    biomes: overrides.biomes ?? [
      { id: 'biome-main', type: 'plains', center: [0, 0], radius: 200, weight: 1 },
    ],
    terrain: overrides.terrain ?? {
      generator: 'fbm',
      params: { octaves: 5, frequency: 0.008, amplitude: 28, ridgeMix: 0.35, persistence: 0.5, lacunarity: 2.1, terracing: 0, warpStrength: 0.15 },
      waterLevel: 2.5,
      features: [],
    },
    regions: overrides.regions ?? [],
    paths: overrides.paths ?? [],
    objects: overrides.objects ?? [],
    lighting: overrides.lighting ?? {
      sunAzimuth: 120,
      sunElevation: 48,
      sunColor: '#fff4e0',
      sunIntensity: 2.4,
      ambientColor: '#9db8d6',
      ambientIntensity: 0.85,
      shadows: true,
    },
    assets: overrides.assets ?? [],
    meta: overrides.meta ?? {
      generator: 'local-planner',
      notes: [],
      provenance: [{ type: 'user', detail: 'plan created', ts: now }],
    },
  };
}

let idCounter = 0;
export function newId(prefix = 'id'): string {
  idCounter += 1;
  const rand = Math.floor(Math.random() * 0xffffff).toString(36);
  return `${prefix}-${Date.now().toString(36)}-${idCounter.toString(36)}-${rand}`;
}
