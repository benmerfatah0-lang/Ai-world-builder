/**
 * Hand-rolled WorldPlan validator mirroring schemas/worldplan.schema.json.
 * Kept dependency-free so it runs in the browser, the Node backend and tests.
 */
import type { WorldPlan } from '../types';
import { SCHEMA_VERSION } from '../types';

export interface ValidationIssue {
  path: string;
  message: string;
  severity: 'error' | 'warning';
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
}

const ART_STYLES = ['realistic', 'stylized', 'cartoon', 'low-poly', 'voxel', 'custom'];
const QUALITIES = ['draft', 'standard', 'high'];
const WEATHERS = ['clear', 'cloudy', 'rain', 'snow', 'storm', 'fog'];
const SKIES = ['day', 'sunset', 'night', 'dawn', 'overcast'];
const TERRAIN_GENERATORS = ['fbm', 'islands', 'canyons', 'mountains', 'flat'];

function isObj(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function isVec(v: unknown, n: number): boolean {
  return Array.isArray(v) && v.length === n && v.every((x) => typeof x === 'number' && Number.isFinite(x));
}

export function validateWorldPlan(input: unknown): ValidationResult {
  const issues: ValidationIssue[] = [];
  const err = (path: string, message: string) => issues.push({ path, message, severity: 'error' });
  const warn = (path: string, message: string) => issues.push({ path, message, severity: 'warning' });

  if (!isObj(input)) {
    err('$', 'WorldPlan must be an object');
    return { valid: false, issues };
  }
  const p = input as Partial<WorldPlan> & Record<string, unknown>;

  if (typeof p.schemaVersion !== 'string') err('schemaVersion', 'required string');
  else if (!/^1\.\d+\.\d+$/.test(p.schemaVersion)) err('schemaVersion', 'must match 1.x.x');

  if (typeof p.id !== 'string' || !p.id) err('id', 'required non-empty string');
  if (typeof p.name !== 'string' || !p.name) err('name', 'required non-empty string');
  if (typeof p.seed !== 'number' || !Number.isInteger(p.seed) || p.seed < 0) err('seed', 'required non-negative integer');

  if (!isObj(p.settings)) {
    err('settings', 'required object');
  } else {
    const s = p.settings;
    if (typeof s.style !== 'string' || !ART_STYLES.includes(s.style)) err('settings.style', `must be one of ${ART_STYLES.join(', ')}`);
    if (!isObj(s.size)) err('settings.size', 'required object');
    else {
      const sz = s.size as Record<string, unknown>;
      if (typeof sz.widthMeters !== 'number' || sz.widthMeters < 32 || sz.widthMeters > 4096) err('settings.size.widthMeters', 'number in [32, 4096]');
      if (typeof sz.depthMeters !== 'number' || sz.depthMeters < 32 || sz.depthMeters > 4096) err('settings.size.depthMeters', 'number in [32, 4096]');
    }
    if (!isObj(s.density)) err('settings.density', 'required object');
    else {
      for (const k of ['vegetation', 'props', 'structures'] as const) {
        const v = (s.density as Record<string, unknown>)[k];
        if (v !== undefined && (typeof v !== 'number' || v < 0 || v > 1)) err(`settings.density.${k}`, 'number in [0, 1]');
      }
    }
    if (typeof s.quality !== 'string' || !QUALITIES.includes(s.quality)) err('settings.quality', `must be one of ${QUALITIES.join(', ')}`);
    if (s.environment !== undefined) {
      if (!isObj(s.environment)) err('settings.environment', 'must be object');
      else {
        const e = s.environment as Record<string, unknown>;
        if (e.weather !== undefined && (typeof e.weather !== 'string' || !WEATHERS.includes(e.weather))) err('settings.environment.weather', `must be one of ${WEATHERS.join(', ')}`);
        if (e.skyPreset !== undefined && (typeof e.skyPreset !== 'string' || !SKIES.includes(e.skyPreset))) err('settings.environment.skyPreset', `must be one of ${SKIES.join(', ')}`);
        if (e.timeOfDay !== undefined && (typeof e.timeOfDay !== 'number' || e.timeOfDay < 0 || e.timeOfDay > 24)) err('settings.environment.timeOfDay', 'number in [0, 24]');
      }
    }
  }

  if (!isObj(p.terrain)) {
    err('terrain', 'required object');
  } else {
    const t = p.terrain;
    if (typeof t.generator !== 'string' || !TERRAIN_GENERATORS.includes(t.generator)) err('terrain.generator', `must be one of ${TERRAIN_GENERATORS.join(', ')}`);
    if (typeof t.waterLevel !== 'number') err('terrain.waterLevel', 'required number');
    if (t.features !== undefined) {
      if (!Array.isArray(t.features)) err('terrain.features', 'must be array');
      else t.features.forEach((f, i) => {
        if (!isObj(f)) return err(`terrain.features[${i}]`, 'must be object');
        if (typeof f.id !== 'string') err(`terrain.features[${i}].id`, 'required string');
        if (typeof f.type !== 'string') err(`terrain.features[${i}].type`, 'required string');
        if (!isVec(f.position, 2)) err(`terrain.features[${i}].position`, 'must be [x, z]');
      });
    }
  }

  if (p.biomes !== undefined) {
    if (!Array.isArray(p.biomes)) err('biomes', 'must be array');
    else p.biomes.forEach((b, i) => {
      if (!isObj(b)) return err(`biomes[${i}]`, 'must be object');
      if (typeof b.id !== 'string') err(`biomes[${i}].id`, 'required string');
      if (typeof b.type !== 'string') err(`biomes[${i}].type`, 'required string');
      if (!isVec(b.center, 2)) err(`biomes[${i}].center`, 'must be [x, z]');
      if (typeof b.radius !== 'number' || b.radius <= 0) err(`biomes[${i}].radius`, 'must be > 0');
    });
  }

  if (p.regions !== undefined) {
    if (!Array.isArray(p.regions)) err('regions', 'must be array');
    else p.regions.forEach((r, i) => {
      if (!isObj(r)) return err(`regions[${i}]`, 'must be object');
      if (typeof r.id !== 'string') err(`regions[${i}].id`, 'required string');
      if (typeof r.kind !== 'string') err(`regions[${i}].kind`, 'required string');
      if (!isVec(r.center, 2)) err(`regions[${i}].center`, 'must be [x, z]');
      if (typeof r.radius !== 'number' || r.radius <= 0) err(`regions[${i}].radius`, 'must be > 0');
    });
  }

  if (p.paths !== undefined) {
    if (!Array.isArray(p.paths)) err('paths', 'must be array');
    else p.paths.forEach((pa, i) => {
      if (!isObj(pa)) return err(`paths[${i}]`, 'must be object');
      if (typeof pa.id !== 'string') err(`paths[${i}].id`, 'required string');
      if (typeof pa.kind !== 'string') err(`paths[${i}].kind`, 'required string');
      if (!Array.isArray(pa.points) || pa.points.length < 2 || !pa.points.every((pt) => isVec(pt, 2))) {
        err(`paths[${i}].points`, 'must be an array of >= 2 [x, z] points');
      }
    });
  }

  if (!Array.isArray(p.objects)) {
    err('objects', 'required array');
  } else {
    const seen = new Set<string>();
    p.objects.forEach((o, i) => {
      if (!isObj(o)) return err(`objects[${i}]`, 'must be object');
      if (typeof o.id !== 'string' || !o.id) err(`objects[${i}].id`, 'required non-empty string');
      else if (seen.has(o.id)) err(`objects[${i}].id`, `duplicate id "${o.id}"`);
      else seen.add(o.id);
      if (typeof o.kind !== 'string' || !o.kind) err(`objects[${i}].kind`, 'required string');
      if (!isVec(o.position, 3)) err(`objects[${i}].position`, 'must be [x, y, z]');
      if (o.rotation !== undefined && !isVec(o.rotation, 3)) err(`objects[${i}].rotation`, 'must be [x, y, z]');
      if (o.instances !== undefined) {
        if (!Array.isArray(o.instances)) err(`objects[${i}].instances`, 'must be array');
        else o.instances.forEach((inst, j) => {
          if (!isObj(inst) || !isVec(inst.position, 3)) err(`objects[${i}].instances[${j}].position`, 'must be [x, y, z]');
        });
      }
    });
  }

  if (!isObj(p.meta) || typeof p.meta.generator !== 'string') {
    err('meta.generator', 'required string');
  }

  if (typeof p.schemaVersion === 'string' && p.schemaVersion !== SCHEMA_VERSION) {
    warn('schemaVersion', `plan is ${p.schemaVersion}, current schema is ${SCHEMA_VERSION} — run migration`);
  }

  return { valid: issues.filter((i) => i.severity === 'error').length === 0, issues };
}
