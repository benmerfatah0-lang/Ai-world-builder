import React, { useEffect } from 'react';
import { useApp } from './state/store';
import { TopBar } from './ui/TopBar';
import { CommandBar } from './ui/CommandBar';
import { LeftPanel } from './ui/LeftPanel';
import { RightPanel } from './ui/RightPanel';
import { ViewportCanvas } from './ui/ViewportCanvas';
import { BottomPanel } from './ui/BottomPanel';
import { StatusBar } from './ui/StatusBar';
import { MobileNav } from './ui/MobileNav';
import { Dialogs } from './ui/Dialogs';

export default function App(): React.ReactElement {
  const activeMobilePanel = useApp((s) => s.activeMobilePanel);

  // Global keyboard shortcuts.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);
      const mod = e.ctrlKey || e.metaKey;

      if (mod && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        if (!typing) { e.preventDefault(); useApp.getState().undo(); }
        return;
      }
      if (mod && (e.key.toLowerCase() === 'y' || (e.key.toLowerCase() === 'z' && e.shiftKey))) {
        if (!typing) { e.preventDefault(); useApp.getState().redo(); }
        return;
      }
      if (mod && e.key.toLowerCase() === 's') {
        e.preventDefault();
        void useApp.getState().saveNow('save');
        return;
      }
      if (mod && e.key.toLowerCase() === 'd' && !typing) {
        e.preventDefault();
        useApp.getState().duplicateSelection();
        return;
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && !typing) {
        e.preventDefault();
        useApp.getState().deleteSelection();
        return;
      }
      if (!typing && !mod) {
        const s = useApp.getState();
        if (e.key === 'g' || e.key === 'w') s.setTransformMode('translate');
        if (e.key === 'r') s.setTransformMode('rotate');
        if (e.key === 's') s.setTransformMode('scale');
        if (e.key === 'f') s.setSelection(s.selection);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const panelClass =
    activeMobilePanel === 'hierarchy' ? 'show-hierarchy'
      : activeMobilePanel === 'assets' ? 'show-assets'
        : activeMobilePanel === 'properties' ? 'show-properties'
          : activeMobilePanel === 'console' ? 'show-console'
            : '';

  return (
    <div className={`app ${panelClass}`}>
      <TopBar />
      <CommandBar />
      <LeftPanel />
      <ViewportCanvas />
      <RightPanel />
      <BottomPanel />
      <MobileNav />
      <StatusBar />
      <Dialogs />
    </div>
  );
}
