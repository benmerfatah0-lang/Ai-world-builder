/**
 * In-memory KeyValueStore implementing the same surface as db.KeyValueStore.
 * Used by unit tests and as a fallback when IndexedDB is unavailable.
 */
import type { ProjectRecord, CheckpointRecord, BlobRecord } from './db';

export class MemoryKeyValueStore {
  private projects = new Map<string, ProjectRecord>();
  private checkpoints = new Map<string, CheckpointRecord>();
  private blobs = new Map<string, BlobRecord>();

  async putProject(rec: ProjectRecord): Promise<void> {
    this.projects.set(rec.id, structuredClone(rec));
  }
  async getProject(id: string): Promise<ProjectRecord | undefined> {
    const r = this.projects.get(id);
    return r ? structuredClone(r) : undefined;
  }
  async listProjects(): Promise<ProjectRecord[]> {
    return [...this.projects.values()].map((r) => structuredClone(r));
  }
  async deleteProject(id: string): Promise<void> {
    this.projects.delete(id);
    for (const [k, c] of [...this.checkpoints]) if (c.projectId === id) this.checkpoints.delete(k);
    for (const [k, b] of [...this.blobs]) if (b.projectId === id) this.blobs.delete(k);
  }

  async putCheckpoint(rec: CheckpointRecord): Promise<void> {
    this.checkpoints.set(rec.id, structuredClone(rec));
  }
  async listCheckpoints(projectId: string): Promise<CheckpointRecord[]> {
    return [...this.checkpoints.values()].filter((c) => c.projectId === projectId).map((c) => structuredClone(c));
  }
  async deleteCheckpoint(id: string): Promise<void> {
    this.checkpoints.delete(id);
  }

  async putBlob(rec: BlobRecord): Promise<void> {
    this.blobs.set(rec.key, structuredClone(rec));
  }
  async getBlob(key: string): Promise<BlobRecord | undefined> {
    const r = this.blobs.get(key);
    return r ? structuredClone(r) : undefined;
  }
  async listBlobs(projectId: string): Promise<BlobRecord[]> {
    return [...this.blobs.values()].filter((b) => b.projectId === projectId).map((b) => structuredClone(b));
  }
  async deleteBlob(key: string): Promise<void> {
    this.blobs.delete(key);
  }
}
