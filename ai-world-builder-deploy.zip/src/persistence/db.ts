/**
 * Minimal typed IndexedDB wrapper (no dependencies).
 * Object stores:
 *  - projects: { id, name, createdAt, updatedAt, plan, thumbnail? }
 *  - projectData: keyed by `${projectId}:${key}` → ArrayBuffers / JSON (heightmaps, assets)
 *  - checkpoints: { id, projectId, ts, label, plan }
 *  - research: cached research entries per project
 */

export interface ProjectRecord {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  plan: unknown;
  thumbnail?: string;
}

export interface CheckpointRecord {
  id: string;
  projectId: string;
  ts: string;
  label: string;
  plan: unknown;
}

export interface BlobRecord {
  key: string;
  projectId: string;
  kind: 'heightmap' | 'asset' | 'thumbnail' | 'meta';
  meta?: Record<string, unknown>;
  data: ArrayBuffer | string | object;
}

const DB_NAME = 'ai-world-builder';
const DB_VERSION = 1;

export function openDatabase(name = DB_NAME): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not available in this environment'));
      return;
    }
    const req = indexedDB.open(name, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('projects')) {
        db.createObjectStore('projects', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('projectData')) {
        const store = db.createObjectStore('projectData', { keyPath: 'key' });
        store.createIndex('byProject', 'projectId', { unique: false });
      }
      if (!db.objectStoreNames.contains('checkpoints')) {
        const store = db.createObjectStore('checkpoints', { keyPath: 'id' });
        store.createIndex('byProject', 'projectId', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Failed to open IndexedDB'));
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('IndexedDB transaction failed'));
    tx.onabort = () => reject(tx.error ?? new Error('IndexedDB transaction aborted'));
  });
}

function reqResult<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('IndexedDB request failed'));
  });
}

export class KeyValueStore {
  constructor(private db: IDBDatabase) {}

  async putProject(rec: ProjectRecord): Promise<void> {
    const tx = this.db.transaction('projects', 'readwrite');
    tx.objectStore('projects').put(rec);
    await txDone(tx);
  }

  async getProject(id: string): Promise<ProjectRecord | undefined> {
    const tx = this.db.transaction('projects', 'readonly');
    return reqResult(tx.objectStore('projects').get(id) as IDBRequest<ProjectRecord | undefined>);
  }

  async listProjects(): Promise<ProjectRecord[]> {
    const tx = this.db.transaction('projects', 'readonly');
    const all = await reqResult(tx.objectStore('projects').getAll() as IDBRequest<ProjectRecord[]>);
    return all.sort((a, b) => (b.updatedAt ?? '').localeCompare(a.updatedAt ?? ''));
  }

  async deleteProject(id: string): Promise<void> {
    const tx = this.db.transaction(['projects', 'projectData', 'checkpoints'], 'readwrite');
    tx.objectStore('projects').delete(id);
    // Delete related records via cursors.
    await new Promise<void>((resolve, reject) => {
      const cursorReq = tx.objectStore('checkpoints').index('byProject').openCursor(IDBKeyRange.only(id));
      cursorReq.onsuccess = () => {
        const cursor = cursorReq.result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        }
      };
      cursorReq.onerror = () => reject(cursorReq.error);
      const dataReq = tx.objectStore('projectData').index('byProject').openCursor(IDBKeyRange.only(id));
      dataReq.onsuccess = () => {
        const cursor = dataReq.result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        } else {
          resolve();
        }
      };
      dataReq.onerror = () => reject(dataReq.error);
    });
    await txDone(tx);
  }

  async putCheckpoint(rec: CheckpointRecord): Promise<void> {
    const tx = this.db.transaction('checkpoints', 'readwrite');
    tx.objectStore('checkpoints').put(rec);
    await txDone(tx);
  }

  async listCheckpoints(projectId: string): Promise<CheckpointRecord[]> {
    const tx = this.db.transaction('checkpoints', 'readonly');
    const all = await reqResult(
      tx.objectStore('checkpoints').index('byProject').getAll(IDBKeyRange.only(projectId)) as IDBRequest<CheckpointRecord[]>,
    );
    return all.sort((a, b) => b.ts.localeCompare(a.ts));
  }

  async deleteCheckpoint(id: string): Promise<void> {
    const tx = this.db.transaction('checkpoints', 'readwrite');
    tx.objectStore('checkpoints').delete(id);
    await txDone(tx);
  }

  async putBlob(rec: BlobRecord): Promise<void> {
    const tx = this.db.transaction('projectData', 'readwrite');
    tx.objectStore('projectData').put(rec);
    await txDone(tx);
  }

  async getBlob(key: string): Promise<BlobRecord | undefined> {
    const tx = this.db.transaction('projectData', 'readonly');
    return reqResult(tx.objectStore('projectData').get(key) as IDBRequest<BlobRecord | undefined>);
  }

  async listBlobs(projectId: string): Promise<BlobRecord[]> {
    const tx = this.db.transaction('projectData', 'readonly');
    return reqResult(
      tx.objectStore('projectData').index('byProject').getAll(IDBKeyRange.only(projectId)) as IDBRequest<BlobRecord[]>,
    );
  }

  async deleteBlob(key: string): Promise<void> {
    const tx = this.db.transaction('projectData', 'readwrite');
    tx.objectStore('projectData').delete(key);
    await txDone(tx);
  }
}
