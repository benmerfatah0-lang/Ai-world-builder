/**
 * ProjectStore — high-level persistence API used by the app.
 * Works against any KeyValueStore (IndexedDB in the browser, memory in tests).
 * Strategy: local-first saving (IndexedDB) with optional file export/import —
 * no paid cloud storage required. Autosave debounced by the app layer.
 */
import type { WorldPlan } from '../core/types';
import type { KeyValueStore, ProjectRecord, CheckpointRecord, BlobRecord } from './db';
import { newId } from '../core/types';

export interface ProjectSummary {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  thumbnail?: string;
}

export interface SaveResult {
  savedAt: string;
  projectId: string;
}

export class ProjectStore {
  constructor(private kv: KeyValueStore) {}

  async createProject(plan: WorldPlan, name?: string): Promise<ProjectSummary> {
    const rec: ProjectRecord = {
      id: plan.id,
      name: name ?? plan.name,
      createdAt: plan.createdAt ?? new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      plan,
    };
    await this.kv.putProject(rec);
    return toSummary(rec);
  }

  async saveProject(plan: WorldPlan, thumbnail?: string): Promise<SaveResult> {
    const existing = await this.kv.getProject(plan.id);
    const rec: ProjectRecord = {
      id: plan.id,
      name: plan.name,
      createdAt: existing?.createdAt ?? plan.createdAt ?? new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      plan,
      thumbnail: thumbnail ?? existing?.thumbnail,
    };
    await this.kv.putProject(rec);
    return { savedAt: rec.updatedAt, projectId: rec.id };
  }

  async loadProject(id: string): Promise<{ record: ProjectRecord; plan: WorldPlan } | null> {
    const rec = await this.kv.getProject(id);
    if (!rec) return null;
    return { record: rec, plan: rec.plan as WorldPlan };
  }

  async listProjects(): Promise<ProjectSummary[]> {
    const all = await this.kv.listProjects();
    return all
      .map(toSummary)
      .sort((a, b) => (b.updatedAt ?? '').localeCompare(a.updatedAt ?? ''));
  }

  async deleteProject(id: string): Promise<void> {
    await this.kv.deleteProject(id);
  }

  async createCheckpoint(plan: WorldPlan, label: string): Promise<CheckpointRecord> {
    const rec: CheckpointRecord = {
      id: newId('ckpt'),
      projectId: plan.id,
      ts: new Date().toISOString(),
      label,
      plan,
    };
    await this.kv.putCheckpoint(rec);
    return rec;
  }

  async listCheckpoints(projectId: string): Promise<CheckpointRecord[]> {
    return this.kv.listCheckpoints(projectId);
  }

  async restoreCheckpoint(checkpointId: string, projectId: string): Promise<WorldPlan | null> {
    const list = await this.kv.listCheckpoints(projectId);
    const ck = list.find((c) => c.id === checkpointId);
    return ck ? (ck.plan as WorldPlan) : null;
  }

  async deleteCheckpoint(id: string): Promise<void> {
    await this.kv.deleteCheckpoint(id);
  }

  /* --- binary-ish project data (heightmaps, asset blobs) --- */

  async putData(projectId: string, kind: BlobRecord['kind'], key: string, data: BlobRecord['data'], meta?: Record<string, unknown>): Promise<void> {
    await this.kv.putBlob({ key: `${projectId}:${kind}:${key}`, projectId, kind, data, meta });
  }

  async getData<T = unknown>(projectId: string, kind: BlobRecord['kind'], key: string): Promise<T | null> {
    const rec = await this.kv.getBlob(`${projectId}:${kind}:${key}`);
    return rec ? (rec.data as T) : null;
  }

  async listData(projectId: string): Promise<BlobRecord[]> {
    return this.kv.listBlobs(projectId);
  }

  async deleteData(projectId: string, kind: BlobRecord['kind'], key: string): Promise<void> {
    await this.kv.deleteBlob(`${projectId}:${kind}:${key}`);
  }
}

function toSummary(rec: ProjectRecord): ProjectSummary {
  return {
    id: rec.id,
    name: rec.name,
    createdAt: rec.createdAt,
    updatedAt: rec.updatedAt,
    thumbnail: rec.thumbnail,
  };
}
