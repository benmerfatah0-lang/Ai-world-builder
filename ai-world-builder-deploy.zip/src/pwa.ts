import { useEffect, useState } from 'react';

type InstallPromptEvent = Event & {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
};

let installPrompt: InstallPromptEvent | null = null;
const listeners = new Set<() => void>();

export function registerPwa(): void {
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    installPrompt = event as InstallPromptEvent;
    listeners.forEach((fn) => fn());
  });
  window.addEventListener('appinstalled', () => {
    installPrompt = null;
    listeners.forEach((fn) => fn());
  });
  if ('serviceWorker' in navigator && import.meta.env.PROD) {
    window.addEventListener('load', () => {
      void navigator.serviceWorker.register('/sw.js').catch((error) => {
        console.warn('[pwa] Service worker registration failed:', error);
      });
    });
  }
}

export function useInstallApp(): { canInstall: boolean; install: () => Promise<void>; standalone: boolean } {
  const [, refresh] = useState(0);
  useEffect(() => {
    const update = () => refresh((n) => n + 1);
    listeners.add(update);
    return () => { listeners.delete(update); };
  }, []);
  const standalone = window.matchMedia('(display-mode: standalone)').matches ||
    Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
  return {
    canInstall: Boolean(installPrompt) && !standalone,
    standalone,
    install: async () => {
      if (!installPrompt) return;
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === 'accepted') installPrompt = null;
      listeners.forEach((fn) => fn());
    },
  };
}
