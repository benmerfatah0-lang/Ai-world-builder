/**
 * Style palettes and biome presets shared by all generators and the renderer.
 */
import type { ArtStyle, BiomeType } from '../core/types';

export interface Palette {
  name: string;
  flatShading: boolean;
  segments: 'low' | 'medium' | 'high';
  colors: {
    ground: string;
    groundAlt: string;
    grass: string;
    grassDry: string;
    rock: string;
    rockDark: string;
    sand: string;
    snow: string;
    water: string;
    waterDeep: string;
    trunk: string;
    leaves: string;
    leavesAlt: string;
    stone: string;
    stoneDark: string;
    wood: string;
    roof: string;
    roofAlt: string;
    metal: string;
    accent: string;
    emissive: string;
  };
  roughness: number;
  metalness: number;
}

const PALETTES: Record<ArtStyle, Palette> = {
  'low-poly': {
    name: 'Low-poly',
    flatShading: true,
    segments: 'low',
    colors: {
      ground: '#8fb86a', groundAlt: '#7ca65a', grass: '#6fae4e', grassDry: '#b8c46a',
      rock: '#8d8d94', rockDark: '#6c6c74', sand: '#e6d39a', snow: '#f2f6fa',
      water: '#4aa5d8', waterDeep: '#2c6f9e', trunk: '#7a5433', leaves: '#4d9440',
      leavesAlt: '#63ab4e', stone: '#b3b0a8', stoneDark: '#8c8a82', wood: '#a97b4f',
      roof: '#b3543f', roofAlt: '#8f4433', metal: '#8a929c', accent: '#e0a53f', emissive: '#ff9d45',
    },
    roughness: 0.85, metalness: 0.02,
  },
  realistic: {
    name: 'Realistic',
    flatShading: false,
    segments: 'high',
    colors: {
      ground: '#6b7a4e', groundAlt: '#5c6b42', grass: '#4e7a35', grassDry: '#9a9a58',
      rock: '#7c7c7c', rockDark: '#5a5a5a', sand: '#cbb98a', snow: '#eef2f6',
      water: '#3a7ea6', waterDeep: '#20506e', trunk: '#5e4227', leaves: '#2f6b2a',
      leavesAlt: '#3f7d33', stone: '#9c9a92', stoneDark: '#6f6d66', wood: '#8a6238',
      roof: '#7c4632', roofAlt: '#5f3626', metal: '#71787f', accent: '#c2a13c', emissive: '#e08c3a',
    },
    roughness: 0.72, metalness: 0.05,
  },
  stylized: {
    name: 'Stylized',
    flatShading: true,
    segments: 'medium',
    colors: {
      ground: '#96c16e', groundAlt: '#84b35c', grass: '#74c252', grassDry: '#c9cf72',
      rock: '#9a97a8', rockDark: '#77748a', sand: '#f0dc9f', snow: '#f6fafd',
      water: '#4fbfe0', waterDeep: '#2d84b8', trunk: '#8a5c36', leaves: '#57b848',
      leavesAlt: '#72cf5c', stone: '#c4c0b6', stoneDark: '#96928a', wood: '#bf8552',
      roof: '#d4604a', roofAlt: '#a84837', metal: '#9aa7b5', accent: '#ffcb4d', emissive: '#ffb24d',
    },
    roughness: 0.8, metalness: 0.02,
  },
  cartoon: {
    name: 'Cartoon',
    flatShading: true,
    segments: 'low',
    colors: {
      ground: '#a6d477', groundAlt: '#93c45f', grass: '#7fd94f', grassDry: '#d9de6b',
      rock: '#a8a2c0', rockDark: '#847daa', sand: '#ffe29a', snow: '#ffffff',
      water: '#59d2f2', waterDeep: '#2f9ad0', trunk: '#9c6432', leaves: '#5ecf3c',
      leavesAlt: '#80e457', stone: '#d6d2c8', stoneDark: '#a7a296', wood: '#d2914f',
      roof: '#ff7a5c', roofAlt: '#d95c41', metal: '#aab6c6', accent: '#ffd23f', emissive: '#ffcf4f',
    },
    roughness: 0.9, metalness: 0,
  },
  voxel: {
    name: 'Voxel',
    flatShading: true,
    segments: 'low',
    colors: {
      ground: '#7fae5a', groundAlt: '#6e9c4c', grass: '#63a83c', grassDry: '#aab85a',
      rock: '#878790', rockDark: '#67676e', sand: '#dbc98c', snow: '#eef2f7',
      water: '#3f92c9', waterDeep: '#276394', trunk: '#6e4a2c', leaves: '#418531',
      leavesAlt: '#52a03c', stone: '#a6a39b', stoneDark: '#7d7a73', wood: '#96693e',
      roof: '#a34a37', roofAlt: '#7e3a2b', metal: '#7f8894', accent: '#d9a63c', emissive: '#e39240',
    },
    roughness: 0.95, metalness: 0,
  },
  custom: {
    name: 'Custom',
    flatShading: true,
    segments: 'medium',
    colors: {
      ground: '#8fb86a', groundAlt: '#7ca65a', grass: '#6fae4e', grassDry: '#b8c46a',
      rock: '#8d8d94', rockDark: '#6c6c74', sand: '#e6d39a', snow: '#f2f6fa',
      water: '#4aa5d8', waterDeep: '#2c6f9e', trunk: '#7a5433', leaves: '#4d9440',
      leavesAlt: '#63ab4e', stone: '#b3b0a8', stoneDark: '#8c8a82', wood: '#a97b4f',
      roof: '#b3543f', roofAlt: '#8f4433', metal: '#8a929c', accent: '#e0a53f', emissive: '#ff9d45',
    },
    roughness: 0.85, metalness: 0.02,
  },
};

export function getPalette(style: ArtStyle): Palette {
  return PALETTES[style] ?? PALETTES['low-poly'];
}

export interface BiomePreset {
  type: BiomeType;
  label: string;
  groundColorKey: keyof Palette['colors'];
  treeDensity: number;
  rockDensity: number;
  treePrefabs: string[];
  rockPrefabs: string[];
  groundPrefabs: string[];
  heightBias: number;
  moisture: number;
  temperature: number;
}

export const BIOME_PRESETS: Record<BiomeType, BiomePreset> = {
  plains: {
    type: 'plains', label: 'Plains', groundColorKey: 'grass',
    treeDensity: 0.12, rockDensity: 0.05,
    treePrefabs: ['tree.oak_a', 'tree.oak_b', 'tree.willow'], rockPrefabs: ['rock.a', 'rock.b'],
    groundPrefabs: ['grass.tuft', 'flower.mixed', 'bush.small'],
    heightBias: -2, moisture: 0.5, temperature: 0.6,
  },
  forest: {
    type: 'forest', label: 'Forest', groundColorKey: 'grass',
    treeDensity: 0.85, rockDensity: 0.1,
    treePrefabs: ['tree.pine_a', 'tree.pine_b', 'tree.oak_a', 'tree.birch'],
    rockPrefabs: ['rock.a', 'rock.b', 'rock.mossy'],
    groundPrefabs: ['grass.tuft', 'mushroom.red', 'bush.small', 'bush.berries'],
    heightBias: 0, moisture: 0.8, temperature: 0.5,
  },
  desert: {
    type: 'desert', label: 'Desert', groundColorKey: 'sand',
    treeDensity: 0.04, rockDensity: 0.18,
    treePrefabs: ['cactus.tall', 'cactus.round'], rockPrefabs: ['rock.dune', 'rock.a'],
    groundPrefabs: ['grass.dry', 'rock.small'],
    heightBias: 1, moisture: 0.05, temperature: 0.95,
  },
  snow: {
    type: 'snow', label: 'Snow', groundColorKey: 'snow',
    treeDensity: 0.3, rockDensity: 0.12,
    treePrefabs: ['tree.pine_snow_a', 'tree.pine_snow_b'], rockPrefabs: ['rock.ice', 'rock.a'],
    groundPrefabs: ['rock.small', 'grass.tuft'],
    heightBias: 6, moisture: 0.5, temperature: -0.5,
  },
  tundra: {
    type: 'tundra', label: 'Tundra', groundColorKey: 'groundAlt',
    treeDensity: 0.08, rockDensity: 0.2,
    treePrefabs: ['tree.pine_snow_b'], rockPrefabs: ['rock.ice', 'rock.b'],
    groundPrefabs: ['grass.dry', 'rock.small'],
    heightBias: 2, moisture: 0.3, temperature: -0.2,
  },
  swamp: {
    type: 'swamp', label: 'Swamp', groundColorKey: 'groundAlt',
    treeDensity: 0.55, rockDensity: 0.05,
    treePrefabs: ['tree.willow', 'tree.dead'], rockPrefabs: ['rock.mossy'],
    groundPrefabs: ['grass.tuft', 'mushroom.red', 'bush.small'],
    heightBias: -4, moisture: 1, temperature: 0.6,
  },
  volcanic: {
    type: 'volcanic', label: 'Volcanic', groundColorKey: 'rockDark',
    treeDensity: 0.02, rockDensity: 0.5,
    treePrefabs: ['tree.dead'], rockPrefabs: ['rock.obsidian', 'rock.a', 'rock.b'],
    groundPrefabs: ['rock.small', 'crystal.red'],
    heightBias: 8, moisture: 0.1, temperature: 1,
  },
  beach: {
    type: 'beach', label: 'Beach', groundColorKey: 'sand',
    treeDensity: 0.08, rockDensity: 0.08,
    treePrefabs: ['tree.palm'], rockPrefabs: ['rock.dune', 'rock.a'],
    groundPrefabs: ['grass.dry', 'rock.small'],
    heightBias: -3, moisture: 0.6, temperature: 0.85,
  },
  ocean: {
    type: 'ocean', label: 'Ocean', groundColorKey: 'sand',
    treeDensity: 0, rockDensity: 0.02,
    treePrefabs: [], rockPrefabs: ['rock.a'],
    groundPrefabs: [],
    heightBias: -12, moisture: 1, temperature: 0.7,
  },
  lake: {
    type: 'lake', label: 'Lake', groundColorKey: 'sand',
    treeDensity: 0.1, rockDensity: 0.1,
    treePrefabs: ['tree.willow', 'tree.oak_b'], rockPrefabs: ['rock.a', 'rock.b'],
    groundPrefabs: ['grass.tuft'],
    heightBias: -8, moisture: 1, temperature: 0.5,
  },
  river: {
    type: 'river', label: 'River', groundColorKey: 'sand',
    treeDensity: 0.2, rockDensity: 0.15,
    treePrefabs: ['tree.willow', 'tree.birch'], rockPrefabs: ['rock.a', 'rock.b'],
    groundPrefabs: ['grass.tuft'],
    heightBias: -5, moisture: 1, temperature: 0.5,
  },
  canyon: {
    type: 'canyon', label: 'Canyon', groundColorKey: 'sand',
    treeDensity: 0.03, rockDensity: 0.45,
    treePrefabs: ['cactus.tall'], rockPrefabs: ['rock.dune', 'rock.b'],
    groundPrefabs: ['rock.small', 'grass.dry'],
    heightBias: 4, moisture: 0.15, temperature: 0.85,
  },
  mountains: {
    type: 'mountains', label: 'Mountains', groundColorKey: 'rock',
    treeDensity: 0.22, rockDensity: 0.5,
    treePrefabs: ['tree.pine_a', 'tree.pine_snow_a'], rockPrefabs: ['rock.a', 'rock.b', 'rock.ice'],
    groundPrefabs: ['rock.small', 'grass.tuft'],
    heightBias: 22, moisture: 0.4, temperature: 0.1,
  },
  hills: {
    type: 'hills', label: 'Hills', groundColorKey: 'grass',
    treeDensity: 0.35, rockDensity: 0.12,
    treePrefabs: ['tree.oak_a', 'tree.oak_b', 'tree.birch'], rockPrefabs: ['rock.a', 'rock.b'],
    groundPrefabs: ['grass.tuft', 'flower.mixed', 'bush.small'],
    heightBias: 6, moisture: 0.55, temperature: 0.55,
  },
  island: {
    type: 'island', label: 'Island', groundColorKey: 'sand',
    treeDensity: 0.4, rockDensity: 0.1,
    treePrefabs: ['tree.palm', 'tree.oak_b'], rockPrefabs: ['rock.a'],
    groundPrefabs: ['grass.tuft', 'flower.mixed'],
    heightBias: -2, moisture: 0.7, temperature: 0.8,
  },
  custom: {
    type: 'custom', label: 'Custom', groundColorKey: 'ground',
    treeDensity: 0.2, rockDensity: 0.1,
    treePrefabs: ['tree.oak_a'], rockPrefabs: ['rock.a'],
    groundPrefabs: ['grass.tuft'],
    heightBias: 0, moisture: 0.5, temperature: 0.5,
  },
};

export function getBiomePreset(type: BiomeType): BiomePreset {
  return BIOME_PRESETS[type] ?? BIOME_PRESETS.plains;
}
