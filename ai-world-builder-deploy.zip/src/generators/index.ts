/**
 * WorldGenerator orchestrator: executes a WorldPlan into concrete geometry data
 * (heightfield + expanded objects). Runs in chunks so the UI can show progress
 * and cancel long generations.
 */
import type { WorldPlan, WorldObject, PathSpec } from '../core/types';
import { generateHeightfield, type Heightfield } from './terrain';
import { scatterWorld } from './scatter';
import { expandRegion } from './structures';
import { newId } from '../core/types';

export type { Heightfield };

export interface GenerationProgress {
  phase: string;
  current: number;
  total: number;
  message: string;
}

export interface GenerationResult {
  heightfield: Heightfield;
  /** Objects derived from regions + scatter (appended to plan.objects for rendering). */
  derivedObjects: WorldObject[];
  derivedPaths: PathSpec[];
  stats: {
    objectCount: number;
    instanceCount: number;
    terrainCells: number;
    durationMs: number;
  };
}

export class CancelledError extends Error {
  constructor() {
    super('Generation cancelled');
    this.name = 'CancelledError';
  }
}

export interface CancelToken {
  cancelled: boolean;
  throwIfCancelled(): void;
}

export function createCancelToken(): CancelToken {
  return {
    cancelled: false,
    throwIfCancelled() {
      if (this.cancelled) throw new CancelledErrorShim();
    },
  };
}

// Small indirection avoids importing CancelledError into token module cycle.
class CancelledErrorShim extends Error {
  constructor() {
    super('Generation cancelled');
    this.name = 'CancelledError';
  }
}

const nextTick = () => new Promise<void>((r) => setTimeout(r, 0));

export async function generateWorld(
  plan: WorldPlan,
  onProgress: (p: GenerationProgress) => void,
  token: CancelToken = createCancelToken(),
  existingHeightfield?: Heightfield,
): Promise<GenerationResult> {
  const t0 = Date.now();
  const phases = ['terrain', 'regions', 'scatter', 'finalize'] as const;
  const total = phases.length;
  const report = (phase: string, current: number, message: string) =>
    onProgress({ phase, current, total, message });

  report('terrain', 0, 'Generating terrain heightfield…');
  await nextTick();
  token.throwIfCancelled();

  const heightfield = existingHeightfield ?? generateHeightfield(plan);
  report('terrain', 1, `Terrain ready (${heightfield.resolution}×${heightfield.resolution})`);
  await nextTick();
  token.throwIfCancelled();

  // Expand regions into structures and props.
  const derivedObjects: WorldObject[] = [];
  const derivedPaths: PathSpec[] = [];
  const regions = plan.regions ?? [];
  for (let i = 0; i < regions.length; i++) {
    token.throwIfCancelled();
    report('regions', 1, `Building region ${i + 1}/${regions.length}: ${regions[i].kind}…`);
    await nextTick();
    const expansion = expandRegion(plan, heightfield, regions[i]);
    derivedObjects.push(...expansion.objects);
    derivedPaths.push(...expansion.paths);
  }

  report('scatter', 2, 'Scattering vegetation and props…');
  await nextTick();
  token.throwIfCancelled();

  const scatter = scatterWorld(plan, heightfield);
  derivedObjects.push(...scatter.clusters);

  report('finalize', 3, 'Finalizing world…');
  await nextTick();
  token.throwIfCancelled();

  const instanceCount = derivedObjects.reduce((n, o) => n + (o.instances?.length ?? 1), 0);
  return {
    heightfield,
    derivedObjects,
    derivedPaths,
    stats: {
      objectCount: derivedObjects.length,
      instanceCount,
      terrainCells: heightfield.resolution * heightfield.resolution,
      durationMs: Date.now() - t0,
    },
  };
}

/**
 * Regenerate only the objects/instances inside a circular region, preserving
 * everything outside it. Returns new derived objects for that region only.
 */
export async function regenerateRegion(
  plan: WorldPlan,
  heightfield: Heightfield,
  region: { center: [number, number]; radius: number; kind?: string },
  onProgress: (p: GenerationProgress) => void,
  token: CancelToken = createCancelToken(),
): Promise<{ objects: WorldObject[]; paths: PathSpec[] }> {
  reportRegion(onProgress, 'Analyzing region…');
  await nextTick();
  token.throwIfCancelled();

  const salted: WorldPlan = {
    ...plan,
    // Salt the seed so the same region produces different-but-coherent results.
    seed: plan.seed + Math.floor(Math.abs(region.center[0] * 31 + region.center[1] * 17) % 100000),
  };

  const objects: WorldObject[] = [];
  const paths: PathSpec[] = [];

  if (region.kind) {
    const syntheticRegion = {
      id: newId('region'),
      kind: region.kind as never,
      center: region.center,
      radius: region.radius,
      source: 'user' as const,
    };
    const expansion = expandRegion(plan, heightfield, syntheticRegion);
    objects.push(...expansion.objects);
    paths.push(...expansion.paths);
  } else {
    const scatter = scatterWorld(salted, heightfield, {
      region: { center: region.center, radius: region.radius },
    });
    objects.push(...scatter.clusters);
  }

  reportRegion(onProgress, `Region regenerated (${objects.length} groups)`);
  return { objects, paths };
}

function reportRegion(onProgress: (p: GenerationProgress) => void, message: string) {
  onProgress({ phase: 'region', current: 1, total: 2, message });
}
