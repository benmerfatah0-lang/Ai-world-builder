/**
 * Scatter placement: deterministic, density-aware, slope/water-aware object
 * placement with simple spacing constraints ("collision-aware placement").
 */
import { rngFrom, randRange, randInt, chance, pick, type Rng } from '../core/rng';
import { sampleHeight, sampleNormal, type Heightfield } from './terrain';
import { getBiomePreset } from './presets';
import type { WorldPlan, WorldObject, Biome, Vec3, ObjectInstance } from '../core/types';
import { newId } from '../core/types';

export interface ScatterOptions {
  /** Global multiplier from quality preset. */
  qualityScale?: number;
  /** Restrict scatter to a circular region (used for regional regeneration). */
  region?: { center: [number, number]; radius: number };
  /** Skip water and shoreline cells. */
  avoidWater?: boolean;
}

export interface ScatterResult {
  clusters: WorldObject[];
  counts: Record<string, number>;
}

interface Placement {
  position: Vec3;
  rotation: Vec3;
  scale: number;
}

export function scatterWorld(plan: WorldPlan, hf: Heightfield, opts: ScatterOptions = {}): ScatterResult {
  const rng = rngFrom(plan.seed ^ 0x5ca77e5);
  const half = hf.size / 2;
  const density = plan.settings.density ?? {};
  const veg = clamp01(density.vegetation ?? 0.6);
  const propD = clamp01(density.props ?? 0.5);
  const qualityScale = opts.qualityScale ?? (plan.settings.quality === 'draft' ? 0.45 : plan.settings.quality === 'high' ? 1.35 : 1);

  // Group scatter by prefab so we can emit one instanced cluster per prefab.
  const byPrefab = new Map<string, { kind: WorldObject['kind']; placements: Placement[]; tags: string[] }>();
  const counts: Record<string, number> = {};

  const biomes = (plan.biomes ?? []).length ? plan.biomes! : [
    { id: 'biome-main', type: 'plains' as const, center: [0, 0] as [number, number], radius: half },
  ];

  for (const biome of biomes) {
    const preset = getBiomePreset(biome.type);
    const biomeRng = rngFrom(`${plan.seed}:${biome.id}`);
    const areaScale = Math.PI * biome.radius * biome.radius;
    // Roughly trees-per-m² scaled by density and quality.
    const treeCount = Math.floor(areaScale * 0.004 * preset.treeDensity * veg * qualityScale);
    const rockCount = Math.floor(areaScale * 0.0012 * preset.rockDensity * propD * qualityScale);
    const groundCount = Math.floor(areaScale * 0.0035 * preset.treeDensity * veg * qualityScale * 1.4);

    scatterGroup(byPrefab, counts, preset.treePrefabs, treeCount, biome, biomeRng, hf, half, {
      minSlopeOk: 0.55, avoidWater: opts.avoidWater ?? true, scaleMin: 0.75, scaleMax: 1.45,
      kind: 'tree', region: opts.region,
    });
    scatterGroup(byPrefab, counts, preset.rockPrefabs, rockCount, biome, biomeRng, hf, half, {
      minSlopeOk: 0.25, avoidWater: false, scaleMin: 0.5, scaleMax: 1.8,
      kind: 'rock', region: opts.region,
    });
    scatterGroup(byPrefab, counts, preset.groundPrefabs, groundCount, biome, biomeRng, hf, half, {
      minSlopeOk: 0.65, avoidWater: true, scaleMin: 0.6, scaleMax: 1.3,
      kind: groundKindFor(preset.groundPrefabs), region: opts.region,
    });
  }

  const clusters: WorldObject[] = [];
  for (const [prefab, group] of byPrefab) {
    if (!group.placements.length) continue;
    clusters.push({
      id: newId(`cluster-${prefab.split('.').pop() ?? 'x'}`),
      name: `${prefab} ×${group.placements.length}`,
      kind: group.kind,
      prefab,
      position: [0, 0, 0],
      tags: ['scatter', ...group.tags],
      meta: { generated: 'scatter', instanceCount: group.placements.length },
      instances: group.placements.map((pl) => ({
        position: pl.position,
        rotation: pl.rotation,
        scale: [pl.scale, pl.scale, pl.scale] as Vec3,
      })),
    });
    counts[prefab] = group.placements.length;
  }

  return { clusters, counts };
}

function groundKindFor(prefabs: string[]): WorldObject['kind'] {
  if (prefabs.some((p) => p.startsWith('flower'))) return 'flower';
  if (prefabs.some((p) => p.startsWith('grass'))) return 'grass';
  return 'bush';
}

interface ScatterGroupOpts {
  minSlopeOk: number;   // max allowed |normal.y| inverse — higher means require flatter
  avoidWater: boolean;
  scaleMin: number;
  scaleMax: number;
  kind: WorldObject['kind'];
  region?: { center: [number, number]; radius: number };
}

/**
 * Poisson-ish placement: candidates rejected when too close to accepted points.
 * Spatial hash keeps this linear in practice.
 */
function scatterGroup(
  byPrefab: Map<string, { kind: WorldObject['kind']; placements: Placement[]; tags: string[] }>,
  counts: Record<string, number>,
  prefabs: string[],
  targetCount: number,
  biome: Biome,
  rng: Rng,
  hf: Heightfield,
  half: number,
  opts: ScatterGroupOpts,
): void {
  if (!prefabs.length || targetCount <= 0) return;

  const spacing = spacingFor(opts.kind, targetCount, biome.radius);
  const occupied: Array<{ x: number; z: number; r: number }> = [];
  const cellSize = Math.max(spacing, 1);
  const grid = new Map<string, Array<{ x: number; z: number; r: number }>>();

  const maxAttempts = Math.min(targetCount * 14, 24000);
  let placed = 0;

  for (let attempt = 0; attempt < maxAttempts && placed < targetCount; attempt++) {
    const angle = rng() * Math.PI * 2;
    const r = Math.sqrt(rng()) * biome.radius;
    const x = biome.center[0] + Math.cos(angle) * r;
    const z = biome.center[1] + Math.sin(angle) * r;

    if (Math.abs(x) > half - 2 || Math.abs(z) > half - 2) continue;

    if (opts.region) {
      const dx = x - opts.region.center[0];
      const dz = z - opts.region.center[1];
      if (dx * dx + dz * dz > opts.region.radius * opts.region.radius) continue;
    }

    const y = sampleHeight(hf, x, z);
    if (opts.avoidWater && y <= hf.waterLevel + 0.4) continue;
    if (!opts.avoidWater && y <= hf.waterLevel - 1.5) continue;

    const n = sampleNormal(hf, x, z, 1.5);
    const flatness = n.y; // 1 = perfectly flat
    if (flatness < opts.minSlopeOk) continue;

    const pad = spacing * randRange(rng, 0.85, 1.25);
    if (collides(grid, occupied, x, z, pad, cellSize)) continue;

    const prefab = pick(rng, prefabs);
    const scale = randRange(rng, opts.scaleMin, opts.scaleMax);
    const placement: Placement = {
      position: [round2(x), round2(y - 0.15), round2(z)],
      rotation: [round2((rng() - 0.5) * 0.12), round2(rng() * Math.PI * 2), round2((rng() - 0.5) * 0.12)],
      scale: round2(scale),
    };

    let entry = byPrefab.get(prefab);
    if (!entry) {
      entry = { kind: opts.kind, placements: [], tags: [biome.type] };
      byPrefab.set(prefab, entry);
    }
    entry.placements.push(placement);

    occupied.push({ x, z, r: pad * 0.5 });
    const gx = Math.floor(x / cellSize);
    const gz = Math.floor(z / cellSize);
    const key = `${gx}:${gz}`;
    const list = grid.get(key) ?? [];
    list.push({ x, z, r: pad * 0.5 });
    grid.set(key, list);
    placed += 1;
  }

  counts[`${biome.id}:${opts.kind}`] = (counts[`${biome.id}:${opts.kind}`] ?? 0) + placed;
}

function spacingFor(kind: WorldObject['kind'], count: number, radius: number): number {
  const area = Math.PI * radius * radius;
  const density = count / Math.max(area, 1);
  const base = kind === 'tree' ? 2.2 : kind === 'rock' ? 1.6 : 1.0;
  return Math.max(base * 0.6, base * (1 - Math.min(density * 40, 0.55)));
}

function collides(
  grid: Map<string, Array<{ x: number; z: number; r: number }>>,
  _occupied: Array<{ x: number; z: number; r: number }>,
  x: number,
  z: number,
  pad: number,
  cellSize: number,
): boolean {
  const gx = Math.floor(x / cellSize);
  const gz = Math.floor(z / cellSize);
  for (let j = gz - 1; j <= gz + 1; j++) {
    for (let i = gx - 1; i <= gx + 1; i++) {
      const list = grid.get(`${i}:${j}`);
      if (!list) continue;
      for (const p of list) {
        const dx = p.x - x;
        const dz = p.z - z;
        const minDist = p.r + pad * 0.5;
        if (dx * dx + dz * dz < minDist * minDist) return true;
      }
    }
  }
  return false;
}

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

function round2(v: number): number {
  return Math.round(v * 100) / 100;
}

/**
 * Place individual (non-clustered) props around a point, e.g. village props.
 */
export function placePropsAround(
  plan: WorldPlan,
  hf: Heightfield,
  center: [number, number],
  radius: number,
  kinds: Array<WorldObject['kind']>,
  count: number,
  seedSalt: string,
): WorldObject[] {
  const rng: Rng = rngFrom(`${plan.seed}:${seedSalt}`);
  const out: WorldObject[] = [];
  const occupied: Array<{ x: number; z: number; r: number }> = [];
  let attempts = 0;
  while (out.length < count && attempts < count * 12) {
    attempts++;
    const angle = rng() * Math.PI * 2;
    const r = Math.sqrt(rng()) * radius;
    const x = center[0] + Math.cos(angle) * r;
    const z = center[1] + Math.sin(angle) * r;
    const y = sampleHeight(hf, x, z);
    if (y <= hf.waterLevel + 0.3) continue;
    const n = sampleNormal(hf, x, z, 1);
    if (n.y < 0.72) continue;
    if (occupied.some((p) => (p.x - x) ** 2 + (p.z - z) ** 2 < p.r * p.r)) continue;

    const kind = pick(rng, kinds);
    out.push({
      id: newId(kind),
      kind,
      prefab: prefabForKind(kind),
      position: [round2(x), round2(y - 0.05), round2(z)],
      rotation: [0, round2(rng() * Math.PI * 2), 0],
      scale: round2(randRange(rng, 0.85, 1.25)),
      tags: ['prop', seedSalt],
    });
    occupied.push({ x, z, r: 1.6 });
  }
  return out;
}

function prefabForKind(kind: WorldObject['kind']): string {
  switch (kind) {
    case 'crate': return 'prop.crate';
    case 'barrel': return 'prop.barrel';
    case 'bench': return 'prop.bench';
    case 'lamp': return 'prop.lamp';
    case 'well': return 'prop.well';
    case 'campfire': return 'prop.campfire';
    case 'fence': return 'prop.fence';
    default: return `prop.${kind}`;
  }
}
