/**
 * Structure intelligence: turns regions (village, castle, farm, ruins, …) into
 * coherent collections of WorldObjects with roads and props.
 */
import { rngFrom, randRange, randInt, chance, pick, type Rng } from '../core/rng';
import { sampleHeight, sampleNormal, type Heightfield } from './terrain';
import { placePropsAround } from './scatter';
import type { WorldPlan, WorldObject, Region, PathSpec, Vec2, Vec3 } from '../core/types';
import { newId } from '../core/types';

export interface RegionExpansion {
  objects: WorldObject[];
  paths: PathSpec[];
}

export function expandRegion(plan: WorldPlan, hf: Heightfield, region: Region): RegionExpansion {
  switch (region.kind) {
    case 'village':
    case 'camp':
    case 'harbor':
      return expandSettlement(plan, hf, region);
    case 'city':
      return expandSettlement(plan, hf, region, { houses: 18, minDist: 12, walls: region.kind === 'city' });
    case 'castle':
      return expandCastle(plan, hf, region);
    case 'farm':
      return expandFarm(plan, hf, region);
    case 'ruins':
      return expandRuins(plan, hf, region);
    case 'temple':
      return expandTemple(plan, hf, region);
    case 'graveyard':
      return expandGraveyard(plan, hf, region);
    default:
      return { objects: placePropsAround(plan, hf, region.center, region.radius, ['crate', 'barrel'], 4, region.id), paths: [] };
  }
}

interface SettlementOpts {
  houses?: number;
  minDist?: number;
  walls?: boolean;
}

function expandSettlement(plan: WorldPlan, hf: Heightfield, region: Region, opts: SettlementOpts = {}): RegionExpansion {
  const rng: Rng = rngFrom(`${plan.seed}:${region.id}`);
  const densityStruct = plan.settings.density.structures ?? 0.5;
  const houseCount = opts.houses ?? Math.max(3, Math.round((region.radius / 7) * (0.6 + densityStruct)));
  const minDist = opts.minDist ?? 9;
  const objects: WorldObject[] = [];
  const paths: PathSpec[] = [];
  const slots: Array<[number, number]> = [];

  // Find house slots around the region center.
  let attempts = 0;
  while (slots.length < houseCount && attempts < houseCount * 20) {
    attempts++;
    const angle = rng() * Math.PI * 2;
    const r = Math.sqrt(rng()) * region.radius * 0.85;
    const x = region.center[0] + Math.cos(angle) * r;
    const z = region.center[1] + Math.sin(angle) * r;
    const y = sampleHeight(hf, x, z);
    if (y <= hf.waterLevel + 0.8) continue;
    const n = sampleNormal(hf, x, z, 2);
    if (n.y < 0.86) continue; // houses need fairly flat ground
    if (slots.some(([sx, sz]) => (sx - x) ** 2 + (sz - z) ** 2 < minDist * minDist)) continue;
    slots.push([x, z]);
  }

  // Houses face the center.
  for (const [x, z] of slots) {
    const y = sampleHeight(hf, x, z);
    const yaw = Math.atan2(region.center[1] - z, region.center[0] - x) + Math.PI / 2;
    const isHut = chance(rng, 0.3);
    objects.push({
      id: newId('house'),
      name: isHut ? 'Hut' : 'House',
      kind: isHut ? 'hut' : 'house',
      prefab: isHut ? 'structure.hut_a' : pick(rng, ['structure.house_a', 'structure.house_b', 'structure.house_c']),
      position: [r2(x), r2(y - 0.1), r2(z)],
      rotation: [0, r2(yaw), 0],
      scale: r2(randRange(rng, 0.9, 1.25)),
      tags: [region.kind, 'structure'],
    });
    // Small yard props per house.
    if (chance(rng, 0.45)) {
      objects.push({
        id: newId('barrel'),
        kind: 'barrel',
        prefab: 'prop.barrel',
        position: [r2(x + Math.cos(yaw) * 3.2), r2(sampleHeight(hf, x + Math.cos(yaw) * 3.2, z + Math.sin(yaw) * 3.2)), r2(z + Math.sin(yaw) * 3.2)],
        rotation: [0, r2(rng() * Math.PI * 2), 0],
        scale: 1,
        tags: [region.kind, 'prop'],
      });
    }
    if (chance(rng, 0.3)) {
      objects.push({
        id: newId('fence'),
        kind: 'fence',
        prefab: 'prop.fence',
        position: [r2(x - Math.cos(yaw) * 3.6), r2(sampleHeight(hf, x - Math.cos(yaw) * 3.6, z - Math.sin(yaw) * 3.2)), r2(z - Math.sin(yaw) * 3.2)],
        rotation: [0, r2(yaw), 0],
        scale: 1,
        tags: [region.kind, 'prop'],
      });
    }
  }

  // Central well + lamp posts for larger settlements.
  if (slots.length >= 3) {
    const wy = sampleHeight(hf, region.center[0], region.center[1]);
    if (wy > hf.waterLevel) {
      objects.push({
        id: newId('well'),
        name: 'Village well',
        kind: 'well',
        prefab: 'prop.well',
        position: [r2(region.center[0]), r2(wy - 0.05), r2(region.center[1])],
        rotation: [0, r2(rng() * Math.PI), 0],
        scale: 1,
        tags: [region.kind, 'landmark'],
      });
    }
    for (let i = 0; i < Math.min(6, slots.length); i++) {
      const a = (i / 6) * Math.PI * 2;
      const lx = region.center[0] + Math.cos(a) * region.radius * 0.45;
      const lz = region.center[1] + Math.sin(a) * region.radius * 0.45;
      const ly = sampleHeight(hf, lx, lz);
      if (ly > hf.waterLevel) {
        objects.push({
          id: newId('lamp'),
          kind: 'lamp',
          prefab: 'prop.lamp',
          position: [r2(lx), r2(ly), r2(lz)],
          rotation: [0, r2(a), 0],
          scale: 1,
          tags: [region.kind, 'prop'],
        });
      }
    }
  }

  // Roads: connect houses to the center.
  for (const [x, z] of slots) {
    const pts = roadPoints(region.center, [x, z], rng);
    paths.push({
      id: newId('road'),
      kind: 'road',
      width: 3,
      points: pts,
      params: { region: region.id },
    });
  }

  objects.push(...placePropsAround(plan, hf, region.center, region.radius, ['crate', 'barrel', 'bench'], Math.round(3 + densityStruct * 4), `${region.id}:props`));

  if (opts.walls) {
    objects.push(...wallRing(plan, hf, region.center, region.radius * 1.02, rng));
  }

  return { objects, paths };
}

function expandCastle(plan: WorldPlan, hf: Heightfield, region: Region): RegionExpansion {
  const rng: Rng = rngFrom(`${plan.seed}:${region.id}`);
  const objects: WorldObject[] = [];
  const paths: PathSpec[] = [];
  const R = region.radius * 0.8;

  // Keep: central tower.
  const cy = sampleHeight(hf, region.center[0], region.center[1]);
  objects.push({
    id: newId('tower'),
    name: 'Keep',
    kind: 'tower',
    prefab: 'structure.tower_keep',
    position: [r2(region.center[0]), r2(cy - 0.1), r2(region.center[1])],
    rotation: [0, 0, 0],
    scale: r2(randRange(rng, 1.25, 1.6)),
    tags: ['castle', 'landmark'],
  });

  // Four corner towers + curtain walls.
  const corners: Array<[number, number]> = [];
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    corners.push([region.center[0] + Math.cos(a) * R, region.center[1] + Math.sin(a) * R]);
  }
  for (let i = 0; i < 4; i++) {
    const [x, z] = corners[i];
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const ty = sampleHeight(hf, x, z);
    objects.push({
      id: newId('tower'),
      name: 'Tower',
      kind: 'tower',
      prefab: 'structure.tower_round',
      position: [r2(x), r2(ty - 0.1), r2(z)],
      rotation: [0, r2(a), 0],
      scale: r2(randRange(rng, 0.95, 1.15)),
      tags: ['castle'],
    });
    // Curtain wall to the next corner (closed loop).
    objects.push(...wallSegment(plan, hf, corners[i], corners[(i + 1) % 4], rng));
  }

  // Gatehouse on the approach side.
  const ga = Math.atan2(-region.center[1], -region.center[0]);
  const gx = region.center[0] + Math.cos(ga) * R;
  const gz = region.center[1] + Math.sin(ga) * R;
  objects.push({
    id: newId('tower'),
    name: 'Gatehouse',
    kind: 'tower',
    prefab: 'structure.gatehouse',
    position: [r2(gx), r2(sampleHeight(hf, gx, gz) - 0.1), r2(gz)],
    rotation: [0, r2(ga + Math.PI / 2), 0],
    scale: 1.15,
    tags: ['castle'],
  });

  // Inner houses.
  objects.push(...expandSettlement(plan, hf, { ...region, kind: 'village', radius: R * 0.55, id: `${region.id}:inner` }).objects);

  paths.push({
    id: newId('road'),
    kind: 'road',
    width: 4,
    points: [
      [r2(gx), r2(gz)],
      [r2(gx + Math.cos(ga) * R * 1.6), r2(gz + Math.sin(ga) * R * 1.6)],
    ],
  });

  return { objects, paths };
}

function expandFarm(plan: WorldPlan, hf: Heightfield, region: Region): RegionExpansion {
  const rng: Rng = rngFrom(`${plan.seed}:${region.id}`);
  const objects: WorldObject[] = [];
  const paths: PathSpec[] = [];

  // Field strips: rows of crops as grass clusters.
  const rows = randInt(rng, 4, 7);
  for (let r = 0; r < rows; r++) {
    const off = (r / (rows - 1) - 0.5) * region.radius * 1.2;
    const instances: Vec3[] = [];
    const cols = Math.floor(region.radius / 1.6);
    for (let c = 0; c < cols; c++) {
      const along = (c / (cols - 1) - 0.5) * region.radius * 1.2;
      const x = region.center[0] + along;
      const z = region.center[1] + off;
      const y = sampleHeight(hf, x, z);
      if (y <= hf.waterLevel + 0.3) continue;
      instances.push([r2(x), r2(y), r2(z)]);
    }
    if (instances.length) {
      objects.push({
        id: newId('crop-row'),
        name: `Crop row ${r + 1}`,
        kind: 'grass',
        prefab: 'plant.crop_row',
        position: [0, 0, 0],
        tags: ['farm', 'crops'],
        meta: { row: r },
        instances: instances.map((p) => ({ position: p, scale: r2(randRange(rng, 0.8, 1.1)) })),
      });
    }
  }

  // Barn + farmhouse.
  const by = sampleHeight(hf, region.center[0], region.center[1]);
  objects.push({
    id: newId('house'),
    name: 'Farmhouse',
    kind: 'house',
    prefab: 'structure.house_b',
    position: [r2(region.center[0] + region.radius * 0.45), r2(by), r2(region.center[1] - region.radius * 0.35)],
    rotation: [0, r2(rng() * Math.PI), 0],
    scale: 1.2,
    tags: ['farm', 'structure'],
  });
  objects.push({
    id: newId('farm'),
    name: 'Barn',
    kind: 'farm',
    prefab: 'structure.barn',
    position: [r2(region.center[0] - region.radius * 0.5), r2(sampleHeight(hf, region.center[0] - region.radius * 0.5, region.center[1] + region.radius * 0.3)), r2(region.center[1] + region.radius * 0.3)],
    rotation: [0, r2(rng() * Math.PI), 0],
    scale: 1.1,
    tags: ['farm', 'structure'],
  });

  paths.push({
    id: newId('path'),
    kind: 'path',
    width: 1.6,
    points: [
      [r2(region.center[0]), r2(region.center[1])],
      [r2(region.center[0] + region.radius * 0.5), r2(region.center[1] - region.radius * 0.35)],
    ],
  });

  return { objects, paths };
}

function expandRuins(plan: WorldPlan, hf: Heightfield, region: Region): RegionExpansion {
  const rng: Rng = rngFrom(`${plan.seed}:${region.id}`);
  const objects: WorldObject[] = [];
  const count = randInt(rng, 6, 14);
  for (let i = 0; i < count; i++) {
    const a = rng() * Math.PI * 2;
    const r = Math.sqrt(rng()) * region.radius * 0.85;
    const x = region.center[0] + Math.cos(a) * r;
    const z = region.center[1] + Math.sin(a) * r;
    const y = sampleHeight(hf, x, z);
    if (y <= hf.waterLevel) continue;
    const broken = chance(rng, 0.6);
    objects.push({
      id: newId('ruin'),
      name: broken ? 'Broken column' : 'Ruin wall',
      kind: 'ruin',
      prefab: broken ? 'structure.ruin_column' : 'structure.ruin_wall',
      position: [r2(x), r2(y - 0.1), r2(z)],
      rotation: [r2((rng() - 0.5) * 0.25), r2(rng() * Math.PI * 2), r2((rng() - 0.5) * 0.25)],
      scale: r2(randRange(rng, 0.7, 1.35)),
      tags: ['ruins'],
    });
  }
  return { objects, paths: [] };
}

function expandTemple(plan: WorldPlan, hf: Heightfield, region: Region): RegionExpansion {
  const rng: Rng = rngFrom(`${plan.seed}:${region.id}`);
  const objects: WorldObject[] = [];
  const y = sampleHeight(hf, region.center[0], region.center[1]);
  objects.push({
    id: newId('temple'),
    name: 'Temple',
    kind: 'temple',
    prefab: 'structure.temple',
    position: [r2(region.center[0]), r2(y - 0.1), r2(region.center[1])],
    rotation: [0, r2(rng() * Math.PI * 2), 0],
    scale: r2(randRange(rng, 1, 1.3)),
    tags: ['temple', 'landmark'],
  });
  // Ring of columns.
  const n = randInt(rng, 6, 10);
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const x = region.center[0] + Math.cos(a) * region.radius * 0.55;
    const z = region.center[1] + Math.sin(a) * region.radius * 0.55;
    const cy = sampleHeight(hf, x, z);
    objects.push({
      id: newId('ruin'),
      name: 'Column',
      kind: 'ruin',
      prefab: 'structure.ruin_column',
      position: [r2(x), r2(cy - 0.05), r2(z)],
      rotation: [0, r2(a), 0],
      scale: r2(randRange(rng, 1.1, 1.5)),
      tags: ['temple'],
    });
  }
  return { objects, paths: [] };
}

function expandGraveyard(plan: WorldPlan, hf: Heightfield, region: Region): RegionExpansion {
  const rng: Rng = rngFrom(`${plan.seed}:${region.id}`);
  const objects: WorldObject[] = [];
  const rows = randInt(rng, 3, 5);
  const cols = randInt(rng, 4, 7);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (chance(rng, 0.18)) continue;
      const x = region.center[0] + (c / (cols - 1) - 0.5) * region.radius * 1.1;
      const z = region.center[1] + (r / (rows - 1) - 0.5) * region.radius * 1.1;
      const y = sampleHeight(hf, x, z);
      if (y <= hf.waterLevel) continue;
      objects.push({
        id: newId('ruin'),
        kind: 'ruin',
        prefab: 'structure.gravestone',
        position: [r2(x), r2(y - 0.05), r2(z)],
        rotation: [0, r2((rng() - 0.5) * 0.5), 0],
        scale: r2(randRange(rng, 0.85, 1.15)),
        tags: ['graveyard'],
      });
    }
  }
  return { objects, paths: [] };
}

function wallRing(plan: WorldPlan, hf: Heightfield, center: [number, number], radius: number, rng: Rng): WorldObject[] {
  const objects: WorldObject[] = [];
  const n = Math.max(8, Math.floor((radius * Math.PI * 2) / 7));
  const pts: Array<[number, number]> = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    pts.push([center[0] + Math.cos(a) * radius, center[1] + Math.sin(a) * radius]);
  }
  for (let i = 0; i < n; i++) {
    objects.push(...wallSegment(plan, hf, pts[i], pts[(i + 1) % n], rng));
  }
  return objects;
}

function wallSegment(plan: WorldPlan, hf: Heightfield, a: [number, number], b: [number, number], rng: Rng): WorldObject[] {
  const objects: WorldObject[] = [];
  const dx = b[0] - a[0];
  const dz = b[1] - a[1];
  const len = Math.sqrt(dx * dx + dz * dz);
  const pieces = Math.max(1, Math.round(len / 4.5));
  const yaw = Math.atan2(dz, dx);
  for (let i = 0; i < pieces; i++) {
    const t = (i + 0.5) / pieces;
    const x = a[0] + dx * t;
    const z = a[1] + dz * t;
    const y = sampleHeight(hf, x, z);
    if (y <= hf.waterLevel) continue;
    objects.push({
      id: newId('wall'),
      kind: 'wall',
      prefab: 'structure.wall_segment',
      position: [r2(x), r2(y - 0.05), r2(z)],
      rotation: [0, r2(yaw), 0],
      scale: r2(randRange(rng, 0.95, 1.1)),
      tags: ['wall'],
    });
  }
  return objects;
}

function roadPoints(from: Vec2, to: Vec2, rng: Rng): Vec2[] {
  const pts: Vec2[] = [from];
  const segs = randInt(rng, 2, 4);
  for (let i = 1; i < segs; i++) {
    const t = i / segs;
    const wobble = (rng() - 0.5) * 3;
    const px = from[0] + (to[0] - from[0]) * t + wobble;
    const pz = from[1] + (to[1] - from[1]) * t - wobble;
    pts.push([r2(px), r2(pz)]);
  }
  pts.push(to);
  return pts;
}

function r2(v: number): number {
  return Math.round(v * 100) / 100;
}
