/**
 * Terrain heightfield generation from a WorldPlan's terrain spec.
 * Pure and deterministic: (plan, resolution) => Float32Array heights.
 */
import { Noise2D, clamp, smoothstep } from '../core/noise';
import type { WorldPlan, TerrainFeature } from '../core/types';

export interface Heightfield {
  resolution: number;
  /** World-space extent in meters (square, centered on origin). */
  size: number;
  heights: Float32Array;
  waterLevel: number;
}

export function generateHeightfield(plan: WorldPlan, resolution = 129): Heightfield {
  const { terrain, seed, settings } = plan;
  const size = Math.max(settings.size.widthMeters, settings.size.depthMeters);
  const heightScale = settings.size.heightScale ?? 48;
  const params = terrain.params ?? {};
  const octaves = params.octaves ?? 5;
  const frequency = params.frequency ?? 0.008;
  const amplitude = params.amplitude ?? heightScale * 0.6;
  const ridgeMix = params.ridgeMix ?? 0.35;
  const persistence = params.persistence ?? 0.5;
  const lacunarity = params.lacunarity ?? 2.1;
  const terracing = params.terracing ?? 0;
  const warpStrength = params.warpStrength ?? 0.15;

  const noiseA = new Noise2D(seed);
  const noiseB = new Noise2D(seed + 101);
  const heights = new Float32Array(resolution * resolution);
  const half = size / 2;
  const cell = size / (resolution - 1);

  for (let j = 0; j < resolution; j++) {
    for (let i = 0; i < resolution; i++) {
      const x = -half + i * cell;
      const z = -half + j * cell;

      // Domain warp for more natural landforms.
      const wx = x + warpStrength * 60 * noiseB.fbm(x * 0.004, z * 0.004, 2);
      const wz = z + warpStrength * 60 * noiseB.fbm(x * 0.004 + 40, z * 0.004 - 25, 2);

      let h = 0;
      switch (terrain.generator) {
        case 'flat':
          h = 0;
          break;
        case 'islands': {
          const n = noiseA.fbm(wx * frequency, wz * frequency, octaves, persistence, lacunarity) * 0.5 + 0.5;
          const dx = x / half;
          const dz = z / half;
          const dist = Math.sqrt(dx * dx + dz * dz);
          const islandMask = smoothstep(1.05, 0.35, dist);
          const ridge = noiseA.ridged(wx * frequency * 2, wz * frequency * 2, 3);
          h = (n * 0.75 + ridge * ridgeMix * 0.35) * islandMask * amplitude - amplitude * 0.12;
          break;
        }
        case 'canyons': {
          const base = noiseA.fbm(wx * frequency, wz * frequency, octaves, persistence, lacunarity);
          const ridged = noiseA.ridged(wx * frequency * 1.6, wz * frequency * 1.6, 4, persistence, lacunarity);
          // Carve sharp valleys into a raised plateau.
          const plateau = amplitude * 0.55;
          const carve = smoothstep(0.25, 0.85, ridged) * amplitude * 0.9;
          h = plateau + base * amplitude * 0.15 - carve;
          break;
        }
        case 'mountains': {
          const ridged = noiseA.ridged(wx * frequency, wz * frequency, octaves, persistence, lacunarity);
          const base = noiseA.fbm(wx * frequency * 0.7, wz * frequency * 0.7, 3);
          h = ridged * amplitude * 1.15 + base * amplitude * 0.18 - amplitude * 0.15;
          break;
        }
        case 'fbm':
        default: {
          const base = noiseA.fbm(wx * frequency, wz * frequency, octaves, persistence, lacunarity);
          const ridged = noiseA.ridged(wx * frequency * 1.4, wz * frequency * 1.4, 3, persistence, lacunarity);
          h = base * amplitude * (1 - ridgeMix * 0.45) + ridged * amplitude * ridgeMix * 0.75;
          break;
        }
      }

      // Explicit terrain features (mountains, lakes, craters, …).
      for (const f of terrain.features ?? []) {
        h = applyFeature(h, f, x, z);
      }

      // Biome height bias.
      h += biomeBias(plan, x, z) * 0.35;

      if (terracing > 1) {
        const step = amplitude / terracing;
        h = Math.round(h / step) * step;
      }

      heights[j * resolution + i] = h;
    }
  }

  // Gentle smoothing pass keeps slopes walkable without erasing detail.
  smooth(heights, resolution, 1, 0.35);

  return { resolution, size, heights, waterLevel: terrain.waterLevel };
}

function applyFeature(h: number, f: TerrainFeature, x: number, z: number): number {
  const r = f.radius ?? 20;
  const dx = x - f.position[0];
  const dz = z - f.position[1];
  const d2 = dx * dx + dz * dz;
  const d = Math.sqrt(d2);
  if (d > r * 1.5) return h;
  const falloff = f.falloff ?? 0.5;
  const t = smoothstep(r, r * (1 - falloff * 0.9), d); // 0 at edge, 1 at center

  switch (f.type) {
    case 'mountain':
      return h + t * (f.height ?? 40);
    case 'hill':
      return h + t * (f.height ?? 12);
    case 'plateau': {
      const target = f.height ?? h + 10;
      return h * (1 - t) + target * t;
    }
    case 'valley':
      return h - t * (f.height ?? 15);
    case 'cliff': {
      // Sharp step along the +x side of the feature center.
      const side = smoothstep(-r * 0.15, r * 0.15, dx) * smoothstep(r, r * 0.2, d);
      return h + side * (f.height ?? 18);
    }
    case 'canyon': {
      const band = smoothstep(r, r * 0.55, d);
      return h - band * (f.height ?? 20);
    }
    case 'crater': {
      const rim = smoothstep(r, r * 0.75, d) * (1 - smoothstep(r * 0.75, r * 0.45, d));
      const bowl = smoothstep(r * 0.55, 0, d);
      return h + rim * (f.height ?? 8) * 0.6 - bowl * (f.height ?? 8);
    }
    case 'lake': {
      const bowl = smoothstep(r, r * 0.15, d);
      return h - bowl * (f.height ?? 12);
    }
    case 'river': {
      // River = trench along a polyline encoded in params.points
      const pts = (f.params?.points as number[][] | undefined) ?? [[f.position[0], f.position[1]]];
      const width = f.radius ?? 10;
      let minD = Infinity;
      for (let i = 0; i < pts.length - 1; i++) {
        minD = Math.min(minD, distToSegment(x, z, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1]));
      }
      if (pts.length === 1) minD = d;
      const trench = smoothstep(width, width * 0.25, minD);
      return h - trench * (f.height ?? 6);
    }
    case 'beach': {
      // Flatten toward water level in a ring near the center.
      const target = (f.height ?? 0) + 1.5;
      return h * (1 - t * 0.8) + target * t * 0.8;
    }
    default:
      return h;
  }
}

function biomeBias(plan: WorldPlan, x: number, z: number): number {
  const biomes = plan.biomes ?? [];
  let bias = 0;
  let totalW = 0;
  for (const b of biomes) {
    const dx = x - b.center[0];
    const dz = z - b.center[1];
    const d = Math.sqrt(dx * dx + dz * dz);
    const w = smoothstep(b.radius, b.radius * 0.25, d) * (b.weight ?? 1);
    if (w > 0) {
      const presetBias = BIOME_HEIGHT_BIAS[b.type] ?? 0;
      bias += presetBias * w;
      totalW += w;
    }
  }
  return totalW > 0 ? bias / totalW : 0;
}

const BIOME_HEIGHT_BIAS: Record<string, number> = {
  mountains: 14, hills: 6, plateau: 5, canyon: -2, valley: -4,
  lake: -8, ocean: -14, river: -5, beach: -3, swamp: -4,
  desert: 1, snow: 5, volcanic: 8, forest: 0, plains: -1, island: -2, tundra: 2,
};

function distToSegment(px: number, pz: number, ax: number, az: number, bx: number, bz: number): number {
  const abx = bx - ax;
  const abz = bz - az;
  const apx = px - ax;
  const apz = pz - az;
  const ab2 = abx * abx + abz * abz || 1;
  let t = (apx * abx + apz * abz) / ab2;
  t = clamp(t, 0, 1);
  const cx = ax + abx * t;
  const cz = az + abz * t;
  return Math.sqrt((px - cx) ** 2 + (pz - cz) ** 2);
}

export function smooth(data: Float32Array, resolution: number, iterations = 1, strength = 0.5): void {
  for (let it = 0; it < iterations; it++) {
    const copy = data.slice();
    for (let j = 1; j < resolution - 1; j++) {
      for (let i = 1; i < resolution - 1; i++) {
        const idx = j * resolution + i;
        const avg = (copy[idx - 1] + copy[idx + 1] + copy[idx - resolution] + copy[idx + resolution]) / 4;
        data[idx] = copy[idx] * (1 - strength) + avg * strength;
      }
    }
  }
}

/** Bilinear height lookup in world space. */
export function sampleHeight(hf: Heightfield, x: number, z: number): number {
  const half = hf.size / 2;
  const cell = hf.size / (hf.resolution - 1);
  const fx = clamp((x + half) / cell, 0, hf.resolution - 1.001);
  const fz = clamp((z + half) / cell, 0, hf.resolution - 1.001);
  const i0 = Math.floor(fx);
  const j0 = Math.floor(fz);
  const i1 = Math.min(i0 + 1, hf.resolution - 1);
  const j1 = Math.min(j0 + 1, hf.resolution - 1);
  const tx = fx - i0;
  const tz = fz - j0;
  const h00 = hf.heights[j0 * hf.resolution + i0];
  const h10 = hf.heights[j0 * hf.resolution + i1];
  const h01 = hf.heights[j1 * hf.resolution + i0];
  const h11 = hf.heights[j1 * hf.resolution + i1];
  return (h00 * (1 - tx) + h10 * tx) * (1 - tz) + (h01 * (1 - tx) + h11 * tx) * tz;
}

/** Approximate surface normal from central differences. */
export function sampleNormal(hf: Heightfield, x: number, z: number, eps = 1): { x: number; y: number; z: number } {
  const hL = sampleHeight(hf, x - eps, z);
  const hR = sampleHeight(hf, x + eps, z);
  const hD = sampleHeight(hf, x, z - eps);
  const hU = sampleHeight(hf, x, z + eps);
  const nx = hL - hR;
  const nz = hD - hU;
  const ny = 2 * eps;
  const len = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
  return { x: nx / len, y: ny / len, z: nz / len };
}

export function heightfieldToJSON(hf: Heightfield): { resolution: number; size: number; waterLevel: number; data: number[] } {
  return { resolution: hf.resolution, size: hf.size, waterLevel: hf.waterLevel, data: Array.from(hf.heights) };
}

export function heightfieldFromJSON(json: { resolution: number; size: number; waterLevel: number; data: number[] }): Heightfield {
  return { resolution: json.resolution, size: json.size, waterLevel: json.waterLevel, heights: Float32Array.from(json.data) };
}
