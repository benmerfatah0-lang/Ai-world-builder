/**
 * Palette-driven material factory. Materials are cached per (palette, override)
 * so scenes share materials and stay fast.
 */
import * as THREE from 'three';
import { getPalette, type Palette } from '../generators/presets';
import type { ArtStyle, MaterialOverride } from '../core/types';

export class MaterialFactory {
  private cache = new Map<string, THREE.Material>();
  readonly palette: Palette;

  constructor(private style: ArtStyle) {
    this.palette = getPalette(style);
  }

  private key(color: string, rough: number, metal: number, flat: boolean, emissive?: string): string {
    return `${color}|${rough}|${metal}|${flat}|${emissive ?? ''}`;
  }

  get(colorKey: keyof Palette['colors'], override?: MaterialOverride): THREE.Material {
    const color = override?.color ?? this.palette.colors[colorKey] ?? '#888888';
    const rough = override?.roughness ?? this.palette.roughness;
    const metal = override?.metalness ?? this.palette.metalness;
    const flat = override?.flatShading ?? this.palette.flatShading;
    const emissive = override?.emissive;
    const k = this.key(color, rough, metal, flat, emissive);
    let mat = this.cache.get(k);
    if (!mat) {
      const params: THREE.MeshStandardMaterialParameters = {
        color: new THREE.Color(color),
        roughness: rough,
        metalness: metal,
        flatShading: flat,
      };
      if (emissive) {
        params.emissive = new THREE.Color(emissive);
        params.emissiveIntensity = 0.85;
      }
      mat = new THREE.MeshStandardMaterial(params);
      this.cache.set(k, mat);
    }
    return mat;
  }

  water(): THREE.Material {
    let mat = this.cache.get('water-special') as THREE.MeshStandardMaterial | undefined;
    if (!mat) {
      mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(this.palette.colors.water),
        roughness: 0.18,
        metalness: 0.12,
        transparent: true,
        opacity: 0.82,
        flatShading: this.palette.flatShading,
      });
      this.cache.set('water-special', mat);
    }
    return mat;
  }

  dispose(): void {
    for (const m of this.cache.values()) m.dispose();
    this.cache.clear();
  }
}
