/**
 * Procedural prefab builders. Each builder returns a THREE.Group built from
 * primitives — these are the "asset library" prefabs used when no AI-generated
 * or user-imported model exists. Honest procedural modeling, not fake AI.
 */
import * as THREE from 'three';
import { rngFrom, randRange, chance, pick, type Rng } from '../core/rng';
import type { MaterialFactory } from './materials';
import type { Palette } from '../generators/presets';
import type { WorldObject, ObjectKind, Vec3 } from '../core/types';

export type PrefabBuilder = (mf: MaterialFactory, rng: Rng) => THREE.Object3D;

function trunkGeometry(rng: Rng, height: number, radius: number): THREE.CylinderGeometry {
  return new THREE.CylinderGeometry(radius * 0.72, radius, height, 6, 1);
}

function buildTree(mf: MaterialFactory, rng: Rng, opts: { pine?: boolean; snowy?: boolean; palm?: boolean; dead?: boolean; willow?: boolean }): THREE.Group {
  const g = new THREE.Group();
  const h = randRange(rng, 3.2, 5.4);
  const trunk = new THREE.Mesh(trunkGeometry(rng, h, randRange(rng, 0.18, 0.3)), mf.get('trunk'));
  trunk.position.y = h / 2;
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  g.add(trunk);

  if (opts.dead) {
    for (let i = 0; i < 3; i++) {
      const branch = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.11, randRange(rng, 1, 1.8), 5), mf.get('trunk'));
      branch.position.set(0, h * randRange(rng, 0.5, 0.85), 0);
      branch.rotation.set(randRange(rng, -1, 1), rng() * Math.PI * 2, randRange(rng, 0.5, 1.1));
      branch.castShadow = true;
      g.add(branch);
    }
    return g;
  }

  if (opts.pine) {
    const layers = 3 + Math.floor(rng() * 2);
    for (let i = 0; i < layers; i++) {
      const t = i / layers;
      const radius = (1 - t) * randRange(rng, 1.25, 1.7);
      const cone = new THREE.Mesh(new THREE.ConeGeometry(radius, randRange(rng, 1.4, 2.1), 7), mf.get(opts.snowy ? 'snow' : 'leaves'));
      cone.position.y = h * 0.45 + t * h * 0.55;
      cone.castShadow = true;
      cone.receiveShadow = true;
      g.add(cone);
      if (opts.snowy && i === 0) {
        const snowCap = new THREE.Mesh(new THREE.ConeGeometry(radius * 1.02, 0.5, 7), mf.get('snow'));
        snowCap.position.y = cone.position.y + 0.35;
        g.add(snowCap);
      }
    }
  } else if (opts.palm) {
    const bend = randRange(rng, 0.35, 0.7);
    (trunk as THREE.Mesh<THREE.CylinderGeometry>).geometry.dispose();
    (trunk as THREE.Mesh).geometry = new THREE.CylinderGeometry(0.14, 0.24, h, 6, 6);
    trunk.position.set(bend * 1.4, h / 2, 0);
    trunk.rotation.z = -bend * 0.35;
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const frond = new THREE.Mesh(new THREE.ConeGeometry(0.32, randRange(rng, 2.2, 3), 4), mf.get('leaves'));
      frond.position.set(Math.cos(a) * 1.15 + bend * 2.2, h * 0.98, Math.sin(a) * 1.15);
      frond.rotation.set(Math.PI / 2 - 0.45, 0, -a + Math.PI / 2);
      frond.castShadow = true;
      g.add(frond);
    }
  } else {
    const blobs = opts.willow ? 4 : 3;
    for (let i = 0; i < blobs; i++) {
      const r = randRange(rng, 1.1, 1.75);
      const foliage = new THREE.Mesh(
        opts.willow ? new THREE.SphereGeometry(r, 7, 6) : new THREE.IcosahedronGeometry(r, 1),
        mf.get(chance(rng, 0.5) ? 'leaves' : 'leavesAlt'),
      );
      foliage.position.set(
        randRange(rng, -0.7, 0.7),
        h * randRange(rng, 0.72, 1.02) + i * 0.35,
        randRange(rng, -0.7, 0.7),
      );
      foliage.scale.y = opts.willow ? randRange(rng, 1.15, 1.5) : randRange(rng, 0.85, 1.1);
      foliage.castShadow = true;
      foliage.receiveShadow = true;
      g.add(foliage);
      if (opts.willow) {
        for (let s = 0; s < 4; s++) {
          const strand = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.02, randRange(rng, 1.2, 2.2), 4), mf.get('leavesAlt'));
          strand.position.copy(foliage.position).add(new THREE.Vector3(randRange(rng, -1, 1), -randRange(rng, 0.8, 1.4), randRange(rng, -1, 1)));
          g.add(strand);
        }
      }
    }
  }
  return g;
}

function buildRock(mf: MaterialFactory, rng: Rng, opts: { mossy?: boolean; ice?: boolean; obsidian?: boolean; dune?: boolean; small?: boolean }): THREE.Group {
  const g = new THREE.Group();
  const r = opts.small ? randRange(rng, 0.25, 0.55) : randRange(rng, 0.6, 1.5);
  const geo = new THREE.IcosahedronGeometry(r, opts.small ? 0 : 1);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const v = new THREE.Vector3().fromBufferAttribute(pos, i);
    const n = 0.78 + ((i * 2654435761) % 1000) / 1000 * 0.42;
    v.multiplyScalar(n);
    pos.setXYZ(i, v.x, v.y * (opts.dune ? 0.45 : 0.8), v.z);
  }
  geo.computeVertexNormals();
  const key: keyof Palette['colors'] = opts.obsidian ? 'rockDark' : opts.ice ? 'snow' : opts.mossy ? 'grass' : 'rock';
  const mesh = new THREE.Mesh(geo, mf.get(key));
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  g.add(mesh);
  if (opts.mossy) {
    const moss = new THREE.Mesh(new THREE.SphereGeometry(r * 0.75, 7, 5, 0, Math.PI * 2, 0, Math.PI * 0.4), mf.get('grass'));
    moss.position.y = r * 0.55;
    g.add(moss);
  }
  return g;
}

function buildHouse(mf: MaterialFactory, rng: Rng, opts: { hut?: boolean; barn?: boolean } = {}): THREE.Group {
  const g = new THREE.Group();
  const w = opts.hut ? randRange(rng, 2.4, 3.2) : opts.barn ? randRange(rng, 6, 8) : randRange(rng, 3.4, 5);
  const d = opts.hut ? randRange(rng, 2.4, 3) : opts.barn ? randRange(rng, 4.5, 6) : randRange(rng, 3, 4.4);
  const h = opts.hut ? randRange(rng, 1.9, 2.4) : opts.barn ? randRange(rng, 3.4, 4.2) : randRange(rng, 2.4, 3.2);

  const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mf.get(opts.hut ? 'wood' : 'stone'));
  body.position.y = h / 2;
  body.castShadow = true;
  body.receiveShadow = true;
  g.add(body);

  // Pitched roof as a scaled cylinder prism.
  const roofH = opts.barn ? 2.2 : 1.5;
  const roofGeo = new THREE.CylinderGeometry(0.001, Math.SQRT2 * 0.5 * Math.max(w, d) * 0.78, roofH, 4, 1);
  const roof = new THREE.Mesh(roofGeo, mf.get(chance(rng, 0.5) ? 'roof' : 'roofAlt'));
  roof.position.y = h + roofH / 2 - 0.02;
  roof.rotation.y = Math.PI / 4;
  roof.scale.set(w >= d ? 1 : d / w, 1, d > w ? w / d * (d / w) : 1);
  roof.scale.z = (d / Math.max(w, d)) * 1.28;
  roof.scale.x = (w / Math.max(w, d)) * 1.28;
  roof.castShadow = true;
  g.add(roof);

  // Door
  const door = new THREE.Mesh(new THREE.BoxGeometry(w * 0.18, h * 0.55, 0.12), mf.get('wood'));
  door.position.set(0, h * 0.28, d / 2 + 0.04);
  g.add(door);

  // Windows
  const windowCount = opts.hut ? 1 : 2;
  for (let i = 0; i < windowCount; i++) {
    const win = new THREE.Mesh(new THREE.BoxGeometry(w * 0.16, h * 0.22, 0.1), mf.get('accent'));
    win.position.set((i - (windowCount - 1) / 2) * w * 0.32, h * 0.62, d / 2 + 0.04);
    g.add(win);
    const winBack = win.clone();
    winBack.position.z = -d / 2 - 0.04;
    g.add(winBack);
  }

  // Chimney
  if (chance(rng, opts.hut ? 0.35 : 0.7)) {
    const chimney = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.3, 0.55), mf.get('stoneDark'));
    chimney.position.set(w * 0.28, h + roofH * 0.55, -d * 0.12);
    chimney.castShadow = true;
    g.add(chimney);
  }
  return g;
}

function buildTower(mf: MaterialFactory, rng: Rng, opts: { keep?: boolean; gatehouse?: boolean } = {}): THREE.Group {
  const g = new THREE.Group();
  const h = opts.keep ? randRange(rng, 9, 12) : randRange(rng, 6, 8.5);
  const r = opts.keep ? randRange(rng, 2.4, 3) : randRange(rng, 1.5, 2);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.12, h, 8), mf.get('stone'));
  body.position.y = h / 2;
  body.castShadow = true;
  body.receiveShadow = true;
  g.add(body);

  // Battlements
  const merlons = 8;
  for (let i = 0; i < merlons; i++) {
    const a = (i / merlons) * Math.PI * 2;
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.75, 0.35), mf.get('stoneDark'));
    m.position.set(Math.cos(a) * r * 0.95, h + 0.35, Math.sin(a) * r * 0.95);
    m.rotation.y = -a;
    m.castShadow = true;
    g.add(m);
  }

  if (!opts.keep && chance(rng, 0.55)) {
    const roof = new THREE.Mesh(new THREE.ConeGeometry(r * 1.12, randRange(rng, 2.2, 3.2), 8), mf.get('roof'));
    roof.position.y = h + 1.7;
    roof.castShadow = true;
    g.add(roof);
    const flagPole = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.6, 4), mf.get('metal'));
    flagPole.position.y = h + 4;
    g.add(flagPole);
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.5), mf.get('accent'));
    flag.position.set(0.45, h + 4.5, 0);
    g.add(flag);
  }

  if (opts.gatehouse) {
    const gate = new THREE.Mesh(new THREE.BoxGeometry(r * 1.05, h * 0.42, r * 2.15), mf.get('stoneDark'));
    gate.position.y = h * 0.21;
    g.add(gate);
  }
  return g;
}

function buildWall(mf: MaterialFactory, rng: Rng): THREE.Group {
  const g = new THREE.Group();
  const seg = new THREE.Mesh(new THREE.BoxGeometry(4.6, 2.2, 0.75), mf.get('stone'));
  seg.position.y = 1.1;
  seg.castShadow = true;
  seg.receiveShadow = true;
  g.add(seg);
  for (let i = 0; i < 5; i++) {
    const cap = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.5, 0.85), mf.get('stoneDark'));
    cap.position.set(-1.9 + i * 0.95, 2.45, 0);
    g.add(cap);
  }
  return g;
}

function buildBridge(mf: MaterialFactory, rng: Rng): THREE.Group {
  const g = new THREE.Group();
  const deck = new THREE.Mesh(new THREE.BoxGeometry(8, 0.35, 2.6), mf.get('wood'));
  deck.position.y = 1.15;
  deck.castShadow = true;
  deck.receiveShadow = true;
  g.add(deck);
  for (const side of [-1, 1]) {
    const rail = new THREE.Mesh(new THREE.BoxGeometry(8, 0.12, 0.12), mf.get('wood'));
    rail.position.set(0, 1.95, side * 1.2);
    g.add(rail);
    for (let i = 0; i < 5; i++) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.9, 0.14), mf.get('wood'));
      post.position.set(-3.4 + i * 1.7, 1.55, side * 1.2);
      g.add(post);
    }
  }
  for (const x of [-3, 3]) {
    const support = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.2, 2.8), mf.get('stoneDark'));
    support.position.set(x, 0.55, 0);
    g.add(support);
  }
  return g;
}

function buildProp(mf: MaterialFactory, rng: Rng, kind: ObjectKind): THREE.Group {
  const g = new THREE.Group();
  switch (kind) {
    case 'crate': {
      const s = randRange(rng, 0.55, 0.85);
      const box = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), mf.get('wood'));
      box.position.y = s / 2;
      box.castShadow = true;
      box.receiveShadow = true;
      g.add(box);
      break;
    }
    case 'barrel': {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 0.85, 10), mf.get('wood'));
      body.position.y = 0.43;
      body.castShadow = true;
      g.add(body);
      for (const y of [0.18, 0.68]) {
        const hoop = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.035, 6, 14), mf.get('metal'));
        hoop.position.y = y;
        hoop.rotation.x = Math.PI / 2;
        g.add(hoop);
      }
      break;
    }
    case 'bench': {
      const seat = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.1, 0.5), mf.get('wood'));
      seat.position.y = 0.5;
      seat.castShadow = true;
      g.add(seat);
      const back = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.5, 0.08), mf.get('wood'));
      back.position.set(0, 0.85, -0.22);
      g.add(back);
      for (const x of [-0.7, 0.7]) {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.5, 0.45), mf.get('wood'));
        leg.position.set(x, 0.25, 0);
        g.add(leg);
      }
      break;
    }
    case 'lamp': {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 2.6, 6), mf.get('metal'));
      pole.position.y = 1.3;
      pole.castShadow = true;
      g.add(pole);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.19, 8, 6), mf.get('emissive' as keyof Palette['colors'], { emissive: '#ffcf7a', color: '#ffe9b0' }));
      head.position.y = 2.72;
      g.add(head);
      const cap = new THREE.Mesh(new THREE.ConeGeometry(0.26, 0.22, 8), mf.get('metal'));
      cap.position.y = 2.95;
      g.add(cap);
      break;
    }
    case 'well': {
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.95, 0.7, 10), mf.get('stone'));
      base.position.y = 0.35;
      base.castShadow = true;
      base.receiveShadow = true;
      g.add(base);
      for (const x of [-0.72, 0.72]) {
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.6, 5), mf.get('wood'));
        post.position.set(x, 1.15, 0);
        g.add(post);
      }
      const roof = new THREE.Mesh(new THREE.ConeGeometry(1.15, 0.75, 4), mf.get('roof'));
      roof.position.y = 2.35;
      roof.rotation.y = Math.PI / 4;
      roof.castShadow = true;
      g.add(roof);
      const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.5, 5), mf.get('wood'));
      bar.rotation.z = Math.PI / 2;
      bar.position.y = 1.85;
      g.add(bar);
      break;
    }
    case 'campfire': {
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * Math.PI * 2;
        const stone = new THREE.Mesh(new THREE.DodecahedronGeometry(0.14, 0), mf.get('stoneDark'));
        stone.position.set(Math.cos(a) * 0.55, 0.1, Math.sin(a) * 0.55);
        g.add(stone);
      }
      for (const rot of [-0.6, 0.6]) {
        const log = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.95, 5), mf.get('trunk'));
        log.position.y = 0.14;
        log.rotation.set(Math.PI / 2, 0, rot);
        g.add(log);
      }
      const flame = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.55, 6), mf.get('emissive' as keyof Palette['colors'], { emissive: '#ff8c2b', color: '#ff9d3c' }));
      flame.position.y = 0.45;
      flame.name = 'flame';
      g.add(flame);
      break;
    }
    case 'fence': {
      for (let i = 0; i < 3; i++) {
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1, 0.12), mf.get('wood'));
        post.position.set(-1 + i, 0.5, 0);
        post.castShadow = true;
        g.add(post);
      }
      for (const y of [0.42, 0.78]) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.09, 0.09), mf.get('wood'));
        rail.position.set(0, y, 0);
        g.add(rail);
      }
      break;
    }
    case 'boat': {
      const hull = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.18, 2.4, 6, 1), mf.get('wood'));
      hull.rotation.x = Math.PI / 2;
      hull.scale.set(1, 1, 0.55);
      hull.position.y = 0.3;
      hull.castShadow = true;
      g.add(hull);
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.8, 5), mf.get('wood'));
      mast.position.y = 1.1;
      g.add(mast);
      const sail = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.1), mf.get('snow'));
      sail.position.set(0.35, 1.35, 0);
      sail.rotation.y = Math.PI / 2.4;
      g.add(sail);
      break;
    }
    case 'crystal': {
      const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(randRange(rng, 0.45, 0.9), 0), mf.get('accent', { emissive: '#4fd8ff', color: '#66e0ff' }));
      crystal.position.y = 0.75;
      crystal.scale.y = randRange(rng, 1.5, 2.4);
      crystal.castShadow = true;
      g.add(crystal);
      for (let i = 0; i < 3; i++) {
        const shard = new THREE.Mesh(new THREE.OctahedronGeometry(0.28, 0), crystal.material);
        shard.position.set(randRange(rng, -0.6, 0.6), 0.32, randRange(rng, -0.6, 0.6));
        shard.scale.y = randRange(rng, 1.2, 1.9);
        g.add(shard);
      }
      break;
    }
    case 'mushroom': {
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, 0.35, 6), mf.get('snow'));
      stem.position.y = 0.18;
      g.add(stem);
      const cap = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 5, 0, Math.PI * 2, 0, Math.PI * 0.55), mf.get('roof'));
      cap.position.y = 0.36;
      g.add(cap);
      break;
    }
    case 'flower': {
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.02, 0.35, 4), mf.get('leaves'));
      stem.position.y = 0.18;
      g.add(stem);
      const bloom = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 5), mf.get('accent'));
      bloom.position.y = 0.4;
      g.add(bloom);
      break;
    }
    case 'bush': {
      for (let i = 0; i < 3; i++) {
        const blob = new THREE.Mesh(new THREE.IcosahedronGeometry(randRange(rng, 0.3, 0.55), 1), mf.get(chance(rng, 0.5) ? 'leaves' : 'leavesAlt'));
        blob.position.set(randRange(rng, -0.35, 0.35), randRange(rng, 0.25, 0.55), randRange(rng, -0.35, 0.35));
        blob.castShadow = true;
        g.add(blob);
      }
      break;
    }
    case 'grass':
    case 'cactus':
    case 'custom':
    default:
      return buildGeneric(mf, rng, kind);
  }
  return g;
}

function buildGeneric(mf: MaterialFactory, rng: Rng, kind: string): THREE.Group {
  const g = new THREE.Group();
  if (kind === 'cactus') {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, randRange(rng, 1.6, 2.6), 8), mf.get('leaves'));
    body.position.y = 1.1;
    body.castShadow = true;
    g.add(body);
    for (const side of [-1, 1]) {
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.9, 7), mf.get('leaves'));
      arm.position.set(side * 0.42, 1.5, 0);
      arm.rotation.z = side * -0.9;
      g.add(arm);
    }
  } else if (kind === 'grass' || kind === 'plant') {
    for (let i = 0; i < 5; i++) {
      const blade = new THREE.Mesh(new THREE.ConeGeometry(0.045, randRange(rng, 0.35, 0.7), 4), mf.get('grass'));
      blade.position.set(randRange(rng, -0.18, 0.18), 0.22, randRange(rng, -0.18, 0.18));
      blade.rotation.set(randRange(rng, -0.3, 0.3), 0, randRange(rng, -0.3, 0.3));
      g.add(blade);
    }
  } else {
    const geo = new THREE.DodecahedronGeometry(randRange(rng, 0.4, 0.9), 0);
    const mesh = new THREE.Mesh(geo, mf.get('accent'));
    mesh.position.y = 0.55;
    mesh.castShadow = true;
    g.add(mesh);
  }
  return g;
}

function buildTemple(mf: MaterialFactory, rng: Rng): THREE.Group {
  const g = new THREE.Group();
  const base = new THREE.Mesh(new THREE.BoxGeometry(7, 0.7, 7), mf.get('stone'));
  base.position.y = 0.35;
  base.receiveShadow = true;
  g.add(base);
  const second = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.55, 5.6), mf.get('stone'));
  second.position.y = 0.95;
  g.add(second);
  for (const [x, z] of [[-2.1, -2.1], [2.1, -2.1], [-2.1, 2.1], [2.1, 2.1]] as Array<[number, number]>) {
    const col = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 3.2, 8), mf.get('stone'));
    col.position.set(x, 2.8, z);
    col.castShadow = true;
    g.add(col);
    const cap = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.3, 0.85), mf.get('stoneDark'));
    cap.position.set(x, 4.55, z);
    g.add(cap);
  }
  const roof = new THREE.Mesh(new THREE.BoxGeometry(6.2, 0.5, 6.2), mf.get('stoneDark'));
  roof.position.y = 4.95;
  roof.castShadow = true;
  g.add(roof);
  const top = new THREE.Mesh(new THREE.ConeGeometry(2.6, 1.8, 4), mf.get('roofAlt'));
  top.position.y = 6.1;
  top.rotation.y = Math.PI / 4;
  g.add(top);
  return g;
}

function buildRuin(mf: MaterialFactory, rng: Rng, prefab: string): THREE.Group {
  const g = new THREE.Group();
  if (prefab.includes('column')) {
    const h = randRange(rng, 1.4, 3.2);
    const col = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.4, h, 8), mf.get('stone'));
    col.position.y = h / 2;
    col.castShadow = true;
    col.receiveShadow = true;
    g.add(col);
    const broken = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.34, 0.35, 8), mf.get('stoneDark'));
    broken.position.y = h + 0.12;
    broken.rotation.set(randRange(rng, -0.25, 0.25), 0, randRange(rng, -0.25, 0.25));
    g.add(broken);
    const base = new THREE.Mesh(new THREE.BoxGeometry(1, 0.28, 1), mf.get('stoneDark'));
    base.position.y = 0.14;
    g.add(base);
  } else if (prefab.includes('gravestone')) {
    const stone = new THREE.Mesh(new THREE.BoxGeometry(0.62, 1.05, 0.16), mf.get('stoneDark'));
    stone.position.y = 0.55;
    stone.castShadow = true;
    g.add(stone);
    const top = new THREE.Mesh(new THREE.SphereGeometry(0.31, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.5), mf.get('stoneDark'));
    top.position.y = 1.06;
    g.add(top);
    const mound = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.14, 1.4), mf.get('groundAlt' as keyof Palette['colors']));
    mound.position.set(0, 0.07, 0.7);
    g.add(mound);
  } else {
    const w = randRange(rng, 1.8, 3.2);
    const wall = new THREE.Mesh(new THREE.BoxGeometry(w, randRange(rng, 1.2, 2.4), 0.5), mf.get('stone'));
    wall.position.y = 1;
    wall.castShadow = true;
    wall.receiveShadow = true;
    g.add(wall);
    for (let i = 0; i < 3; i++) {
      const chunk = new THREE.Mesh(new THREE.BoxGeometry(randRange(rng, 0.35, 0.7), randRange(rng, 0.3, 0.6), 0.55), mf.get('stoneDark'));
      chunk.position.set(randRange(rng, -w / 2, w / 2), randRange(rng, 0.15, 0.5), randRange(rng, -0.5, 0.5));
      chunk.rotation.set(randRange(rng, -0.4, 0.4), rng() * Math.PI, randRange(rng, -0.4, 0.4));
      g.add(chunk);
    }
  }
  return g;
}

function buildWindmill(mf: MaterialFactory, rng: Rng): THREE.Group {
  const g = new THREE.Group();
  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.5, 4.4, 10), mf.get('stone'));
  base.position.y = 2.2;
  base.castShadow = true;
  base.receiveShadow = true;
  g.add(base);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(1.45, 1.7, 10), mf.get('roof'));
  roof.position.y = 5.25;
  roof.castShadow = true;
  g.add(roof);
  const hub = new THREE.Group();
  hub.position.set(0, 4.1, 1.35);
  hub.name = 'blades';
  for (let i = 0; i < 4; i++) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.32, 2.6, 0.1), mf.get('wood'));
    blade.position.y = 1.35;
    const holder = new THREE.Group();
    holder.rotation.z = (i / 4) * Math.PI * 2;
    holder.add(blade);
    hub.add(holder);
  }
  g.add(hub);
  return g;
}

const BUILDERS: Record<string, PrefabBuilder> = {
  'tree.oak_a': (mf, rng) => buildTree(mf, rng, {}),
  'tree.oak_b': (mf, rng) => buildTree(mf, rng, {}),
  'tree.birch': (mf, rng) => buildTree(mf, rng, {}),
  'tree.willow': (mf, rng) => buildTree(mf, rng, { willow: true }),
  'tree.pine_a': (mf, rng) => buildTree(mf, rng, { pine: true }),
  'tree.pine_b': (mf, rng) => buildTree(mf, rng, { pine: true }),
  'tree.pine_snow_a': (mf, rng) => buildTree(mf, rng, { pine: true, snowy: true }),
  'tree.pine_snow_b': (mf, rng) => buildTree(mf, rng, { pine: true, snowy: true }),
  'tree.palm': (mf, rng) => buildTree(mf, rng, { palm: true }),
  'tree.dead': (mf, rng) => buildTree(mf, rng, { dead: true }),
  'rock.a': (mf, rng) => buildRock(mf, rng, {}),
  'rock.b': (mf, rng) => buildRock(mf, rng, {}),
  'rock.mossy': (mf, rng) => buildRock(mf, rng, { mossy: true }),
  'rock.ice': (mf, rng) => buildRock(mf, rng, { ice: true }),
  'rock.obsidian': (mf, rng) => buildRock(mf, rng, { obsidian: true }),
  'rock.dune': (mf, rng) => buildRock(mf, rng, { dune: true }),
  'rock.small': (mf, rng) => buildRock(mf, rng, { small: true }),
  'structure.house_a': (mf, rng) => buildHouse(mf, rng, {}),
  'structure.house_b': (mf, rng) => buildHouse(mf, rng, {}),
  'structure.house_c': (mf, rng) => buildHouse(mf, rng, {}),
  'structure.hut_a': (mf, rng) => buildHouse(mf, rng, { hut: true }),
  'structure.barn': (mf, rng) => buildHouse(mf, rng, { barn: true }),
  'structure.tower_keep': (mf, rng) => buildTower(mf, rng, { keep: true }),
  'structure.tower_round': (mf, rng) => buildTower(mf, rng, {}),
  'structure.gatehouse': (mf, rng) => buildTower(mf, rng, { gatehouse: true }),
  'structure.wall_segment': (mf, rng) => buildWall(mf, rng),
  'structure.bridge': (mf, rng) => buildBridge(mf, rng),
  'structure.temple': (mf, rng) => buildTemple(mf, rng),
  'structure.ruin_column': (mf, rng) => buildRuin(mf, rng, 'ruin_column'),
  'structure.ruin_wall': (mf, rng) => buildRuin(mf, rng, 'ruin_wall'),
  'structure.gravestone': (mf, rng) => buildRuin(mf, rng, 'gravestone'),
  'structure.windmill': (mf, rng) => buildWindmill(mf, rng),
  'prop.crate': (mf, rng) => buildProp(mf, rng, 'crate'),
  'prop.barrel': (mf, rng) => buildProp(mf, rng, 'barrel'),
  'prop.bench': (mf, rng) => buildProp(mf, rng, 'bench'),
  'prop.lamp': (mf, rng) => buildProp(mf, rng, 'lamp'),
  'prop.well': (mf, rng) => buildProp(mf, rng, 'well'),
  'prop.campfire': (mf, rng) => buildProp(mf, rng, 'campfire'),
  'prop.fence': (mf, rng) => buildProp(mf, rng, 'fence'),
  'prop.boat': (mf, rng) => buildProp(mf, rng, 'boat'),
  'crystal.red': (mf, rng) => buildProp(mf, rng, 'crystal'),
  'crystal.blue': (mf, rng) => buildProp(mf, rng, 'crystal'),
  'mushroom.red': (mf, rng) => buildProp(mf, rng, 'mushroom'),
  'flower.mixed': (mf, rng) => buildProp(mf, rng, 'flower'),
  'bush.small': (mf, rng) => buildProp(mf, rng, 'bush'),
  'bush.berries': (mf, rng) => buildProp(mf, rng, 'bush'),
  'grass.tuft': (mf, rng) => buildProp(mf, rng, 'grass'),
  'grass.dry': (mf, rng) => buildProp(mf, rng, 'grass'),
  'plant.crop_row': (mf, rng) => buildGeneric(mf, rng, 'plant'),
  'cactus.tall': (mf, rng) => buildGeneric(mf, rng, 'cactus'),
  'cactus.round': (mf, rng) => buildGeneric(mf, rng, 'cactus'),
};

export function listPrefabs(): string[] {
  return Object.keys(BUILDERS);
}

export function buildPrefab(prefab: string, mf: MaterialFactory, seed: string | number): THREE.Object3D {
  const builder = BUILDERS[prefab] ?? BUILDERS[guessPrefab(prefab)] ?? null;
  const rng = rngFrom(typeof seed === 'string' ? seed : seed >>> 0);
  const obj = builder ? builder(mf, rng) : buildGeneric(mf, rng, prefab);
  obj.name = prefab;
  obj.traverse((c) => {
    c.castShadow = true;
    if ((c as THREE.Mesh).isMesh) {
      (c as THREE.Mesh).receiveShadow = true;
    }
  });
  return obj;
}

function guessPrefab(prefab: string): string {
  const p = prefab.toLowerCase();
  if (p.includes('tree')) return 'tree.oak_a';
  if (p.includes('rock') || p.includes('stone')) return 'rock.a';
  if (p.includes('house') || p.includes('hut')) return 'structure.house_a';
  if (p.includes('tower')) return 'structure.tower_round';
  if (p.includes('wall') || p.includes('fence')) return 'structure.wall_segment';
  return 'prop.crate';
}

/** Merge all meshes of a group into one geometry+material pair for instancing. */
export function flattenToInstanced(group: THREE.Object3D): THREE.BufferGeometry | null {
  const geos: THREE.BufferGeometry[] = [];
  group.updateMatrixWorld(true);
  group.traverse((c) => {
    const mesh = c as THREE.Mesh;
    if (mesh.isMesh) {
      const g = mesh.geometry.clone();
      g.applyMatrix4(mesh.matrixWorld);
      // Bake per-mesh colors into vertex colors so one material can render the prefab.
      const mat = mesh.material as THREE.MeshStandardMaterial;
      const count = g.attributes.position.count;
      const colors = new Float32Array(count * 3);
      const col = mat.color ?? new THREE.Color(0x888888);
      for (let i = 0; i < count; i++) {
        colors[i * 3] = col.r;
        colors[i * 3 + 1] = col.g;
        colors[i * 3 + 2] = col.b;
      }
      g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      if (!g.attributes.normal) g.computeVertexNormals();
      geos.push(g);
    }
  });
  if (!geos.length) return null;
  return mergeGeometries(geos);
}

/** Minimal geometry merge (positions/normals/uv/color) to avoid extra deps. */
export function mergeGeometries(geos: THREE.BufferGeometry[]): THREE.BufferGeometry {
  let total = 0;
  for (const g of geos) total += g.attributes.position.count;
  const positions = new Float32Array(total * 3);
  const normals = new Float32Array(total * 3);
  const colors = new Float32Array(total * 3);
  let offset = 0;
  for (const g of geos) {
    const pos = g.attributes.position as THREE.BufferAttribute;
    const norm = g.attributes.normal as THREE.BufferAttribute | undefined;
    const col = g.attributes.color as THREE.BufferAttribute | undefined;
    for (let i = 0; i < pos.count; i++) {
      const di = (offset + i) * 3;
      positions[di] = pos.getX(i);
      positions[di + 1] = pos.getY(i);
      positions[di + 2] = pos.getZ(i);
      if (norm) {
        normals[di] = norm.getX(i);
        normals[di + 1] = norm.getY(i);
        normals[di + 2] = norm.getZ(i);
      }
      if (col) {
        colors[di] = col.getX(i);
        colors[di + 1] = col.getY(i);
        colors[di + 2] = col.getZ(i);
      } else {
        colors[di] = colors[di + 1] = colors[di + 2] = 0.8;
      }
    }
    offset += pos.count;
    g.dispose();
  }
  const merged = new THREE.BufferGeometry();
  merged.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  merged.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
  merged.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  return merged;
}

export type { WorldObject, Vec3 };
