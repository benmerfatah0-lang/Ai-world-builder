/**
 * Viewport — the Three.js rendering core of the editor.
 *
 * Owns: renderer, camera, orbit + transform controls, sky/lighting, terrain and
 * water meshes, entity meshes (unique objects + instanced scatter clusters),
 * selection (raycast), view modes, and the render loop.
 *
 * Deliberately framework-free so it can be driven by React (or tests) through
 * a small imperative API.
 */
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { TransformControls } from 'three/examples/jsm/controls/TransformControls.js';
import { Emitter } from '../core/events';
import { hashString } from '../core/rng';
import type { WorldPlan, WorldObject, PathSpec, Vec3, SkyPreset } from '../core/types';
import type { Heightfield } from '../generators/terrain';
import { sampleHeight } from '../generators/terrain';
import { MaterialFactory } from './materials';
import { buildPrefab, flattenToInstanced } from './entityFactory';
import { buildTerrainMesh, buildPathRibbon, type TerrainBuildResult } from './terrainMesh';

export type TransformMode = 'translate' | 'rotate' | 'scale';
export type ViewMode = 'rendered' | 'solid' | 'wireframe';

export interface ViewportWorld {
  plan: WorldPlan;
  heightfield: Heightfield;
  derivedObjects: WorldObject[];
  derivedPaths: PathSpec[];
}

export interface ViewportEvents extends Record<string, unknown> {
  selection: { ids: string[] };
  transform: { id: string; position: Vec3; rotation: Vec3; scale: Vec3 | number; commit: boolean };
  pointerDown: { id: string | null };
  cameraChanged: void;
}

export class Viewport {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene: THREE.Scene;
  readonly camera: THREE.PerspectiveCamera;
  readonly events = new Emitter<ViewportEvents>();

  private orbit: OrbitControls;
  private transform: TransformControls;
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private clock = new THREE.Clock();

  private objectRoot = new THREE.Group();
  private terrainGroup = new THREE.Group();
  private envGroup = new THREE.Group();

  private entityMap = new Map<string, THREE.Object3D>();
  private entityJson = new Map<string, string>();
  private pickables: THREE.Object3D[] = [];
  private selectionHelper: THREE.Box3Helper | null = null;
  private selectedIds: string[] = [];

  private materialFactory: MaterialFactory;
  private terrainBuild: TerrainBuildResult | null = null;
  private heightfield: Heightfield | null = null;
  private water: THREE.Mesh | null = null;
  private sky: THREE.Mesh | null = null;
  private sun: THREE.DirectionalLight;
  private ambient: THREE.HemisphereLight;

  private raf = 0;
  private disposed = false;
  private viewMode: ViewMode = 'rendered';
  private dragging = false;

  constructor(private canvas: HTMLCanvasElement, style: WorldPlan['settings']['style'] = 'low-poly') {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, preserveDrawingBuffer: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x9db8d6, 0.0016);

    this.camera = new THREE.PerspectiveCamera(55, 1, 0.3, 5000);
    this.camera.position.set(120, 95, 120);

    this.orbit = new OrbitControls(this.camera, canvas);
    this.orbit.enableDamping = true;
    this.orbit.dampingFactor = 0.06;
    this.orbit.maxPolarAngle = Math.PI * 0.495;
    this.orbit.minDistance = 3;
    this.orbit.maxDistance = 1600;

    this.transform = new TransformControls(this.camera, canvas);
    this.transform.getHelper().name = 'transform-gizmo';
    this.scene.add(this.transform.getHelper());
    this.transform.addEventListener('dragging-changed', (e) => {
      const value = (e as unknown as { value: boolean }).value;
      this.dragging = value;
      this.orbit.enabled = !value;
    });
    this.transform.addEventListener('objectChange', () => {
      const target = this.transform.object;
      if (!target) return;
      const id = target.userData.entityId as string | undefined;
      if (!id) return;
      this.updateSelectionHelper();
      this.events.emit('transform', {
        id,
        position: vec3(target.position),
        rotation: [target.rotation.x, target.rotation.y, target.rotation.z],
        scale: vec3(target.scale),
        commit: false,
      });
    });
    this.transform.addEventListener('mouseUp', () => {
      const target = this.transform.object;
      if (!target) return;
      const id = target.userData.entityId as string | undefined;
      if (!id) return;
      this.events.emit('transform', {
        id,
        position: vec3(target.position),
        rotation: [target.rotation.x, target.rotation.y, target.rotation.z],
        scale: vec3(target.scale),
        commit: true,
      });
    });

    // Lights
    this.ambient = new THREE.HemisphereLight(0x9db8d6, 0x3a4a3a, 0.85);
    this.scene.add(this.ambient);
    this.sun = new THREE.DirectionalLight(0xfff4e0, 2.4);
    this.sun.position.set(120, 160, 60);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.camera.near = 10;
    this.sun.shadow.camera.far = 620;
    const sc = this.sun.shadow.camera as THREE.OrthographicCamera;
    sc.left = -180; sc.right = 180; sc.top = 180; sc.bottom = -180;
    this.sun.shadow.bias = -0.0007;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);

    this.scene.add(this.terrainGroup);
    this.scene.add(this.objectRoot);
    this.scene.add(this.envGroup);

    this.materialFactory = new MaterialFactory(style);
    this.buildSky('day');

    canvas.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('resize', this.onResize);
    this.onResize();

    const loop = () => {
      if (this.disposed) return;
      this.raf = requestAnimationFrame(loop);
      this.tick();
    };
    this.raf = requestAnimationFrame(loop);
  }

  /* ---------------------------------------------------------------- */
  /* World synchronization                                            */
  /* ---------------------------------------------------------------- */

  setWorld(world: ViewportWorld): void {
    const { plan, heightfield, derivedObjects, derivedPaths } = world;
    const terrainKey = `${plan.seed}|${JSON.stringify(plan.terrain)}|${JSON.stringify(plan.settings.size)}|${plan.settings.style}|${heightfield.resolution}`;
    if (this.terrainKey !== terrainKey) {
      this.terrainKey = terrainKey;
      this.rebuildTerrain(heightfield, plan.settings.style);
    }
    this.heightfield = heightfield;

    if (this.styleKey !== plan.settings.style) {
      this.styleKey = plan.settings.style;
      this.materialFactory.dispose();
      this.materialFactory = new MaterialFactory(plan.settings.style);
    }

    const all = [...plan.objects, ...derivedObjects];
    const seen = new Set<string>();
    for (const obj of all) {
      seen.add(obj.id);
      const json = JSON.stringify(obj);
      if (this.entityJson.get(obj.id) === json && this.entityMap.has(obj.id)) continue;
      this.removeEntity(obj.id);
      this.addEntity(obj, plan.seed);
      this.entityJson.set(obj.id, json);
    }
    for (const id of [...this.entityMap.keys()]) {
      if (!seen.has(id)) this.removeEntity(id);
    }

    this.rebuildPaths(derivedPaths, heightfield, plan.settings.style);
    this.applyEnvironment(plan);
    this.updatePickables();

    // Drop selection if its object vanished.
    this.selectedIds = this.selectedIds.filter((id) => this.entityMap.has(id));
    if (this.selectedIds.length) this.attachToSelection();
    else this.transform.detach();
  }

  private terrainKey = '';
  private styleKey = '';
  private pathMeshes: THREE.Object3D[] = [];

  private rebuildTerrain(hf: Heightfield, style: WorldPlan['settings']['style']): void {
    if (this.terrainBuild) {
      this.terrainGroup.remove(this.terrainBuild.mesh, this.terrainBuild.water);
      this.terrainBuild.dispose();
    }
    this.terrainBuild = buildTerrainMesh(hf, style);
    this.terrainGroup.add(this.terrainBuild.mesh, this.terrainBuild.water);
    this.water = this.terrainBuild.water;

    const shadowCam = this.sun.shadow.camera as THREE.OrthographicCamera;
    const extent = Math.max(80, hf.size * 0.55);
    shadowCam.left = -extent; shadowCam.right = extent; shadowCam.top = extent; shadowCam.bottom = -extent;
    shadowCam.updateProjectionMatrix();
    this.updatePickables();
  }

  private rebuildPaths(paths: PathSpec[], hf: Heightfield, style: WorldPlan['settings']['style']): void {
    for (const p of this.pathMeshes) this.terrainGroup.remove(p);
    this.pathMeshes = [];
    const flat = style === 'low-poly' || style === 'voxel' || style === 'cartoon';
    for (const path of paths) {
      const color = path.kind === 'road' ? '#a98b62' : path.kind === 'path' ? '#b89b72' : path.kind === 'river' ? '#3f7fb8' : '#8c7a5e';
      const ribbon = buildPathRibbon(hf, path.points, path.width, color, flat);
      if (ribbon) {
        ribbon.userData.entityId = path.id;
        this.terrainGroup.add(ribbon);
        this.pathMeshes.push(ribbon);
      }
    }
  }

  private addEntity(obj: WorldObject, seed: number): void {
    const group = new THREE.Group();
    group.name = obj.name ?? obj.kind;
    group.userData.entityId = obj.id;
    group.userData.entityKind = obj.kind;

    const objSeed = hashString(`${obj.id}:${obj.prefab ?? obj.kind}:${seed}`);
    const prefab = obj.prefab ?? `generic.${obj.kind}`;

    if (obj.instances && obj.instances.length > 0) {
      const proto = buildPrefab(prefab, this.materialFactory, objSeed);
      const geo = flattenToInstanced(proto);
      disposeObject(proto);
      if (geo) {
        const mat = new THREE.MeshStandardMaterial({
          vertexColors: true,
          flatShading: this.materialFactory.palette.flatShading,
          roughness: this.materialFactory.palette.roughness,
          metalness: this.materialFactory.palette.metalness,
        });
        const inst = new THREE.InstancedMesh(geo, mat, obj.instances.length);
        inst.castShadow = true;
        inst.receiveShadow = true;
        const m = new THREE.Matrix4();
        const q = new THREE.Quaternion();
        const eul = new THREE.Euler();
        const pos = new THREE.Vector3();
        const scl = new THREE.Vector3();
        obj.instances.forEach((instSpec, i) => {
          pos.fromArray(instSpec.position);
          if (instSpec.rotation) eul.fromArray(instSpec.rotation as [number, number, number]);
          else eul.set(0, 0, 0);
          q.setFromEuler(eul);
          const s = instSpec.scale;
          if (typeof s === 'number') scl.set(s, s, s);
          else if (Array.isArray(s)) scl.fromArray(s);
          else scl.set(1, 1, 1);
          m.compose(pos, q, scl);
          inst.setMatrixAt(i, m);
        });
        inst.instanceMatrix.needsUpdate = true;
        inst.userData.entityId = obj.id;
        inst.userData.isCluster = true;
        group.add(inst);
      }
    } else {
      const mesh = buildPrefab(prefab, this.materialFactory, objSeed);
      if (obj.rotation) mesh.rotation.fromArray(obj.rotation as [number, number, number]);
      if (obj.scale !== undefined) {
        if (typeof obj.scale === 'number') mesh.scale.setScalar(obj.scale);
        else mesh.scale.fromArray(obj.scale as [number, number, number]);
      }
      mesh.position.fromArray(obj.position);
      mesh.traverse((c) => {
        c.userData.entityId = obj.id;
      });
      group.add(mesh);
      group.position.set(0, 0, 0);
      // Move the inner mesh by the entity position so group stays at origin for gizmo math.
      group.position.fromArray(obj.position);
      mesh.position.set(0, 0, 0);
    }

    if (obj.position && !(obj.instances && obj.instances.length)) {
      group.position.fromArray(obj.position);
    } else {
      group.position.fromArray(obj.position ?? [0, 0, 0]);
    }

    this.objectRoot.add(group);
    this.entityMap.set(obj.id, group);
  }

  private removeEntity(id: string): void {
    const g = this.entityMap.get(id);
    if (!g) return;
    this.objectRoot.remove(g);
    disposeObject(g);
    this.entityMap.delete(id);
    this.entityJson.delete(id);
    if (this.transform.object === g) this.transform.detach();
  }

  private updatePickables(): void {
    this.pickables = [this.objectRoot];
  }

  /* ---------------------------------------------------------------- */
  /* Environment                                                      */
  /* ---------------------------------------------------------------- */

  applyEnvironment(plan: WorldPlan): void {
    const env = plan.settings.environment ?? {};
    const skyPreset: SkyPreset = env.skyPreset ?? 'day';
    this.buildSky(skyPreset);
    const lighting = plan.lighting ?? {};
    const timeOfDay = env.timeOfDay ?? 10.5;

    // Sun position from azimuth/elevation.
    const az = THREE.MathUtils.degToRad(lighting.sunAzimuth ?? 120);
    const el = THREE.MathUtils.degToRad(lighting.sunElevation ?? elevationForTime(timeOfDay));
    const dist = 240;
    this.sun.position.set(
      Math.cos(el) * Math.cos(az) * dist,
      Math.sin(el) * dist,
      Math.cos(el) * Math.sin(az) * dist,
    );
    this.sun.color.set(lighting.sunColor ?? (skyPreset === 'sunset' ? '#ffb27a' : skyPreset === 'night' ? '#7f93c9' : '#fff4e0'));
    this.sun.intensity = lighting.sunIntensity ?? (skyPreset === 'night' ? 0.5 : skyPreset === 'sunset' ? 1.9 : 2.4);
    this.ambient.color.set(lighting.ambientColor ?? (skyPreset === 'night' ? '#2b3a66' : '#9db8d6'));
    this.ambient.intensity = lighting.ambientIntensity ?? (skyPreset === 'night' ? 0.45 : 0.85);
    this.sun.castShadow = lighting.shadows !== false;

    const fogDensity = env.fogDensity ?? 0.0016;
    const fog = this.scene.fog as THREE.FogExp2;
    fog.density = fogDensity * 0.35;
    fog.color.set(skyPreset === 'night' ? '#0c1226' : skyPreset === 'sunset' ? '#c98a68' : skyPreset === 'overcast' ? '#9aa4ad' : '#9db8d6');
  }

  private buildSky(preset: SkyPreset): void {
    if (this.sky) {
      this.envGroup.remove(this.sky);
      disposeObject(this.sky);
      this.sky = null;
    }
    const colors: Record<SkyPreset, [string, string]> = {
      day: ['#4a86c8', '#cfe4f5'],
      sunset: ['#3b3d7a', '#f2a15c'],
      night: ['#05081a', '#1c2c52'],
      dawn: ['#2c3a6b', '#e8b48a'],
      overcast: ['#5c6b7a', '#a8b4be'],
    };
    const [top, bottom] = colors[preset] ?? colors.day;
    const geo = new THREE.SphereGeometry(2200, 24, 16);
    const mat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        topColor: { value: new THREE.Color(top) },
        bottomColor: { value: new THREE.Color(bottom) },
      },
      vertexShader: /* glsl */ `
        varying vec3 vWorldPos;
        void main() {
          vec4 worldPos = modelMatrix * vec4(position, 1.0);
          vWorldPos = worldPos.xyz;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: /* glsl */ `
        uniform vec3 topColor;
        uniform vec3 bottomColor;
        varying vec3 vWorldPos;
        void main() {
          float h = normalize(vWorldPos).y;
          float t = clamp(h * 1.4 + 0.25, 0.0, 1.0);
          gl_FragColor = vec4(mix(bottomColor, topColor, t), 1.0);
        }
      `,
    });
    this.sky = new THREE.Mesh(geo, mat);
    this.sky.name = 'sky';
    this.sky.frustumCulled = false;
    this.envGroup.add(this.sky);
    this.scene.background = new THREE.Color(bottom);
  }

  /* ---------------------------------------------------------------- */
  /* Selection & transforms                                           */
  /* ---------------------------------------------------------------- */

  private onPointerDown = (ev: PointerEvent): void => {
    if (this.dragging) return;
    const rect = this.canvas.getBoundingClientRect();
    this.pointer.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects([this.objectRoot], true);
    const hit = hits.find((h) => h.object.userData.entityId);
    const id = hit ? (hit.object.userData.entityId as string) : null;
    this.events.emit('pointerDown', { id });
    if (id) this.select([id]);
    else this.select([]);
  };

  select(ids: string[]): void {
    this.selectedIds = ids;
    if (ids.length) this.attachToSelection();
    else this.transform.detach();
    this.updateSelectionHelper();
    this.events.emit('selection', { ids });
  }

  private attachToSelection(): void {
    const g = this.entityMap.get(this.selectedIds[0]);
    if (g) this.transform.attach(g);
    else this.transform.detach();
  }

  private updateSelectionHelper(): void {
    if (this.selectionHelper) {
      this.scene.remove(this.selectionHelper);
      this.selectionHelper = null;
    }
    if (!this.selectedIds.length) return;
    const box = new THREE.Box3();
    for (const id of this.selectedIds) {
      const g = this.entityMap.get(id);
      if (g) box.expandByObject(g);
    }
    if (box.isEmpty()) return;
    this.selectionHelper = new THREE.Box3Helper(box, new THREE.Color('#ffb23f'));
    this.scene.add(this.selectionHelper);
  }

  setTransformMode(mode: TransformMode): void {
    this.transform.setMode(mode);
  }

  setTransformSpace(space: 'world' | 'local'): void {
    this.transform.setSpace(space);
  }

  setViewMode(mode: ViewMode): void {
    this.viewMode = mode;
    const wire = mode === 'wireframe';
    this.scene.traverse((c) => {
      const mesh = c as THREE.Mesh;
      if (mesh.isMesh) {
        const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        for (const m of mats) {
          const std = m as THREE.MeshStandardMaterial;
          if (std && 'wireframe' in std) std.wireframe = wire;
        }
      }
    });
    if (this.terrainBuild) {
      (this.terrainBuild.mesh.material as THREE.MeshStandardMaterial).wireframe = wire;
      this.terrainBuild.mesh.visible = mode !== 'rendered' ? true : true;
    }
  }

  deleteSelected(): void {
    // Deletion is handled by the app via plan ops; the viewport just detaches.
    this.transform.detach();
  }

  /* ---------------------------------------------------------------- */
  /* Camera helpers                                                   */
  /* ---------------------------------------------------------------- */

  frameWorld(): void {
    const box = new THREE.Box3();
    if (this.terrainBuild) box.expandByObject(this.terrainBuild.mesh);
    box.expandByObject(this.objectRoot);
    if (box.isEmpty()) return;
    this.frameBox(box);
  }

  frameSelection(): void {
    const box = new THREE.Box3();
    for (const id of this.selectedIds) {
      const g = this.entityMap.get(id);
      if (g) box.expandByObject(g);
    }
    if (box.isEmpty()) this.frameWorld();
    else this.frameBox(box);
  }

  private frameBox(box: THREE.Box3): void {
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const radius = Math.max(size.x, size.y, size.z, 10);
    const dist = radius * 1.45;
    const dir = new THREE.Vector3(1, 0.75, 1).normalize();
    this.camera.position.copy(center).addScaledVector(dir, dist);
    this.orbit.target.copy(center);
    this.orbit.update();
  }

  setCameraPose(position: Vec3, target: Vec3): void {
    this.camera.position.fromArray(position);
    this.orbit.target.fromArray(target);
    this.orbit.update();
  }

  getCameraPose(): { position: Vec3; target: Vec3 } {
    return {
      position: [this.camera.position.x, this.camera.position.y, this.camera.position.z],
      target: [this.orbit.target.x, this.orbit.target.y, this.orbit.target.z],
    };
  }

  /** World-space ground point under a normalized device coordinate. */
  pickGround(ndcX: number, ndcY: number): Vec3 | null {
    if (!this.heightfield) return null;
    this.pointer.set(ndcX, ndcY);
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObject(this.terrainBuild!.mesh, false);
    if (hits.length) {
      const p = hits[0].point;
      return [p.x, p.y, p.z];
    }
    return null;
  }

  getTerrainHeight(x: number, z: number): number {
    return this.heightfield ? sampleHeight(this.heightfield, x, z) : 0;
  }

  screenshot(): string {
    this.renderer.render(this.scene, this.camera);
    return this.canvas.toDataURL('image/png');
  }

  /* ---------------------------------------------------------------- */
  /* Loop                                                             */
  /* ---------------------------------------------------------------- */

  private tick(): void {
    const t = this.clock.getElapsedTime();
    this.orbit.update();

    if (this.water) {
      this.water.position.y = (this.heightfield?.waterLevel ?? 0) + Math.sin(t * 0.55) * 0.06;
    }

    // Animate campfire flames and windmill blades wherever they are.
    this.objectRoot.traverse((c) => {
      if (c.name === 'flame') {
        const s = 1 + Math.sin(t * 7 + c.id) * 0.12;
        c.scale.set(s, 1 + Math.sin(t * 9) * 0.18, s);
      } else if (c.name === 'blades') {
        c.rotation.z += 0.0045;
      }
    });

    if (this.selectionHelper) this.updateSelectionHelper();

    this.renderer.render(this.scene, this.camera);
  }

  private onResize = (): void => {
    const w = this.canvas.clientWidth || this.canvas.parentElement?.clientWidth || 800;
    const h = this.canvas.clientHeight || this.canvas.parentElement?.clientHeight || 600;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    this.events.emit('cameraChanged', undefined);
  };

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.canvas.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('resize', this.onResize);
    this.transform.detach();
    this.transform.dispose();
    this.orbit.dispose();
    for (const id of [...this.entityMap.keys()]) this.removeEntity(id);
    this.terrainBuild?.dispose();
    this.materialFactory.dispose();
    this.scene.traverse((c) => disposeObject(c));
    this.renderer.dispose();
    this.events.clear();
  }
}

function vec3(v: THREE.Vector3): Vec3 {
  return [v.x, v.y, v.z];
}

function disposeObject(obj: THREE.Object3D): void {
  obj.traverse((c) => {
    const mesh = c as THREE.Mesh;
    if (mesh.isMesh) {
      mesh.geometry?.dispose();
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const m of mats) {
        // Materials may be shared/cached — only dispose clearly local ones.
        if (m && m.name !== '__shared__') m.dispose();
      }
    }
  });
}

function elevationForTime(t: number): number {
  const x = Math.abs(t - 12) / 12;
  return Math.max(4, 62 * Math.cos(x * Math.PI * 0.5));
}
