/**
 * Heightfield → renderable terrain mesh with height/slope-based vertex colors.
 */
import * as THREE from 'three';
import type { Heightfield } from '../generators/terrain';
import { sampleHeight } from '../generators/terrain';
import type { Palette } from '../generators/presets';
import type { ArtStyle } from '../core/types';
import { getPalette } from '../generators/presets';

export interface TerrainBuildResult {
  mesh: THREE.Mesh;
  water: THREE.Mesh;
  dispose(): void;
}

export function buildTerrainMesh(
  hf: Heightfield,
  style: ArtStyle,
  resolution?: number,
): TerrainBuildResult {
  const palette = getPalette(style);
  const res = resolution ?? hf.resolution;
  const half = hf.size / 2;
  const geo = new THREE.PlaneGeometry(hf.size, hf.size, res - 1, res - 1);
  geo.rotateX(-Math.PI / 2);

  const pos = geo.attributes.position as THREE.BufferAttribute;
  const colors = new Float32Array(pos.count * 3);
  const cSand = new THREE.Color(palette.colors.sand);
  const cGrass = new THREE.Color(palette.colors.grass);
  const cGrassDry = new THREE.Color(palette.colors.grassDry);
  const cRock = new THREE.Color(palette.colors.rock);
  const cRockDark = new THREE.Color(palette.colors.rockDark);
  const cSnow = new THREE.Color(palette.colors.snow);
  const cGround = new THREE.Color(palette.colors.ground);
  const tmp = new THREE.Color();

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const y = sampleHeight(hf, x, z);
    pos.setY(i, y);

    // Slope from finite differences.
    const e = 1.2;
    const hL = sampleHeight(hf, x - e, z);
    const hR = sampleHeight(hf, x + e, z);
    const hD = sampleHeight(hf, x, z - e);
    const hU = sampleHeight(hf, x, z + e);
    const slope = 1 - Math.min(1, Math.hypot((hR - hL) / (2 * e), (hU - hD) / (2 * e)) * -1);
    const grad = Math.hypot(hR - hL, hU - hD) / (2 * e);

    const aboveWater = y - hf.waterLevel;
    if (aboveWater < 1.2) {
      tmp.copy(cSand);
    } else if (grad > 0.85) {
      tmp.copy(aboveWater > hf.size * 0.06 ? cRockDark : cRock);
    } else if (aboveWater > hf.size * 0.085 + 18) {
      tmp.copy(cSnow).lerp(cRock, Math.min(1, Math.max(0, 1 - (aboveWater - 30) / 18)) * 0.55);
    } else if (grad > 0.45) {
      tmp.copy(cRock).lerp(cGround, 0.35);
    } else {
      tmp.copy(cGrass).lerp(cGrassDry, Math.min(1, Math.max(0, (y - hf.waterLevel) / 26)));
      if (grad > 0.28) tmp.lerp(cRock, 0.3);
    }
    colors[i * 3] = tmp.r;
    colors[i * 3 + 1] = tmp.g;
    colors[i * 3 + 2] = tmp.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();

  const material = new THREE.MeshStandardMaterial({
    vertexColors: true,
    flatShading: palette.flatShading,
    roughness: 0.95,
    metalness: 0.0,
  });
  const mesh = new THREE.Mesh(geo, material);
  mesh.receiveShadow = true;
  mesh.castShadow = true;
  mesh.name = 'terrain';

  // Water plane
  const waterGeo = new THREE.PlaneGeometry(hf.size * 1.02, hf.size * 1.02, 24, 24);
  waterGeo.rotateX(-Math.PI / 2);
  const waterMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(palette.colors.water),
    roughness: 0.16,
    metalness: 0.18,
    transparent: true,
    opacity: 0.8,
    flatShading: palette.flatShading,
  });
  const water = new THREE.Mesh(waterGeo, waterMat);
  water.position.y = hf.waterLevel;
  water.receiveShadow = true;
  water.name = 'water';

  return {
    mesh,
    water,
    dispose() {
      geo.dispose();
      material.dispose();
      waterGeo.dispose();
      waterMat.dispose();
    },
  };
}

/** Ground ribbon for roads/paths — follows terrain heights. */
export function buildPathRibbon(
  hf: Heightfield,
  points: Array<[number, number]>,
  width: number,
  color: string,
  flatShading: boolean,
): THREE.Mesh | null {
  if (points.length < 2) return null;
  const positions: number[] = [];
  const indices: number[] = [];
  const halfW = width / 2;

  for (let i = 0; i < points.length; i++) {
    const [x, z] = points[i];
    const [px, pz] = points[Math.max(0, i - 1)];
    const [nx, nz] = points[Math.min(points.length - 1, i + 1)];
    let dx = nx - px;
    let dz = nz - pz;
    const len = Math.hypot(dx, dz) || 1;
    dx /= len;
    dz /= len;
    const ox = -dz * halfW;
    const oz = dx * halfW;
    const yL = sampleHeight(hf, x + ox, z + oz) + 0.12;
    const yR = sampleHeight(hf, x - ox, z - oz) + 0.12;
    positions.push(x + ox, yL, z + oz, x - ox, yR, z - oz);
    if (i > 0) {
      const base = (i - 1) * 2;
      indices.push(base, base + 1, base + 2, base + 1, base + 3, base + 2);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  const mat = new THREE.MeshStandardMaterial({ color: new THREE.Color(color), roughness: 0.9, flatShading });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.receiveShadow = true;
  mesh.name = 'path';
  return mesh;
}
