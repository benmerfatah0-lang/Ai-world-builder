# نشر التطبيق بشكل دائم — خطوات سهلة

لا تحتاج إلى ربط GitHub بمحادثة Arena. نزّل ملف `ai-world-builder-deploy.zip` من مساحة العمل ثم اتبع إحدى الطريقتين.

## الطريقة الموصى بها: GitHub من المتصفح + Render

### أولًا: رفع المشروع إلى GitHub يدويًا

1. افتح https://github.com وأنشئ حسابًا مجانيًا إن لم يكن لديك حساب.
2. اضغط **New repository**.
3. اكتب الاسم `ai-world-builder` واختر **Private** أو **Public** ثم **Create repository**.
4. فك ضغط `ai-world-builder-deploy.zip` على حاسوبك.
5. من صفحة المستودع اضغط **uploading an existing file** أو **Add file → Upload files**.
6. اسحب محتويات المجلد المفكوك إلى الصفحة، ثم اضغط **Commit changes**.

> GitHub لا يسمح عادةً برفع مجلد كامل من الهاتف بسهولة. يفضل الحاسوب. الربط مع محادثة Arena غير مطلوب.

### ثانيًا: نشره على Render

1. افتح https://render.com وأنشئ حسابًا.
2. اختر **New → Blueprint**.
3. اربط حساب GitHub من داخل Render فقط، ثم اختر مستودع `ai-world-builder`.
4. سيقرأ Render ملف `render.yaml` ويبني Docker تلقائيًا.
5. بعد انتهاء البناء سيظهر رابط ثابت شبيه بـ:
   `https://ai-world-builder.onrender.com`
6. افتح الرابط من Chrome على Android ثم **⋮ → تثبيت التطبيق**.

الخطة المجانية قد تدخل في وضع السكون عند عدم الاستخدام، فتحتاج أول زيارة إلى بعض الوقت. للحصول على تشغيل دائم دون سكون اختر خطة مدفوعة أو استضافة أخرى.

## مفاتيح الذكاء الاصطناعي الاختيارية

في Render افتح **Environment** وأضف فقط المفاتيح التي تملكها:

- `OPENAI_API_KEY`
- `ANTHROPIC_API_KEY`
- `TRIPO_API_KEY`

لا تضع المفاتيح في GitHub أو الملفات. التطبيق الأساسي يعمل دونها.

## تشغيل Docker على أي خادم

```bash
docker build -t ai-world-builder .
docker run -p 8787:8787 --name ai-world-builder ai-world-builder
```

ثم افتح `http://عنوان-الخادم:8787`.

## ما يوجد في حزمة النشر؟

- مصدر الواجهة ومحرك Three.js في `src/`
- الخادم الآمن في `server/`
- تطبيق Android في `android/`
- غلاف الحاسوب في `electron/`
- الاختبارات والمخطط والوثائق
- `Dockerfile` و`render.yaml` للاستضافة من رابط واحد

## تنبيه مهم

أنا أستطيع تجهيز واختبار الملفات، لكن لا يمكنني إنشاء حساب أو قبول شروط خدمة أو نشر موارد باسمك دون تسجيل دخولك أنت إلى خدمة الاستضافة. بعد النشر، رابط Render هو الرابط الدائم الذي تستعمله بدل رابط Arena المؤقت.
